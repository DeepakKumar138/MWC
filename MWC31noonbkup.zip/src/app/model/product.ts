export class Product{
    repositoryId:string;
    displayName: string;
    salePrice: string;
    description: string;
   
}