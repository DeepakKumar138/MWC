import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServicesService } from '../services/services.service';
import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
@Component({
  selector: 'app-smart-workplace-bundle',
  templateUrl: './smart-workplace-bundle.component.html',
  styleUrls: ['./smart-workplace-bundle.component.css']
})
export class SmartWorkplaceBundleComponent implements OnInit {

  product = [];
  products = [];
  constructor(private service:ServicesService) { }

  ngOnInit() {
    this.getproduct();
  }


  // get product  form API and store in local
  getproduct() {
    let tempproduct = {

    }
    this.service.getProduct()
      .subscribe((data) => {
        console.log(data);
        for (let index = 0; index < data.products.length; index++) {
          this.product.push(data.products[index]);
          localStorage.setItem('product_internet', JSON.stringify(data.products[index]));
        }
    console.log(environment.product);
      });
    console.log(environment.product);
    this.getAllProduct();
  }


  // get product sorted by bandwidth

  getAllProduct() {
    this.products = [];
    let tempproduct = {

    }
    // let tempB = null;
// console.log("hello");


    for (let index = 0; index < this.product.length; index++) {

      if (this.product[index].type == 'Internet') {
        let tempdata = {
          catgory_id: this.product[index].parentCategories[0].repositoryId,
          id: this.product[index].id,
          type: this.product[index].type,
          displayName: this.product[index].displayName,
          salePrice: this.product[index].listPrice,
          bandwidth: this.product[index].x_bANDWIDTH,
          recurrencecost: this.product[index].x_recurrencecost,
          recurrencePeriod: this.product[index].x_recurrencePeriod,
          description: this.product[index].description
        }


        this.products.push(tempdata);
       
        localStorage.setItem('products_internet', JSON.stringify(this.products));
        console.log("hello",this.products); 
      }
    }
  }



  addToCart() {
  
    for (let index = 0; index < this.products.length; index++) {
        let internet = {
          id: this.products[index].id,
          displayName: this.products[index].displayName,
          salePrice: this.products[index].salePrice,
          bandwidth: this.products[index].bandwidth,
          recurrencecost: this.products[index].recurrencecost,
          recurrencePeriod: this.products[index].recurrencePeriod,
        }
        environment.smartbundle_cart.push(internet)
    }
    console.log(environment.smartbundle_cart);
  }
}