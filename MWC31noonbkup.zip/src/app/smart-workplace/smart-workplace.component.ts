import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smart-workplace',
  templateUrl: './smart-workplace.component.html',
  styleUrls: ['./smart-workplace.component.css']
})
export class SmartWorkplaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
