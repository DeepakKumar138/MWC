import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartWorkplaceComponent } from './smart-workplace.component';

describe('SmartWorkplaceComponent', () => {
  let component: SmartWorkplaceComponent;
  let fixture: ComponentFixture<SmartWorkplaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartWorkplaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartWorkplaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
