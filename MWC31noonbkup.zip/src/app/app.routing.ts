import { OrderSummaryComponent } from './new-customer/order-summary/order-summary.component';
import { CustomerQueryComponent } from './new-customer/customer-query/customer-query.component';
import { NewCustomerComponent } from './new-customer/new-customer.component';
import { SignupComponent } from './signup/signup.component';
import { GenerateOtpComponent } from './signup/generate-otp/generate-otp.component';
import { IdentificationComponent } from './signup/identification/identification.component';
import { ProfessionComponent } from './signup/profession/profession.component';
import { EnterpriseDetailsComponent } from './signup/enterprise-details/enterprise-details.component';
import { LoginComponent } from './shared/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MwcLoginComponent } from './shared/mwc-login/mwc-login.component';
import { OnboardedComponent } from './signup/onboarded/onboarded.component';
import { EventComponent } from './pages/event/event.component';
import { Modal1Component } from './pages/modal1/modal1.component';
import { OrderComponent } from './pages/order/order.component';
import { SelectServiceComponent } from './pages/select-service/select-service.component';
import { ProductComponent } from './product/product.component';
import { PersonalizedPageComponent } from './personalized-page/personalized-page.component';
import { ProductEthernetComponent } from './product-ethernet/product-ethernet.component';
import { SmartWorkplaceBundleComponent } from './smart-workplace-bundle/smart-workplace-bundle.component';
import { InfrastructureSecurityProductComponent } from './infrastructure-security-product/infrastructure-security-product.component';
import { ContentForBusinessComponent } from './content-for-business/content-for-business.component';
import { IotSmartWorkplaceComponent } from './iot-smart-workplace/iot-smart-workplace.component';
import { CartSummaryComponent } from './cart-summary/cart-summary.component';
import { DesignYourOwnBundleComponent } from './design-your-own-bundle/design-your-own-bundle.component';
import { DemandsComponent } from './demands/demands.component';
import { VideoOnDemandComponent } from './video-on-demand/video-on-demand.component';
import { SliceAsBundleComponent } from './sliceAsBundle/sliceAsBundle.component';
// import { ProductsComponent } from './new-customer/products/products.component';

export const Approutes: Routes = [
  {
    path: 'mwcLogin', component: MwcLoginComponent
  }, {
    path: '', redirectTo:'newCustomer/customer-query', pathMatch:'full'
  }, {
    path: 'signup',
    component: SignupComponent,
    children: [
      { path: 'enterprise-details', component: EnterpriseDetailsComponent },
      { path: 'profession', component: ProfessionComponent },
      { path: 'identify', component: IdentificationComponent },
      { path: 'generate-otp', component: GenerateOtpComponent },
      { path: 'onboarded', component: OnboardedComponent }
    ]
  }, {
    path: 'newCustomer',
    component: NewCustomerComponent,
    children: [
      {path: '', redirectTo:'newCustomer/customer-query', pathMatch:'full'},
      { path: 'customer-query', component: CustomerQueryComponent },
      { path: 'order-summary', component: OrderSummaryComponent },
      // {path: 'products',component:ProductsComponent}
    ]
  }, {
    path: 'event', component: EventComponent
  }, {
    path: 'map', component: Modal1Component
  }, {
    path: 'order-status', component: OrderComponent
  }, {
    path: 'select-service', component: SelectServiceComponent
  },
  { path: 'internet', component: ProductComponent },
  { path: 'PersonalizedPage', component: PersonalizedPageComponent },
  { path: 'product_ethernet', component: ProductEthernetComponent },
  { path: 'SmartWorkplaceBundle', component: SmartWorkplaceBundleComponent },
  { path: 'infrastructure_product', component: InfrastructureSecurityProductComponent },
  { path: 'ContentForBusiness', component: ContentForBusinessComponent },
  { path: 'iot_smartWork_Place', component: IotSmartWorkplaceComponent },
  { path: 'cart_summary', component: CartSummaryComponent },
  { path: 'design_your_own_bundle', component: DesignYourOwnBundleComponent },
  {path:'demands',component: DemandsComponent},
  {path: 'VoD', component:VideoOnDemandComponent},
  {path: 'dedicated_broadband', component: SliceAsBundleComponent}
];

// @NgModule({
//   imports: [RouterModule.forRoot(Approutes)],
//   exports: [RouterModule]
// })
// export class AppRoutes { }
