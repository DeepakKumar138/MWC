import { Component, ElementRef, OnInit } from '@angular/core';
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServicesService } from '../services/services.service';
import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

cart_total: Number;



  constructor() { }

  ngOnInit() {
    $("script[src='assets/js/menu.js']").remove();



    var dynamicScripts = [
      "assets/js/menu.js",
    ];

    for (var i = 0; i < dynamicScripts.length; i++) {
      let node = document.createElement('script');
      node.src = dynamicScripts[i];
      node.type = 'text/javascript';
      node.async = false;
      node.charset = 'utf-8';
      document.getElementsByTagName('head')[0].appendChild(node);
    }

    this.cart_update();

  }

cart_update(){
  this.cart_total = 0;
  for (let index = 0; index < environment.internet_cart.length; index++) {
    this.cart_total = Number(this.cart_total)+ 1;    
  }

}




}
