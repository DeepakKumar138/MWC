import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery:any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServicesService } from '../services/services.service';
import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
declare var bandwidth:String;

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  bandwidth: number = 10;
  location: number = 10;
  Employees:number= 10;
  contact:number =10;

  options: Options = {
    floor: 10,
    ceil: 1024
  };

  route: string;
  product = new Array;
  repositoryId: string;
  displayName: string;
  salePrice: string;
  
  description: string;
  items = new Array;
  elementRef: ElementRef;
  banner: string;
  product_name: String;


  constructor(private service: ServicesService,
    location: Location,
    private aroute: ActivatedRoute,
    private router: Router,
  ) {
    router.events.subscribe((val) => {
      this.route = location.path();

    });
  }




  ngOnInit() {


    

    // // carousel
    $('.owl-theme').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1000: {
          items: 2
        }
      }
    });
    $('.rightpro-carousel').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
      responsive: {
        0: {
          items: 3
        },
        600: {
          items: 3
        },
        1000: {
          items: 3
        }
      }
    });
    // image gallery
    $(".image-checkbox").each(function () {
      if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
        $(this).addClass('image-checkbox-checked');
      }
      else {
        $(this).removeClass('image-checkbox-checked');
      }
    });

    // sync the state to the input
    $(".image-checkbox").on("click", function (e) {
      $(this).toggleClass('image-checkbox-checked');
      var $checkbox = $(this).find('input[type="checkbox"]');
      $checkbox.prop("checked", !$checkbox.prop("checked"))

      e.preventDefault();
    });


    this.getBannerImage();

    this.getproduct();
  }


  show_product() {
    this.getAllProduct();
    $('#product_carousel').css('display', 'block');
    // console.log(' hlloe '+this.bandwidth);
    

  }

  getBannerImage() {
    this.service.getBannerImages()
      .subscribe((bannerdata) => {

        this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[0].url;
        console.log(' hello' + this.banner);

      });
  }

// get product  form API and store in local
getproduct(){
  let tempproduct = {

    }
    this.service.getProduct()
      .subscribe((data) => {
        console.log(data);
        for (let index = 0; index < data.products.length; index++) {
          environment.product.push(data.products[index]);
          localStorage.setItem('product_internet',JSON.stringify(data.products[index]));
          
        }
      });

    console.log(environment.product);
      
  }


// get product sorted by bandwidth
 
getAllProduct() {
  this.product = [];  
  let tempproduct = {

    }
    // let tempB = null;
    
    
    for (let index = 0; index < environment.product.length; index++) {
    
      if (environment.product[index].type == 'Internet') {
        let tempB = environment.product[index].x_bANDWIDTH.split(' ')
        console.log(tempB[0]);
        console.log(this.bandwidth);

         if (tempB[0] <= this.bandwidth) {
    
        let tempdata = {
          catgory_id: environment.product[index].parentCategories[0].repositoryId,
          id: environment.product[index].id,
          type: environment.product[index].type,
          displayName: environment.product[index].displayName,
          salePrice: environment.product[index].listPrice,
          bandwidth: environment.product[index].x_bANDWIDTH,
          recurrencecost: environment.product[index].x_recurrencecost,
          recurrencePeriod: environment.product[index].x_recurrencePeriod,
          description: environment.product[index].description
        }
   
        
        this.product.push(tempdata);
        this.product.forEach((item, index) => {
          if (index !== this.product.findIndex(i => i.id === item.id)) {
              this.product.splice(index, 1);
          }
          
      });
        tempB = null;
        localStorage.setItem('product_internet', JSON.stringify(this.product));
        }
      }
     
    }

  }
  // getAllProduct() {
  //   let tempproduct = {

  //   }
  //   this.service.getProduct()
  //     .subscribe((data) => {
  //       for (let index = 0; index < data.products.length; index++) {
  //         let tempdata = {
  //           repositoryId: data.products[index].id,
  //           displayName: data.products[index].displayName,
  //           salePrice: data.products[index].salePrice,
  //           description: data.products[index].description

  //         }
  //         this.product.push(tempdata);

  //       }

  //       console.log(this.product);
  //     });
  // }





  // ADD TO CART

  addToCart(id) {
    let p_id = id;
   
    for (let index = 0; index < this.product.length; index++) {
      if (this.product[index].id === p_id) {
        let internet = {
          id: this.product[index].id,
          displayName: this.product[index].displayName,
          salePrice: this.product[index].salePrice,
          bandwidth: this.product[index].bandwidth,
          recurrencecost: this.product[index].recurrencecost,
          recurrencePeriod: this.product[index].recurrencePeriod,

        }
        environment.internet_cart.push(internet)
      }
    }

    console.log(environment.internet_cart);
    // this.router.navigate(['cart_summary/']);

    // console.log(localStorage.getItem('product_internet'));
  }
}
