import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Modal1.Component.TsComponent } from './modal1.component';

describe('Modal1.Component.TsComponent', () => {
  let component: Modal1.Component.TsComponent;
  let fixture: ComponentFixture<Modal1.Component.TsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Modal1.Component.TsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Modal1.Component.TsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
