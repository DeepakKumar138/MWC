/// <reference types="@types/googlemaps" />
import { GoogleMapsAPIWrapper } from '@agm/core';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
declare let google: any;
import { MapsAPILoader } from '@agm/core';
import { ApicallsService } from 'src/app/shared/services/apicalls.service';
import { WindowRefService } from 'src/app/shared/services/window-ref.service';
import * as jwt from 'jsonwebtoken';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-modal1',
  templateUrl: './modal1.component.html',
  styleUrls: ['./modal1.component.css']
})
export class Modal1Component implements OnInit {
    map:any;
  lat: number = 12.8335794;
  lng: number = 77.6449037;
  search: any = "";
  closeResult: string;
  flag = false;
  own: boolean = false;
  ownMarkers: any = [];
  partner: boolean = false;
  trial: boolean = false;
  partnerMarkers: any = [];
  fiveGMarkers: any = [];
  greenicon = "./../../../assets/icons/greenAgmMarker.png";
  blueicon = "./../../../assets/icons/blueAgmMarker.png";
  blackicon = "./../../../assets/icons/blackAgmMarker.png";
  _w: any;
  chatBox: any;

  constructor(private router:Router, private winRef:WindowRefService, private _as:ApicallsService, private modalService: NgbModal,   public gMaps: GoogleMapsAPIWrapper,private mapsAPILoader: MapsAPILoader) {
    navigator.geolocation.getCurrentPosition(this.showPosition);

    ///////////////-chatbot-///////////////////
    this._w = this.winRef.nativeWindow;
    // document.getElementsByTagName('')
  }

  mapabc(){

  console.log("hello");
    window.open(environment.urls.morphUrl+"/ethernet_transport","_self");
  }

  markers: marker[];

protected mapReady(map) {
    this.map = map;
}

ngOnInit(){
  // console.log("child nodes",document.getElementsByTagName("ngb-modal-window")[0].childNodes.length);
  // .childNodes[0]
  
}

getLocation(){
  if(this.flag == true){
    this.flag = false;
  }
  var elem = document.getElementsByTagName("div")[0];
    // elem.setAttribute("style", "max-width:1300px !important;");
  var geocoder = new google.maps.Geocoder();
  console.log("search", this.search);
  var map = this.map;
  var x = this;
   geocoder.geocode( { 'address': this.search}, function(results, status) {
      if (status == 'OK') {
        map.setCenter(results[0].geometry.location);
        x.lat = results[0].geometry.location.lat();
        x.lng = results[0].geometry.location.lng();
        x.markers = [
          {
      
            lat: x.lat,
      
            lng: x.lng
      
          }
        ];
        console.log("lat",results[0].geometry.location.lng());
        if(this.own == true){
          this.changed("own");
        }
        else if(this.partner == true){
          this.changed("partner");
        }
        else{
          this.changed("five");
        }
        // var marker = new google.maps.Marker({
        //     map: map,
        //     position: results[0].geometry.location
        // });

      } else {
        alert('Geocode was not successful for the following reason: ' + status);
      }
    });
}

  showPosition(position) {
    // console.log(position);
    // this.lat = position.coords.latitude;
    // this.lng = position.coords.longitude;
  }

  open(content) {
    console.log(content);
    this.modalService.open(content, { size: 'lg', centered: true });
    var elem = document.getElementsByTagName("div")[0];
    elem.setAttribute("style", "max-width:1050px !important;");
    var elem2 = document.getElementsByTagName("ngb-modal-window")[0];
    elem2.setAttribute("style", "background: rgba(0, 0, 0, 0.4);");
      // console.log("child nodes",document.getElementsByClassName("modal-lg")[0]);

    // this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  changed(value) {
    if (value == "own") {
      this.own = !this.own;
      if(this.own==true){
      this.ownMarkers.push({

        lat: this.lat,

        lng: this.lng

      },{

        lat: this.lat+0.02,

        lng: this.lng+0.01

      },
      {

        lat: this.lat+0.01,

        lng: this.lng+0.02

      },
      {

        lat: this.lat-0.01,

        lng: this.lng-0.01

      },
      {

        lat: this.lat-0.02,

        lng: this.lng-0.01

      });
      }else{
        this.ownMarkers = [];
      }
    }
    else if (value == "partner") {
      this.partner = !this.partner;
      if(this.partner == true){
      this.partnerMarkers.push(
        {

        lat: this.lat-0.02,

        lng: this.lng-0.03

      },
      {

        lat: this.lat-0.03,

        lng: this.lng-0.02

      },
      {

        lat: this.lat+0.02,

        lng: this.lng-0.03

      },
      {

        lat: this.lat-0.02,

        lng: this.lng-0.03

      }
      );
      }else{
        this.partnerMarkers = [];
      }
    }
    else {
      this.trial = !this.trial;
      if (this.trial == true) {
        this.fiveGMarkers.push({

        lat: this.lat+0.013,

        lng: this.lng-0.034

      },
      {

        lat: this.lat-0.021,

        lng: this.lng+0.002

      },
      {

        lat: this.lat-0.027,

        lng: this.lng-0.012

      },
      {

        lat: this.lat+0.017,

        lng: this.lng-0.027

      });
      }else{
        this.fiveGMarkers = [];
      }
    }
  }

  cleanup() {
    [].forEach.call(document.querySelectorAll('.avaamo__chat__widget'), (x) => x.remove());
    [].filter.call(document.querySelectorAll('script'), x => x.src.indexOf('avaamo')!=-1).forEach(x => x.remove());
  }

  requestQuote(){
    this.cleanup();
    var window1 = window.open('http://localhost:8080/documents/20126/0/CPQ-483.pdf', '_blank', 'location=yes,scrollbars=yes,status=yes');
    setTimeout(() => {
      window1.close();
    }, 15000);
  }

  reject_quote() {
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    console.log(user);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "REJECT_QUOTE"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    this._w = this.winRef.nativeWindow;
    console.log(this._w);
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    this._as.getSalesMail().subscribe((data:any)=>{
      console.log(data);
    });

    setTimeout(()=>{
    this._w.Avaamo.openChatBox();
    },2000);
    // document.getElementById('container-fluid').style.filter = 'blur(3px)';
    setTimeout(()=>{
      // document.getElementById('container-fluid').style.filter = 'blur(0px)';
      this._w.Avaamo.closeChatBox();
    },30000);
  }

  accept_quote(){
    console.log("quote accepted now fill address");
    this.router.navigate(['address']);
  }

  takeToCloud(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "CROSS_SELL"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },2000);
   
  }

  

  // silentOnCloud(){
  //   let user = JSON.parse(localStorage.getItem('currentUser'));
  //   // console.log(user);
  //   // console.log(this._w);
  //   let token = jwt.sign({
  //     "uuid": Math.random()*1000,
  //     "FirstName": user.name,
  //     "trigger_reason": "CLOUD_SERVICE_CANCEL"
  //   }, '9e181236-6850-48a8-8807-d8947436ac12');
    
  //   this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
  //   this.chatBox.load();
  //   setTimeout(()=>{
  //     this._w.Avaamo.openChatBox();
  //   },2000);
   
  // }

  proactiveCare(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "IOT_ISSUE"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },2000);
   
  }

  contactMe(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "CONTACT_ME",
      "productName": "Smart workplace bundle"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },2000);
   
  }

  compareProducts(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "COMPARE_OFFER"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },2000);
   
  }

  selectProduct(){
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "SELECT_PRODUCT"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },2000);
   
  }

}

interface marker {
  lat: number;
  lng: number;
}

// "trigger_reason": "CONTACT_ME",
//   "productName": "product name to be passed",