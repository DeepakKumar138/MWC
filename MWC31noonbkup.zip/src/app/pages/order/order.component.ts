import { Component, OnInit } from '@angular/core';
import { ApicallsService } from 'src/app/shared/services/apicalls.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  service="";
  search="";
  chosen='My Orders';
  show = true;
  items = ['My Orders','My payment methods','My invoices','My tickets','My contacts'];
  orders:any = [];
  // orders:any = [
  //   {
  //     "id":"237890",
  //     "status":"IN PROGRESS",
  //     "orderDate":"12/12/2018",
  //     "commitDate":"31/01/2019",
  //     "cReferenceNo":"2389098 -N",
  //     "productDetails":"IP VPN"
  //   },
  //   {
  //     "id":"237891",
  //     "status":"IN PROGRESS",
  //     "orderDate":"14/12/2018",
  //     "commitDate":"31/01/2019",
  //     "cReferenceNo":"1389098 -C",
  //     "productDetails":"ETHERNET HUB & SPOKE"
  //   },
  //   {
  //     "id":"237892",
  //     "status":"DELIVERED",
  //     "orderDate":"16/12/2018",
  //     "commitDate":"31/01/2019",
  //     "cReferenceNo":"1908213 -V",
  //     "productDetails":"Wireless broadband"
  //   },
  //   {
  //     "id":"237893",
  //     "status":"DELIVERED",
  //     "orderDate":"18/12/2018",
  //     "commitDate":"18/12/2018",
  //     "cReferenceNo":"1908213 -V",
  //     "productDetails":"ETHERNET HUB & SPOKE"
  //   }
  // ];



  original:any=[];
  constructor(private _as:ApicallsService) { 
    this._as.getOrders().subscribe((data:any)=>{
      let parser = new DOMParser();
      let res = parser.parseFromString(data.xml,"text/xml");
      let obj={};
       obj["id"] = res.getElementsByTagName("Id")[0].childNodes[0].nodeValue;
       obj["status"] = res.getElementsByTagName("State")[0].childNodes[0].nodeValue;
       obj["orderDate"] = res.getElementsByTagName("CreatedDate")[0].childNodes[0].nodeValue;
       obj["commitDate"] = res.getElementsByTagName("ExpectedOrderCompletionDate")[0].childNodes[0].nodeValue;
       obj["cReferenceNo"] = res.getElementsByTagName("Reference")[0].childNodes[0].nodeValue;
       obj["productDetails"] = res.getElementsByTagName("Name")[0].childNodes[0].nodeValue;
       this.original.push(obj);
       console.log(this.original);
       this.orders = this.original;
    })
  }

  ngOnInit() {
  }

  checkDisabled(order){
    if(order.status == "DELIVERED"){
      return true;
    }
    else{
      return false;
    }
  }

  changed(){
    console.log("value", this.search);
    this.orders = [];
    for(let i=0; i< this.original.length; i++){
      if(this.original[i].id.indexOf(this.search) >= 0){
        this.orders.push(this.original[i]);
      }
      else if(this.original[i].orderDate.indexOf(this.search) >= 0){
        this.orders.push(this.original[i]);
      }
    }
  }

  all(){
    this.orders = [];
    this.orders = this.original;
  }

  chosenone(item){
    this.chosen = item;
    if(item == 'My Orders'){
      this.show = true;
    }
    else{
      this.show = false;
    }
  }
}
