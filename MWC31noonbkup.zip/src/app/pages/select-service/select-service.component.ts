import { Component, OnInit } from '@angular/core';
import { WindowRefService } from '../../shared/services/window-ref.service';
import * as jwt from 'jsonwebtoken';
import { ApicallsService } from 'src/app/shared/services/apicalls.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-select-service',
  templateUrl: './select-service.component.html',
  styleUrls: ['./select-service.component.css']
})
export class SelectServiceComponent implements OnInit {
  chosen:any = "";
  account = "";
  port = "";
  regions = ['US(Texas)','US(west)','Oregon','North-verginia','US(east)'];
  region = "";
  locations = ['New York','Barcelona','Madrid','Dubai','Kolkata'];
  location = "";
  bandwidths = ['200 Mbps','500 Mbps','600 Mbps','900 Mbps','1 Gbps'];
  bandwidth = "";
services:any = [{
  "id":"1",
  "value":"AWS direct connect hosted port"
},
{
  "id":"2",
  "value":"AWS direct connect dedicated port"
},
{
  "id":"3",
  "value":"AWS Business suite"
}];
  _w: any;
  chatBox: any;
  banners: any;
  bannerUrl: any = [];
  constructor(private winRef:WindowRefService,private _as:ApicallsService) {
    this._w = winRef.nativeWindow;
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName":"there",
      "trigger_reason": "CLOUD_SERVICE"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },1000);
    //  setTimeout(()=>{
    //   this._w.Avaamo.closeChatBox();
    //  },10000);

    // avaamo__popup
    console.log("chatbox",this.chatBox);
    this._as.bannerCustomerQuery().subscribe((data:any)=>{
      this.banners = data.webPageAssets.banners;
      console.log(this.banners);
      // for(let i=0;i<this.banners.length;i++){
        this.bannerUrl = [environment.urls.cmsUrl+'/documents/20126/35667/Cloud.png'];
    });
   }

  ngOnInit() {
    console.log(this._w.Avaamo);
  }

  selected(value){
    this.chosen = value;
  }

  next(){
    window.open('http://52.6.121.116/#/internet',"_self");
  }

  cleanup() {
    [].forEach.call(document.querySelectorAll('.avaamo__chat__widget'), (x) => x.remove());
    [].filter.call(document.querySelectorAll('script'), x => x.src.indexOf('avaamo')!=-1).forEach(x => x.remove());
  }

  cancel(){
    this.cleanup();
    
    let user = JSON.parse(localStorage.getItem('currentUser'));
    console.log(user);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": "there",
      "trigger_reason": "CLOUD_SERVICE_CANCEL"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
    this._w.Avaamo.openChatBox();
    },1000);
  }

  ngOnDestroy(){
    if(this._w.Avaamo != 'undefined'){
      this._w.Avaamo.closeChatBox();
    }
    else{
    }
  }
}
