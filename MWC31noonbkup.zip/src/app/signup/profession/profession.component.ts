import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';
import { Url } from 'url';

@Component({
  selector: 'app-profession',
  templateUrl: './profession.component.html',
  styleUrls: ['./profession.component.css']
})
export class ProfessionComponent implements OnInit {
  profession: any = [];
  content: any = 'play-button.png';
  it: any = 'screen.png';
  toggle:boolean=true;
  bank: any = 'bank-building.png';
  data:any = "5000";
  bgColor:any = '#ffffff';
  previousSubscription: any;
  nextSubscription: any;
  currentUser: any;
  constructor(private _stepperService:StepperService, private _as:ApicallsService) { 
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  ngOnInit() {
    this.nextSubscription=this._stepperService.canGoNext$.subscribe(
      () => {
        // alert("subscribe block")
        if(this.next()){
          this._stepperService.goToNextStep();
        }
      }
    );

    // this.previousSubscription=this._stepperService.canGoPrevious$.subscribe(
    //   () => {
    //     if(this.previous()){
    //       this._stepperService.goToPreviousStep();
    //     }
    //   }
    // );
  }

  next(){
    return true;
  }

  // previous(){
  //   return true;
  // }

  Bank(job){
    this.bank = 'bank-building-yellow.png';
    document.getElementById('bank').style.backgroundColor = '#f5cc00';
    this.profession[0] = 'bank';
  }

  IT(){
    this.it = 'screen-yellow.png';
    document.getElementById('it').style.backgroundColor = '#f5cc00';
    this.profession[0] = 'IT';
  }

  Content(){
    this.content = 'play-button-yellow.png';
    document.getElementById('content').style.backgroundColor = '#f5cc00';
    this.profession[0] = 'content';
  }

  Others(){
    document.getElementById('others').style.backgroundColor = '#f5cc00';
    this.profession[0] = 'others';
  }

  value(data){
    console.log(data);
    this.data = data;
    this.profession.push(data);
  }

  ngOnDestroy(){
    console.log(this.profession);
    this._as.setProfession(this.profession);
    // this._as.profession().subscribe((data:any)=>{
    //   console.log(data);
    // })
  }
}
