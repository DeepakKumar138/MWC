import { WindowRefService } from '../../shared/services/window-ref.service';
import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';
import { AccountKit, AuthResponse } from 'ng2-account-kit';
import { Router } from '@angular/router';
import * as jwt from 'jsonwebtoken';

@Component({
  selector: 'app-generate-otp',
  templateUrl: './generate-otp.component.html',
  styleUrls: ['./generate-otp.component.css']
})
export class GenerateOtpComponent implements OnInit {

  otpWindow: Window;
  chatBox: any;
  _w: any;
  mobile: string;
  response: any;
  previousSubscription: any;
  nextSubscription: any;
  user: any;
  otp:any;
  otpvalue: string;
  items: any = [];
  stepperIndex: number;
  disable: boolean;

  constructor(private router: Router, private _as: ApicallsService, private winRef:WindowRefService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this.disable = true;
    this.stepperIndex = 2;
    console.log(this.user);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": "there",
      "trigger_reason": "OTP_F"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    console.log(token);
    this._w = winRef.nativeWindow;
    console.log(this._w);
    // this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    // this.chatBox.load();
    // console.log(this.chatBox);
    
   }

   OTPfromMail(event){
    
     if(event.target.value == '7022'){
      var x = document.getElementById("snackbar");
      x.className = "show";
      setTimeout(function(){ x.className = x.className.replace("show", ""); }, 1000);
      this.disable = false;
      setTimeout(()=>{
        this.router.navigate(['signup/onboarded']);
      },2000);
     }else{
       this.disable = true;
     }
   }

  ngOnInit() {
    setInterval(()=>{
      this.checkwindow();
    },2000);
    this.items=[
      {
        id:1,
        title:"Enterprise details",
        path:"/signup/enterprise-details" 
      },
      // {
      //   id:2,
      //   title:"What you do",
      //   path:"/signup/profession" 
      // },
      {
        id:2,
        title:"Identify yourself",
        path:"/signup/identify" 
      },
      {
        id:3,
        title:"Generate OTP",
        path:"/signup/generate-otp" 
      },
      {
        id:4,
        title:"You are onboarded",
        path:"/signup/onboarded" 
      }
    ];
    // this._stepperService.last.next(false);
    // this._stepperService.disable.next(false);
    if(this.user == null){
      this.mobile = "";
    }else{
    this.mobile = this.user.mobile;
    }
    console.log("init account");
    AccountKit.init({
      appId: "400560070687125",
      state: "testValue",
      version: "v1.0"
    });

    // this.nextSubscription=this._stepperService.canGoNext$.subscribe(
    //   () => {
    //     // alert("subscribe block")
    //     if(this.next()){
    //       this._stepperService.goToNextStep();
    //     }
    //   }
    // );

    // this.otpWindow = window.open("https://www.accountkit.com/v1.0/dialog/sms_login/?app_id=400560070687125&country_code=%2B91&display=popup&fb_app_events_enabled=true&locale=en_US&logging_ref=f23c88634ebf0b8&origin=http%3A%2F%2Flocalhost%3A4200&phone_number="+this.mobile+"&redirect=&sdk=web&state=testValue",'_blank','location=yes,height=700,width=700,scrollbars=yes,status=yes');
    // if(this.otpWindow.closed){
    //   let token = jwt.sign({
    //     "uuid": Math.random()*1000,
    //     "FirstName": this.user.name,
    //     "trigger_reason": "OTP_S"
    //   }, '9e181236-6850-48a8-8807-d8947436ac12');
    //   this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    //   this.chatBox.load();
    // }
    // setTimeout(()=>{
    //   this.otpWindow.close();
    //   // this._w.Avaamo.openChatBox();
    //   // this._w.Avaamo.sendMessage("Invalid OTP");
    // },40000);
    
  }

  getOTPmail(){
    this._as.getAuthOTP().subscribe((data:any)=>{
      console.log(data);
    });
  }

  mail(event){
    if(event.target.value=='1'){
      this.otpvalue = 'mail';
      this._as.getAuthOTP().subscribe((data:any)=>{
        console.log(data);
      });
    }else if(event.target.value=='2'){
      this.otpvalue = 'sms';
    }
  }

  send(){
    if(this.otpvalue=='mail'){
      this.getOTPmail();
    }else if(this.otpvalue=='sms'){
      this.login();
    }else{
      this.login();
    }
  }

  login(): void {
    this.otpWindow = window.open("https://www.accountkit.com/v1.0/dialog/sms_login/?app_id=400560070687125&country_code=%2B91&display=popup&fb_app_events_enabled=true&locale=en_US&logging_ref=f23c88634ebf0b8&origin=http%3A%2F%2Flocalhost%3A4200&phone_number="+this.mobile+"&redirect=&sdk=web&state=testValue",'_blank','location=yes,height=700,width=700,scrollbars=yes,status=yes');
    // AccountKit.login('PHONE', { countryCode: '+91', phoneNumber: '7022710822' });
    // .then(
    //   (response: AuthResponse) =>
    //     console.log(response),
    //   (error: any) => console.error(error)
    // );
    // this._w.Avaamo.openChatBox();
    // this.nextSubscription=this._stepperService.canGoNext$.subscribe(()=>{
    //   this._stepperService.goToNextStep();
    // })

  }

  checkwindow(){
    if(!this.otpWindow){
      console.log("never opened");
    }
    else if(this.otpWindow.closed){
      this.router.navigate(['signup/onboarded']);
    }
  }

  next() {
    this.router.navigate(['signup/onboarded']);
  }

  ngOnDestroy(){
    // this._w.Avaamo.closeChatBox();
  }
}
