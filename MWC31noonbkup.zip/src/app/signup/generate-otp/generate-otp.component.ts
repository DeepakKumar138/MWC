import { WindowRefService } from '../../shared/services/window-ref.service';
import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';
import { AccountKit, AuthResponse } from 'ng2-account-kit';
import { Router } from '@angular/router';
import * as jwt from 'jsonwebtoken';

@Component({
  selector: 'app-generate-otp',
  templateUrl: './generate-otp.component.html',
  styleUrls: ['./generate-otp.component.css']
})
export class GenerateOtpComponent implements OnInit {

  otpWindow: Window;
  chatBox: any;
  _w: any;
  mobile: string;
  response: any;
  previousSubscription: any;
  nextSubscription: any;
  user: any;

  constructor(private _stepperService: StepperService, private router: Router, private _as: ApicallsService, private winRef:WindowRefService) {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    console.log(this.user);
    let token = jwt.sign({
      "uuid": "2112",
      "FirstName": this.user.name,
      "trigger_reason": "OTP_F"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    console.log(token);
    this._w = winRef.nativeWindow;
    console.log(this._w);
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    console.log(this.chatBox);
    
   }

  ngOnInit() {
    
    this.mobile = this._as.getIdentification()[4];
    console.log("init account");
    AccountKit.init({
      appId: "400560070687125",
      state: "testValue",
      version: "v1.0"
    });

    this.nextSubscription=this._stepperService.canGoNext$.subscribe(
      () => {
        // alert("subscribe block")
        if(this.next()){
          this._stepperService.goToNextStep();
        }
      }
    );

    this.otpWindow = window.open("https://www.accountkit.com/v1.0/dialog/sms_login/?app_id=400560070687125&country_code=%2B91&display=popup&fb_app_events_enabled=true&locale=en_US&logging_ref=f23c88634ebf0b8&origin=http%3A%2F%2Flocalhost%3A4200&phone_number="+this.mobile+"&redirect=&sdk=web&state=testValue",'_blank','location=yes,height=700,width=700,scrollbars=yes,status=yes');
    if(this.otpWindow.closed){
      let token = jwt.sign({
        "uuid": "2112",
        "FirstName": this.user.name,
        "trigger_reason": "OTP_S"
      }, '9e181236-6850-48a8-8807-d8947436ac12');
      this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
      this.chatBox.load();
    }
    setTimeout(()=>{
      this.otpWindow.close();
      this._w.Avaamo.openChatBox();
      this._w.Avaamo.sendMessage("Invalid OTP");
    },40000);
    
  }

  login(): void {
    window.open("https://www.accountkit.com/v1.0/dialog/sms_login/?app_id=400560070687125&country_code=%2B91&display=popup&fb_app_events_enabled=true&locale=en_US&logging_ref=f23c88634ebf0b8&origin=http%3A%2F%2Flocalhost%3A4200&phone_number="+this.mobile+"&redirect=&sdk=web&state=testValue",'_blank','location=yes,height=700,width=700,scrollbars=yes,status=yes');
    // AccountKit.login('PHONE', { countryCode: '+91', phoneNumber: '7022710822' });
    // .then(
    //   (response: AuthResponse) =>
    //     console.log(response),
    //   (error: any) => console.error(error)
    // );
    this._w.Avaamo.openChatBox();
    this.nextSubscription=this._stepperService.canGoNext$.subscribe(()=>{
      this._stepperService.goToNextStep();
    })
    this.router.navigate(['signup/onboarded']);
    this.next();
  }

  next() {
    return true;
  }

  ngOnDestroy(){
    this._w.Avaamo.closeChatBox();
  }
}
