import { OnboardedComponent } from './onboarded/onboarded.component';
import { GenerateOtpComponent } from './generate-otp/generate-otp.component';
import { IdentificationComponent } from './identification/identification.component';
import { ProfessionComponent } from './profession/profession.component';
import { SignupComponent } from './signup.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { EnterpriseDetailsComponent } from './enterprise-details/enterprise-details.component';

const routes: Routes = [
    {
        path: 'signup',
        component:SignupComponent,
        children: [ 
            {path: 'enterprise-details', component: EnterpriseDetailsComponent},
            // {path: '', component: EnterpriseDetailsComponent},
            {path: 'profession', component: ProfessionComponent},
            {path: 'identify', component: IdentificationComponent},
            {path: 'generate-otp', component: GenerateOtpComponent},
            {path: 'onboarded', component: OnboardedComponent}
            ]
    }
];

@NgModule({
    exports: [RouterModule,EnterpriseDetailsComponent,ProfessionComponent,
        GenerateOtpComponent,
        IdentificationComponent,
        OnboardedComponent],
    imports: [RouterModule.forChild(routes)]
})
export class SignupRoutingModule { }
