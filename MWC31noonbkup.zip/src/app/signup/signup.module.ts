import { SignupRoutingModule } from './signup.routing';
import { OnboardedComponent } from './onboarded/onboarded.component';
import { IdentificationComponent } from './identification/identification.component';
import { GenerateOtpComponent } from './generate-otp/generate-otp.component';
import { ProfessionComponent } from './profession/profession.component';
import { EnterpriseDetailsComponent } from './enterprise-details/enterprise-details.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StepperService } from '../shared/services/stepper.service';

@NgModule({
    declarations: [
        EnterpriseDetailsComponent,
        ProfessionComponent,
        GenerateOtpComponent,
        IdentificationComponent,
        OnboardedComponent
    ],
    imports: [
        CommonModule,
        SignupRoutingModule
    ],
    exports:[
        CommonModule,
        EnterpriseDetailsComponent,
        ProfessionComponent,
        GenerateOtpComponent,
        IdentificationComponent,
        OnboardedComponent
        
    ],
    providers: [StepperService],
    })

export class SignupModule { }