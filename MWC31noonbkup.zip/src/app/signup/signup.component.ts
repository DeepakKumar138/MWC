import { Component, OnInit } from '@angular/core';
import { StepperService } from '../shared/services/stepper.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  stepperTabs: any = [];
  disable: boolean;
  last:boolean;
  constructor(private _ss:StepperService) {
    
  }

  ngOnInit() {
    // this._ss.setDisable(false);
    // this.disable = this._ss.getDisable();
    // console.log(this._ss.getDisable());
    this.stepperTabs=[
      {
        id:1,
        title:"Enterprise details",
        path:"/signup/enterprise-details" 
      },
      // {
      //   id:2,
      //   title:"What you do",
      //   path:"/signup/profession" 
      // },
      {
        id:2,
        title:"Identify yourself",
        path:"/signup/identify" 
      },
      {
        id:3,
        title:"Generate OTP",
        path:"/signup/generate-otp" 
      },
      {
        id:4,
        title:"You are onboarded",
        path:"/signup/onboarded" 
      }
    ];
  }

}
