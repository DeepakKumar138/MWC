import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  stepperTabs: any = [];
  constructor() { }

  ngOnInit() {
    this.stepperTabs=[
      {
        id:1,
        title:"Enterprise details",
        path:"/signup/enterprise-details" 
      },
      {
        id:2,
        title:"What you do",
        path:"/signup/profession" 
      },
      {
        id:3,
        title:"Identify yourself",
        path:"/signup/identify" 
      },
      {
        id:4,
        title:"Generate OTP",
        path:"/signup/generate-otp" 
      },
      {
        id:5,
        title:"You are onboarded",
        path:"/signup/onboarded" 
      }
    ];
  }

}
