import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';

@Component({
  selector: 'app-onboarded',
  templateUrl: './onboarded.component.html',
  styleUrls: ['./onboarded.component.css']
})
export class OnboardedComponent implements OnInit {

  name: any;
  comment1: any;
  previousSubscription: any;
  nextSubscription: any;
  currentUser: any;
  stepperIndex: number;
  items: any=[];
  constructor(private _stepperService:StepperService, private _as:ApicallsService) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    this.stepperIndex = 3;
    // console.log(this.currentUser.enterpriseName);
    // this._stepperService.last.next(true);
    // this.name = this.currentUser.name;
   }

  ngOnInit() {
    this.items=[
      {
        id:1,
        title:"Enterprise details",
        path:"/signup/enterprise-details" 
      },
      // {
      //   id:2,
      //   title:"What you do",
      //   path:"/signup/profession" 
      // },
      {
        id:2,
        title:"Identify yourself",
        path:"/signup/identify" 
      },
      {
        id:3,
        title:"Generate OTP",
        path:"/signup/generate-otp" 
      },
      {
        id:4,
        title:"You are onboarded",
        path:"/signup/onboarded" 
      }
    ];
    
    // this.nextSubscription=this._stepperService.canGoNext$.subscribe(
    //   () => {
    //     // alert("subscribe block")
    //     if(this.next()){
    //       this._stepperService.goToNextStep();
    //     }
    //   }
    // );

    
  }

  comment(event){
    this.comment1 = event.target.value;
    this._as.setComment(this.comment1);
    // this._as.onboard().subscribe((data:any)=>{
    //   console.log(data);
    // });
    // this._as.enterpriseDetails().subscribe((data:any)=>{
    //   console.log(data);
    // })
  }

  next(){
    this._as.enterpriseDetails().subscribe((data:any)=>{
      console.log(data);
    });
    setTimeout(()=>{
      window.open("http://52.6.121.116/#/SmartWorkplaceBundle","_self");
    },2000); 
  }

  
}