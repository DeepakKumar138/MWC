import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';

@Component({
  selector: 'app-onboarded',
  templateUrl: './onboarded.component.html',
  styleUrls: ['./onboarded.component.css']
})
export class OnboardedComponent implements OnInit {

  name: any;
  comment1: any;
  previousSubscription: any;
  nextSubscription: any;
  constructor(private _stepperService:StepperService, private _as:ApicallsService) {
    this.name = this._as.getIdentification()[0];
   }

  ngOnInit() {
    this.nextSubscription=this._stepperService.canGoNext$.subscribe(
      () => {
        // alert("subscribe block")
        if(this.next()){
          this._stepperService.goToNextStep();
        }
      }
    );

    
  }

  comment(event){
    this.comment1 = event.target.value;
    this._as.setComment(this.comment1);
    this._as.onboard().subscribe((data:any)=>{
      console.log(data);
    });
    this._as.enterpriseDetails().subscribe((data:any)=>{
      console.log(data);
    })
  }

  next(){
    return true;
  }

  
}