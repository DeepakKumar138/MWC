import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-enterprise-details',
  templateUrl: './enterprise-details.component.html',
  styleUrls: ['./enterprise-details.component.css']
})
export class EnterpriseDetailsComponent implements OnInit {

  name:any;
  enterprise_details: any = {};
  country1: any;
  zip1: any;
  city1: any;
  address1: any;
  regNum: any;
  enterpriseName: any;
  previousSubscription: any;
  nextSubscription: any;
  currentUser: any = { "name":"NA","enterpriseName":"NA","city":"NA","numberOfEmployees":"NA","role":"NA","mobile":"NA","email":"NA"};
  items:any = [];
  stepperIndex: number;
  
  constructor(private router:Router, private _as: ApicallsService) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser')); 
    console.log(this.currentUser);
    // this._stepperService.disable.next(false);
    // this._stepperService.last.next(false);
    this.stepperIndex = 0;
   }

  ngOnInit() {
    this.items=[
      {
        id:1,
        title:"Enterprise details",
        path:"/signup/enterprise-details" 
      },
      // {
      //   id:2,
      //   title:"What you do",
      //   path:"/signup/profession" 
      // },
      {
        id:2,
        title:"Identify yourself",
        path:"/signup/identify" 
      },
      {
        id:3,
        title:"Generate OTP",
        path:"/signup/generate-otp" 
      },
      {
        id:4,
        title:"You are onboarded",
        path:"/signup/onboarded" 
      }
    ];
    // this.nextSubscription = this._stepperService.canGoNext$.subscribe(
    //   () => {
    //     // alert("subscribe block")
    //     if (this.next()) {
    //       this._stepperService.goToNextStep();
    //     }
    //   }
    // );

    // this.previousSubscription=this._stepperService.canGoPrevious$.subscribe(
    //   () => {
    //     if(this.previous()){
    //       this._stepperService.goToPreviousStep();
    //     }
    //   }
    // );
  }

  next() {
    
    this.router.navigate(['signup/identify']);
  }

  enterprise_name(event: any) {
    console.log(event.target.value);
    this.enterpriseName = event.target.value;
    this.enterprise_details['enterpriseName']  = this.enterpriseName;
  }
  // reg_num(event) {
  //   this.regNum = event.target.value;
  //   this.enterprise_details.push(this.regNum);
  // }
  address(event) {
    this.address1 = event.target.value;
    this.enterprise_details['address'] = this.address1;
  }
  city(event) {
    this.city1 = event.target.value;
    this.enterprise_details['city'] = this.city1;
  }
  zip(event) {
    this.zip1 = event.target.value;
    this.enterprise_details['zip'] = this.zip1;
  }
  country(event) {
    this.country1 = event.target.value;
    this.enterprise_details['country'] = this.country1;
  }

  ngOnDestroy() {
    console.log(this.enterprise_details);
    this._as.setEnterpriseDetails(this.enterprise_details);
    // this._as.enterprise_details().subscribe((data: any) => {
    //   console.log(data);
    //   if (data != 'success') {
    //     this._as.enterprise_details().subscribe((res: any) => {
    //       console.log(res);
    //     });
    //   }
    // })
  }

}