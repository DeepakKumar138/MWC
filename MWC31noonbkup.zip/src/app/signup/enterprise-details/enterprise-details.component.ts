import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';

@Component({
  selector: 'app-enterprise-details',
  templateUrl: './enterprise-details.component.html',
  styleUrls: ['./enterprise-details.component.css']
})
export class EnterpriseDetailsComponent implements OnInit {

  name:any = "Sam";
  enterprise_details: any = [];
  country1: any;
  zip1: any;
  city1: any;
  address1: any;
  regNum: any;
  enterpriseName: any;
  previousSubscription: any;
  nextSubscription: any;
  currentUser: any;
  constructor(private _stepperService: StepperService, private _as: ApicallsService) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser')); 
   }

  ngOnInit() {
    this.nextSubscription = this._stepperService.canGoNext$.subscribe(
      () => {
        // alert("subscribe block")
        if (this.next()) {
          this._stepperService.goToNextStep();
        }
      }
    );

    // this.previousSubscription=this._stepperService.canGoPrevious$.subscribe(
    //   () => {
    //     if(this.previous()){
    //       this._stepperService.goToPreviousStep();
    //     }
    //   }
    // );
  }

  next() {
    return true;
  }

  enterprise_name(event: any) {
    console.log(event.target.value);
    this.enterpriseName = event.target.value;
    this.enterprise_details.push(this.enterpriseName);
  }
  reg_num(event) {
    this.regNum = event.target.value;
    this.enterprise_details.push(this.regNum);
  }
  address(event) {
    this.address1 = event.target.value;
    this.enterprise_details.push(this.address1);
  }
  city(event) {
    this.city1 = event.target.value;
    this.enterprise_details.push(this.city1);
  }
  zip(event) {
    this.zip1 = event.target.value;
    this.enterprise_details.push(this.zip1);
  }
  country(event) {
    this.country1 = event.target.value;
    this.enterprise_details.push(this.country1);
  }

  ngOnDestroy() {
    console.log(this.enterprise_details);
    this._as.setEnterpriseDetails(this.enterprise_details);
    // this._as.enterprise_details().subscribe((data: any) => {
    //   console.log(data);
    //   if (data != 'success') {
    //     this._as.enterprise_details().subscribe((res: any) => {
    //       console.log(res);
    //     });
    //   }
    // })
  }

}