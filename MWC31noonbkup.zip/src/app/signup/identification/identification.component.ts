import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-identification',
  templateUrl: './identification.component.html',
  styleUrls: ['./identification.component.css']
})
export class IdentificationComponent implements OnInit {

  identify:any = {};
  mobile1: any;
  id1: any;
  role1: any;
  surName1: any;
  firstName1: any;
  previousSubscription: any;
  nextSubscription: any;
  currentUser: any;
  designation1: any;
  disable: boolean = true;
  items: any=[];
  stepperIndex: number;
  email1: any;

  constructor(private router:Router, private _as:ApicallsService) { 
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    // this._stepperService.setDisable(true);
    // console.log(this._stepperService.getDisable());
    // this._stepperService.disable.next(true);
    // this._stepperService.last.next(false);
    this.stepperIndex = 1;
  }

  ngOnInit() {
    this.items=[
      {
        id:1,
        title:"Enterprise details",
        path:"/signup/enterprise-details" 
      },
      // {
      //   id:2,
      //   title:"What you do",
      //   path:"/signup/profession" 
      // },
      {
        id:2,
        title:"Identify yourself",
        path:"/signup/identify" 
      },
      {
        id:3,
        title:"Generate OTP",
        path:"/signup/generate-otp" 
      },
      {
        id:4,
        title:"You are onboarded",
        path:"/signup/onboarded" 
      }
    ];
    // this.nextSubscription=this._stepperService.canGoNext$.subscribe(
    //   () => {
    //     // alert("subscribe block")
    //     if(this.next()){
    //       this._stepperService.goToNextStep();
    //     }
    //   }
    // );

    // this.previousSubscription=this._stepperService.canGoPrevious$.subscribe(
    //   () => {
    //     if(this.previous()){
    //       this._stepperService.goToPreviousStep();
    //     }
    //   }
    // );
  }

  next() {
    this.router.navigate(['signup/generate-otp']);
  }

  firstName(event){
    this.firstName1 = event.target.value;
    this.identify['firstName'] = this.firstName1;
  }
  surName(event){
    this.surName1 = event.target.value;
    this.identify['surName'] = this.surName1;
  }
  role(event){
    this.role1 = event.target.value;
    this.identify['role'] = this.role1;
  }

  email(event){
    this.email1 = event.target.value;
    this.identify['email'] = this.email1;
  }
  
  id(event) {
    this.id1 = event.target.value;
    this.identify['id'] = this.id1;
    document.getElementById("checkbox2").style.display = 'block';
    document.getElementById("checkbox").style.display = 'none';
    document.getElementById("checkbox1").style.display = 'none';
    
    if (this.id1 == "12345") {

      setTimeout(() => {
        this.disable = false;
        document.getElementById("checkbox2").style.display = 'none';
        document.getElementById("checkbox").style.display = 'block';
        document.getElementById("checkbox1").style.display = 'none';
      }, 5000);
    }else{
      // this._stepperService.disable.next(true);
      setTimeout(() => {
        document.getElementById("checkbox2").style.display = 'none';
        document.getElementById("checkbox").style.display = 'none';
        document.getElementById("checkbox1").style.display = 'block';
      }, 5000);
    }
  }
  mobile(event){
    this.mobile1 = event.target.value;
    this.identify['mobile'] = this.mobile1;
  }
  designation(event){
    this.designation1 = event.target.value;
    this.identify['designation'] = this.designation1;
  }

  ngOnDestroy(){
    console.log(this.identify);
    this._as.setIdentification(this.identify);
    // this._as.identify().subscribe((data:any)=>{
    //   console.log(data);
    // })
  }
}