import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit } from '@angular/core';
import { StepperService } from '../../shared/services/stepper.service';

@Component({
  selector: 'app-identification',
  templateUrl: './identification.component.html',
  styleUrls: ['./identification.component.css']
})
export class IdentificationComponent implements OnInit {

  identify:any = [];
  mobile1: any;
  id1: any;
  role1: any;
  surName1: any;
  firstName1: any;
  previousSubscription: any;
  nextSubscription: any;
  currentUser: any;
  constructor(private _stepperService:StepperService, private _as:ApicallsService) { 
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  ngOnInit() {
    this.nextSubscription=this._stepperService.canGoNext$.subscribe(
      () => {
        // alert("subscribe block")
        if(this.next()){
          this._stepperService.goToNextStep();
        }
      }
    );

    // this.previousSubscription=this._stepperService.canGoPrevious$.subscribe(
    //   () => {
    //     if(this.previous()){
    //       this._stepperService.goToPreviousStep();
    //     }
    //   }
    // );
  }

  next(){
    return true;
  }

  firstName(event){
    this.firstName1 = event.target.value;
    this.identify.push(this.firstName1);
  }
  surName(event){
    this.surName1 = event.target.value;
    this.identify.push(this.surName1);
  }
  role(event){
    this.role1 = event.target.value;
    this.identify.push(this.role1);
  }
  id(event){
    this.id1 = event.target.value;
    this.identify.push(this.id1);
  }
  mobile(event){
    this.mobile1 = event.target.value;
    this.identify.push(this.mobile1);
  }

  ngOnDestroy(){
    console.log(this.identify);
    this._as.setIdentification(this.identify);
    // this._as.identify().subscribe((data:any)=>{
    //   console.log(data);
    // })
  }
}