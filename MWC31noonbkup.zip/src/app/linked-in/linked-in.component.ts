import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-linked-in',
  templateUrl: './linked-in.component.html',
  styleUrls: ['./linked-in.component.css']
})
export class LinkedInComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
