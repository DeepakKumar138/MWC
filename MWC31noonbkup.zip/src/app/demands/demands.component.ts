import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { WindowRefService } from 'src/app/shared/services/window-ref.service';
import * as jwt from 'jsonwebtoken';

@Component({
  selector: 'app-demands',
  templateUrl: './demands.component.html',
  styleUrls: ['./demands.component.css']
})
export class DemandsComponent implements OnInit {

  _w: any;
  chatBox: any;

  constructor(private router:Router,private winRef:WindowRefService) { 
    this._w = this.winRef.nativeWindow;
  }

  ngOnInit() {
    this.get5g();
  }

  cleanup() {
    [].forEach.call(document.querySelectorAll('.avaamo__chat__widget'), (x) => x.remove());
    [].filter.call(document.querySelectorAll('script'), x => x.src.indexOf('avaamo')!=-1).forEach(x => x.remove());
  }

  get5g(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "PRODUCT_5G"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },4000);
   
  }

  getProductsDet(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "SELECT_PRODUCT"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },3000);
   
  }

  dedicated_broadband(){
    window.open(environment.urls.morphUrl+"/product_broadband");
  }

  video(){
    window.open(environment.urls.morphUrl+"/video-on-demand");
  }

  smart(){
    this.router.navigate(['smart']);
  }
}
