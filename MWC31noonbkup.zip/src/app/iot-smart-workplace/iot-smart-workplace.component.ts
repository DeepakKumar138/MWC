import { Component,ElementRef, OnInit } from '@angular/core';
declare var $: any;
import {OwlCarousel} from 'ngx-owl-carousel';
import { ServicesService } from '../services/services.service';
import { Product } from '../model/product'

@Component({
  selector: 'app-iot-smart-workplace',
  templateUrl: './iot-smart-workplace.component.html',
  styleUrls: ['./iot-smart-workplace.component.css']
})
export class IotSmartWorkplaceComponent implements OnInit {

  constructor(private service: ServicesService) { }

  ngOnInit() {
  	// image gallery
			// init the state from the input
			$(".image-checkbox").each(function () {
			  if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
			    $(this).addClass('image-checkbox-checked');
			  }
			  else {
			    $(this).removeClass('image-checkbox-checked');
			  }
			});

			// sync the state to the input
			$(".image-checkbox").on("click", function (e) {
			  $(this).toggleClass('image-checkbox-checked');
			  var $checkbox = $(this).find('input[type="checkbox"]');
			  $checkbox.prop("checked",!$checkbox.prop("checked"))

			  e.preventDefault();
      });
      
      // (function () {

		  //   var selector = '[data-rangeSlider]',
		  //     elements = document.querySelectorAll(selector);
		  //   // Basic rangeSlider initialization
		  //   rangeSlider.create(elements, {

		  //     // Callback function
		  //     onInit: function () {
		  //     },

		  //     // Callback function
		  //     onSlideStart: function (value, percent, position) {
		  //       console.info('onSlideStart', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
		  //     },

		  //     // Callback function
		  //     onSlide: function (value, percent, position) {
		  //       console.log('onSlide', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
		  //     },

		  //     // Callback function
		  //     onSlideEnd: function (value, percent, position) {
		  //       console.warn('onSlideEnd', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
		  //     }
		  //   });
      // })();
      

      $('.fitment-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
         navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:2
            }
        }
    })

    $('.rightpro-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
         navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:3
            }
        }
    })
  
  
  }

}
