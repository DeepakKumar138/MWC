import { Component, OnInit } from '@angular/core';
import { ServicesService } from '../services/services.service';
import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';

@Component({
  selector: 'app-cart-summary',
  templateUrl: './cart-summary.component.html',
  styleUrls: ['./cart-summary.component.css']
})
export class CartSummaryComponent implements OnInit {
  banner: String;
  cart_array = new Array;
  monthly_cost_total: Number;
  one_time_cost_total: Number;
  display_name = new Array;
  cart_status: boolean;
  s_one_time_cost_total:number;
  s_monthly_cost_total:Number;
  constructor(private service: ServicesService,
    private location: Location,
    private aroute: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.getBannerImage();
    this.getInternetCart();
    this.getSmratCart();
  }

  // get banner image

  getBannerImage() {
    this.service.getBannerImages()
      .subscribe((bannerdata) => {
        console.log(bannerdata);

        this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[6].url;
        console.log(' hello' + this.banner);

      });
  }
  //get product image
  getInternetCart() {
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;
    this.cart_status = true;

    for (let index = 0; index < environment.internet_cart.length; index++) {
      this.display_name.push(environment.internet_cart[index])

      this.monthly_cost_total += (environment.internet_cart[index].recurrencecost);
      this.one_time_cost_total += environment.internet_cart[index].salePrice;
      this.cart_status = false;
    }

    // console.log(this.display_name);
    // console.log(this.monthly_cost_total);
    // console.log(this.one_time_cost_total);



  }
  getSmratCart() {
    this.s_monthly_cost_total = 0;
    this.s_one_time_cost_total = 0;
    this.cart_status = true;

    for (let index = 0; index < environment.smartbundle_cart.length; index++) {
      this.s_monthly_cost_total += (environment.smartbundle_cart[index].recurrencecost);
      this.s_one_time_cost_total += environment.smartbundle_cart[index].salePrice;
      this.cart_status = false;
    }

}
}
