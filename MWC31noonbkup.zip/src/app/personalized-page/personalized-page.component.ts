import { Component, OnInit } from '@angular/core';
import { ServicesService } from '../services/services.service';
import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';

@Component({
  selector: 'app-personalized-page',
  templateUrl: './personalized-page.component.html',
  styleUrls: ['./personalized-page.component.css']
})
export class PersonalizedPageComponent implements OnInit {
  banner:String;

  constructor(private service: ServicesService,
    private location: Location,
    private aroute: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.getBannerImage();
  
  }

  
getBannerImage() {
  this.service.getBannerImages()
    .subscribe((bannerdata) => {
      console.log(bannerdata);
      
      this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[1].url;
      console.log(' hello' + this.banner);

    });
}

}
