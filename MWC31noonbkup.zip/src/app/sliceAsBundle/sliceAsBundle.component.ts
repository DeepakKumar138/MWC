import { Component, OnInit } from '@angular/core';
import { ApicallsService } from './../shared/services/apicalls.service';
import { environment } from 'src/environments/environment';
import { Cookie } from 'ng2-cookies/ng2-cookies';

@Component({
  selector: 'app-sliceAsBundle',
  templateUrl: './sliceAsBundle.component.html',
  styleUrls: ['./sliceAsBundle.component.css']
})
export class SliceAsBundleComponent implements OnInit {
  bannerUrl: any = [];
  banners: any = [];
  monthly_total:any = "1799";
  welcome = "Welcome to our";
  marketplace = "marketplace";
  flag: boolean = false;
  constructor(private _as:ApicallsService) { 
    this._as.bannerCustomerQuery().subscribe((data:any)=>{
      this.banners = data.webPageAssets.banners;
      console.log(this.banners);
      // for(let i=0;i<this.banners.length;i++){
        this.bannerUrl = [environment.urls.cmsUrl+'/documents/20126/35667/Banner---Customer-Query.jpg'];
        this.flag=true;
        // this.bannerUrl.push(environment.urls.cmsUrl+this.banners[9].url);
        // this.secondBannerUrl.push(environment.urls.cmsUrl+this.banners[7].url);
      // }
    })
  }

  ngOnInit() {
    
    
    // console.log(JSON.parse(localStorage.getItem('product_internet')));
  }

  connected(){
    window.open("http://52.6.121.116/#/iot_smartWork_Place","_self");
  }

  secured(){
    window.open("http://52.6.121.116/#/infrastructure_product","_self");
  }

  doRoute(path){
    window.open(environment.urls.morphUrl+path,"_self");
  }
}
