import { Component, OnInit } from '@angular/core';
import { ApicallsService } from './../shared/services/apicalls.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-sliceAsBundle',
  templateUrl: './sliceAsBundle.component.html',
  styleUrls: ['./sliceAsBundle.component.css']
})
export class SliceAsBundleComponent implements OnInit {
  bannerUrl: any = [];
  banners: any = [];
  monthly_total:any = "0";
  welcome = "Welcome to our";
  marketplace = "marketplace";
  constructor(private _as:ApicallsService) { 
    this._as.bannerCustomerQuery().subscribe((data:any)=>{
      this.banners = data.webPageAssets.banners;
      console.log(this.banners);
      // for(let i=0;i<this.banners.length;i++){
        this.bannerUrl.push(environment.urls.cmsUrl+this.banners[11].url);
        this.bannerUrl.push(environment.urls.cmsUrl+this.banners[9].url);
        // this.secondBannerUrl.push(environment.urls.cmsUrl+this.banners[7].url);
      // }
    })
  }

  ngOnInit() {
  }

}
