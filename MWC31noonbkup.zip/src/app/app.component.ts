import { Component } from '@angular/core';
import { ServicesService } from './services/services.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'marketpalce';


  constructor(private service: ServicesService) { }


  ngOnit() {
    this.getproduct();


  }
   
  getproduct(){
  let tempproduct = {

    }
    this.service.getProduct()
      .subscribe((data) => {
        environment.product = data.product;
      });

      console.log(environment.product);
      
  }
}
