import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { map } from 'rxjs/operators';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  once: any;

  constructor(private http: Http) { }


  setvalue(val){
    console.log("val is ", val);
    this.once = val;
  }

  // get All Product
  getProduct() {
    //  headers = new Headers();
    let headers = new Headers({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT,DELETE',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': '' + environment.token,
      'X-CCAsset-Language': 'en-US'
    });

    return this.http.get('http://52.5.252.249:3000/getProducts', { headers: headers })
      .pipe(map(res => res.json()));

  }



  // get banner images
  getBannerImages() {
    return this.http.get('http://52.5.252.249:8080/o/CMSTelecomDemo/v1/webPageAssets/Banners')
    .pipe(map(res => res.json()));
    
  }
}


