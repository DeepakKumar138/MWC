import { Component,ElementRef, OnInit } from '@angular/core';
declare var $: any;
import {OwlCarousel} from 'ngx-owl-carousel';
import { ServicesService } from '../services/services.service';

@Component({
  selector: 'app-design-your-own-bundle',
  templateUrl: './design-your-own-bundle.component.html',
  styleUrls: ['./design-your-own-bundle.component.css']
})
export class DesignYourOwnBundleComponent implements OnInit {

  constructor(private service: ServicesService) { }

  ngOnInit() {

    // (function () {

	  //   var selector = '[data-rangeSlider]',
	  //     elements = document.querySelectorAll(selector);
	  //   // Basic rangeSlider initialization
	  //   rangeSlider.create(elements, {

	  //     // Callback function
	  //     onInit: function () {
	  //     },

	  //     // Callback function
	  //     onSlideStart: function (value, percent, position) {
	  //       console.info('onSlideStart', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
	  //     },

	  //     // Callback function
	  //     onSlide: function (value, percent, position) {
	  //       console.log('onSlide', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
	  //     },

	  //     // Callback function
	  //     onSlideEnd: function (value, percent, position) {
	  //       console.warn('onSlideEnd', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
	  //     }
	  //   });
    // })();
    

    $('.design-carousel').owlCarousel({
      loop:true,
      margin:10,
      nav:true,
       navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
      responsive:{
          0:{
              items:1
          },
          600:{
              items:2
          },
          1000:{
              items:3
          }
      }
  })

  // image gallery
  $(".image-checkbox").each(function () {
    if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
      $(this).addClass('image-checkbox-checked');
    }
    else {
      $(this).removeClass('image-checkbox-checked');
    }
  });

  // sync the state to the input
  $(".image-checkbox").on("click", function (e) {
    $(this).toggleClass('image-checkbox-checked');
    var $checkbox = $(this).find('input[type="checkbox"]');
    $checkbox.prop("checked",!$checkbox.prop("checked"))

    e.preventDefault();
  });

  function showlocation2()
  {
    $("#location2").removeClass("eht_hidelocation");
    $("#button1").removeClass("active");

    $("#location1").addClass("eht_hidelocation");
    $("#button2").addClass("active");
  }
  function showlocation1()
  {
    $("#location1").removeClass("eht_hidelocation");
    $("#button2").removeClass("active");

    $("#location2").addClass("eht_hidelocation");
    $("#button1").addClass("active");
  }
  }

}
