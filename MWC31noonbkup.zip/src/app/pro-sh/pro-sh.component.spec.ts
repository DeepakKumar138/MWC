import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProShComponent } from './pro-sh.component';

describe('ProShComponent', () => {
  let component: ProShComponent;
  let fixture: ComponentFixture<ProShComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProShComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProShComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
