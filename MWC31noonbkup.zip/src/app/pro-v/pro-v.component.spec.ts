import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProVComponent } from './pro-v.component';

describe('ProVComponent', () => {
  let component: ProVComponent;
  let fixture: ComponentFixture<ProVComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProVComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProVComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
