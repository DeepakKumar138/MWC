import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-pro-v',
  templateUrl: './pro-v.component.html',
  styleUrls: ['./pro-v.component.css']
})
export class ProVComponent implements OnInit {
  constructor() { }

  ngOnInit() {
    // (function () {

    //   var selector = '[data-rangeSlider]',
    //     elements = document.querySelectorAll(selector);
    //   // Basic rangeSlider initialization
    //   rangeSlider.create(elements, {
  
    //     // Callback function
    //     onInit: function () {
    //     },
  
    //     // Callback function
    //     onSlideStart: function (value, percent, position) {
    //       console.info('onSlideStart', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
    //     },
  
    //     // Callback function
    //     onSlide: function (value, percent, position) {
    //       console.log('onSlide', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
    //     },
  
    //     // Callback function
    //     onSlideEnd: function (value, percent, position) {
    //       console.warn('onSlideEnd', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
    //     }
    //   });
    // })();
   
   
    $('.fitment-carousel').owlCarousel({
      loop:true,
      margin:10,
      nav:true,
       navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
      responsive:{
          0:{
              items:1
          },
          600:{
              items:2
          },
          1000:{
              items:2
          }
      }
  })
    
  }

}
