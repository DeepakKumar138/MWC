import { Component, OnInit, Input } from '@angular/core';
declare var $: any;
import { ApicallsService } from 'src/app/shared/services/apicalls.service';
import { Router,NavigationEnd } from '@angular/router';
import { environment } from '../../../environments/environment';
// import { Product } from '../model/product'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { log } from 'util';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  @Input() home:boolean = true;
  cart_total: Number = 0;
  //cart_counter
  cart_counter : any;


constructor(private router: Router) { }

home1(){
  window.open('http://52.6.121.116/#','_self');
}

smartcity(){
  window.open('https://www.google.com','_self');
}

ngOnInit() {

  this.router.events.subscribe((evt) => {
    if (!(evt instanceof NavigationEnd)) {
        return;
    }
    window.scrollTo(0, 0)
});
  $("script[src='assets/js/menu.js']").remove();

  let tempproduct = {

  }
  let temp_product = JSON.parse(localStorage.getItem('smart_bunddle_cart'));

  if(temp_product!=null){
    this.cart_total=1;
  }else{
    this.cart_total=0;
  }

  // console.log('temp', JSON.parse(localStorage.getItem('smart_bunddle_cart'))); 
  // this.cart_counter=temp_product.length;
  // console.log('temp length', temp_product.length); 

 

  var dynamicScripts = [
    "assets/js/menu.js",
  ];

  for (var i = 0; i < dynamicScripts.length; i++) {
    let node = document.createElement('script');
    node.src = dynamicScripts[i];
    node.type = 'text/javascript';
    node.async = false;
    node.charset = 'utf-8';
    document.getElementsByTagName('head')[0].appendChild(node);
  }

  // this.cart_update();

}

doRoute(path){
  window.open(environment.urls.morphUrl+path,"_self");
}

doRouteinner(path){
  this.router.navigate([path]);
}

intelligent(){
  window.open('http://125.18.12.68:8080/Barcelona_POC/');
}

fleet(){
  window.open('http://125.18.12.68:8080/SmartBus');
}

ot(){
  window.open('http://125.18.12.69:8080/wd/login.jsf');
}

// cart_update(){
//   this.cart_total = 0;

//   for (let index = 0; index < environment.internet_cart.length; index++) {
//     this.cart_total = Number(this.cart_total)+ 1;    
//   }
// }


}
