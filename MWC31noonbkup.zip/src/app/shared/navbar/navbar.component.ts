import { Component, OnInit } from '@angular/core';
import { ApicallsService } from 'src/app/shared/services/apicalls.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  navbar: any;

  constructor(private _as:ApicallsService, private router:Router) {
    this._as.getMenu().subscribe((data:any)=>{
      console.log(data[0].menu);
      this.navbar = data[0].menu;
    })
   }

  ngOnInit() {
  }

  hovering(){
    document.getElementById("dropdown-submenu").style.color = "#f5cc00";
  }

  navigate(event){
    console.log(event);
    this.router.navigate([event]);
  }

  home(){
    this.router.navigate(['newCustomer/customer-query']);
  }
}
