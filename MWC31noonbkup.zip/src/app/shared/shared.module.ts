import { StepperService } from './services/stepper.service';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { MwcLoginComponent } from './mwc-login/mwc-login.component';
import { StepperComponent } from './stepper/stepper.component';
import { NavbarComponent } from './navbar/navbar.component';

@NgModule({
  imports: [
    CommonModule,RouterModule
  ],
  declarations: [LoginComponent, MwcLoginComponent, StepperComponent, NavbarComponent],
  exports: [LoginComponent, MwcLoginComponent,StepperComponent,NavbarComponent],
  providers:[StepperService]
})
export class SharedModule { }
