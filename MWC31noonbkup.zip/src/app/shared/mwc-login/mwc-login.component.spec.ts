import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MwcLoginComponent } from './mwc-login.component';

describe('MwcLoginComponent', () => {
  let component: MwcLoginComponent;
  let fixture: ComponentFixture<MwcLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MwcLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MwcLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
