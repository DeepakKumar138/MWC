import { WindowRefService } from '../services/window-ref.service';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { AccountKit, AuthResponse } from 'ng2-account-kit';
import * as jwt from 'jsonwebtoken';
import { ApicallsService } from 'src/app/shared/services/apicalls.service';

@Component({
  selector: 'app-mwc-login',
  templateUrl: './mwc-login.component.html',
  styleUrls: ['./mwc-login.component.css']
})
export class MwcLoginComponent implements OnInit {

  disable:boolean = true;
  password: any;
  name: any;
  _w: any;
  chatBox: any;
  otpWindow: Window;
  mobile: string;
  constructor(private auth:AuthService, private router:Router, private winRef:WindowRefService, private _as:ApicallsService) { 
    let user = JSON.parse(localStorage.getItem('currentUser'));
    console.log(user);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "PASSWORD_F"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    console.log(token);
    this._w = winRef.nativeWindow;
    console.log(this._w);
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    // avaamo__popup
    console.log("chatbox",this.chatBox);
  }

  ngOnInit() {

    AccountKit.init({
      appId: "400560070687125",
      state: "testValue",
      version: "v1.0"
    });
    
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
      this._w.Avaamo.sendMessage("Invalid password");
        var elem = document.getElementsByClassName("avaamo__popup")[0];
    elem.setAttribute("style", "width:300px !important; height:400px !important");
    },30000);
  }

  signInWithGoogle(){
    this.auth.signInWithGoogle();
    window.open("http://52.6.121.116/existing_user");
    
  }

  inputName(event){
    this.name = event;
    // if(this.name=='rapids'||this.name=='wipro'){
    //   this.disable = false;
    // }
  }

  inputPassword(event){
    this.password = event;
  }

  ngOnDestroy(){
    this._w.Avaamo.closeChatBox();
  }

}
