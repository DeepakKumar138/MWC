import { Component, OnInit, Input,EventEmitter,Output } from '@angular/core';
import { StepperService } from '../services/stepper.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.css']
})
export class StepperComponent implements OnInit {
  // isLast: boolean = false;
  @Input('stepperTabs')  items:any;
  @Input('disable')  disable:boolean;
  @Input('last') isLast:boolean;
 
  optionsSelect: Array<any>;
  stepperIndex=0;
  callBackServiceNext:any;
  callBackServicePrevious:any;
  constructor(private _stepperService: StepperService, private _router:Router) {
    
   }

  ngOnInit() {
    this._stepperService.last.subscribe((data:any)=>{
      console.log(data);
      this.isLast = data;
    })
    this._stepperService.disable.subscribe((data:any)=>{
      console.log(data);
      this.disable = data;
    })
    this._router.navigate([this.items[0].path]);
    this.callBackServiceNext=this._stepperService.callNext$.subscribe(
      () => {

         if((this.items.length-1)>this.stepperIndex){
          
          // console.log(this.items[this.stepperIndex]);
          // console.log(this.items.length);
          this._router.navigate([this.items[this.stepperIndex].path]);
        }
        else if(this.stepperIndex==3){
          console.log("last");
          
          // alert("reached End");
        }
      }
    );
    // this.callBackServicePrevious=this._stepperService.callPrevious$.subscribe(
    //   () => {
    //     if(this.stepperIndex>0){
    //       this.stepperIndex-=1;
    //       console.log(this.items[this.stepperIndex])
    //       this._router.navigate([this.items[this.stepperIndex].path]);
    //     }
    //     else{
    //       // alert("reached End");
    //     }
        
    //   }
    // );
  
  }

  ngOnDestroy() {
    this.callBackServiceNext.unsubscribe();
    // this.callBackServicePrevious.unsubscribe()
  }

  onNext():void{
    this._stepperService.initiateNext();
    this.stepperIndex++;
    this._router.navigate([this.items[this.stepperIndex].path]);
  }

  // onPrevious():void{
  //   this._stepperService.initiatePrevious();
  // }

  Submit(){
    window.open(environment.urls.morphUrl+"/SmartWorkplaceBundle","_self");
  }

 
}
