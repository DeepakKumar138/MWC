import { environment } from '../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApicallsService {

  token: any;
  customerQuery1: any;
  comment: any;
  identification: any;
  profession_details: any;
  data: any;
  constructor(private http: HttpClient) { }

  setAccess(data){
    this.token = data;
  }

  setEnterpriseDetails(data) {
    this.data = data;
    console.log(data);
  }

  setProfession(profession) {
    this.profession_details = profession;
  }

  setIdentification(data) {
    this.identification = data;
  }

  getIdentification() {
    return this.identification;
  }

  setComment(data) {
    this.comment = data;
  }

  setCustomerQuery(data) {
    console.log(data);
    this.customerQuery1 = data;
  }

  enterpriseDetails(){
    let body = {
      "enterpriseName": this.data[0],
      "registrationNumber": this.data[1],
      "address": this.data[2],
      "city": this.data[3],
      "zip": this.data[4],
      "country": this.data[5],
      "businessNature": this.profession_details[0],
      "numberOfEmployees": this.profession_details[1],
      "firstName": this.identification[0],
      "surName": this.identification[1],
      "role": this.identification[2],
      "id": this.identification[3],
      "mobile": this.identification[4]
    }

    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    return this.http.post(environment.urls.nodeBackend + "/signup/enterpriseDetails", body, options);
  }

  onboard() {
    let body = {
      "comments": this.comment
    }
    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    return this.http.post(environment.urls.nodeBackend + "/signup/onboarded", body, options);
  }

  customerQuery() {
    let body = {
      "purpose": this.customerQuery1[0],
      "businessType": this.customerQuery1[1],
      "noOfLocations": this.customerQuery1[2],
      "numberOfEmployees": this.customerQuery1[3],
      "firstName": this.customerQuery1[4],
      "enterpriseName": this.customerQuery1[6],
      "email": this.customerQuery1[5],
      "city": this.customerQuery1[7],
      "mobile":this.customerQuery1[8]
    }
    const options = {
      headers:
        {
          'content-type': 'application/json'
        }
    };
    localStorage.setItem('currentUser', JSON.stringify({ name:this.customerQuery1[4],enterpriseName:this.customerQuery1[6],city:this.customerQuery1[7],numberOfEmployees:this.customerQuery1[3] }));
    return this.http.post(environment.urls.nodeBackend + "/newCustomer/customer-query", body, options);
  }

  

  bannerCustomerQuery() {
    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    return this.http.get(environment.urls.cmsUrl + "/o/CMSTelecomDemo/v1/webPageAssets/Banners", options);
    // return this.http.get("./../assets/banners.json");
  }

  secondBannerCustomerQuery() {
    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    // return this.http.get(environment.urls.cmsUrl + "/o/CMSTelecomDemo/v1/webPageAssets/SecondaryBanners", options);
    return this.http.get("./../assets/banners.json");
  }

  postAccount() {
    const options = {
      headers:
        {
          'content-type': 'application/json'
        }
    };
    return this.http.post(environment.urls.nodeBackend+"/postAccount",options);
  }

  createOpportunity(){
    const options = {
      headers:
        {
          'content-type': 'application/json'
        }
    }; 
    return this.http.post(environment.urls.nodeBackend+"/postOpportunity",options);
  }

  getProducts(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.get(environment.urls.nodeBackend+"/getProducts",options);
  }

  getLogin(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.post(environment.urls.nodeBackend+"/login",options);
  }

  getOpportunity(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.get(environment.urls.nodeBackend+"/getOpportunity",options);
  }

  recommendations(){
    return this.http.get('./../../assets/recommendations.json');
  }

  getMail(){
    return this.http.get(environment.urls.nodeBackend+"/mail");
  }

  getMenu(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.get(environment.urls.nodeBackend+"/menu",options);
  }

  getSalesMail(){
    return this.http.get(environment.urls.nodeBackend+"/getSalesMail");
  }

  getOrders(){
    return this.http.get(environment.urls.nodeBackend+"/orders");
  }

  getWhatsApp(){
    return this.http.get(environment.urls.nodeBackend+"/whatsapp");
  }
}
