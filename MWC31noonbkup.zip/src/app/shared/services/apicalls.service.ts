import { environment } from '../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApicallsService {

  token: any;
  customerQuery1: any;
  comment: any;
  identification: any;
  profession_details: any;
  data: any;
  banners: any;
  body: {
  "enterpriseName": any; "address": any; "city": any; "zip": any; "country": any;
    // "businessNature": this.profession_details[0],
    // "numberOfEmployees": this.profession_details[1],
    "firstName": any; "surName": any; "role": any; "id": any; "mobile": any; "designation": any;
  };
  constructor(private http: HttpClient) { }

  setAccess(data){
    this.token = data;
  }

  setEnterpriseDetails(data) {
    this.data = data;
    console.log(data);
  }

  setProfession(profession) {
    this.profession_details = profession;
  }

  setIdentification(data) {
    console.log(data);
    this.identification = data;
  }

  getIdentification() {
    return this.identification;
  }

  setComment(data) {
    this.comment = data;
  }

  setCustomerQuery(data) {
    console.log(data);
    this.customerQuery1 = data;
  }

  enterpriseDetails(){
    if(this.customerQuery1!=null){
    this.body = {
      "enterpriseName": this.customerQuery1.enterpriseName,
      "address": this.data.address,
      "city": this.customerQuery1.city,
      "zip": this.data.zip,
      "country": this.data.country,
      // "businessNature": this.profession_details[0],
      // "numberOfEmployees": this.profession_details[1],
      "firstName": this.customerQuery1.firstName,
      "surName": this.identification.surName,
      "role":this.customerQuery1.role,
      "id": this.identification.id,
      "mobile":this.customerQuery1.mobile,
      "designation":this.identification.designation
    }
  }else if(this.customerQuery1==null){
    this.body = {
      "enterpriseName": "",
      "address": this.data.address,
      "city": "",
      "zip": this.data.zip,
      "country": this.data.country,
      // "businessNature": this.profession_details[0],
      // "numberOfEmployees": this.profession_details[1],
      "firstName": "",
      "surName": this.identification.surName,
      "role":"",
      "id": this.identification.id,
      "mobile":"",
      "designation":this.identification.designation
    }
  }else{
    this.body = {
      "enterpriseName": "",
      "address": "",
      "city": "",
      "zip": "",
      "country": "",
      // "businessNature": this.profession_details[0],
      // "numberOfEmployees": this.profession_details[1],
      "firstName": "",
      "surName": "",
      "role":"",
      "id": this.identification.id,
      "mobile":"",
      "designation":this.identification.designation
    }
  }

    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    return this.http.post(environment.urls.nodeBackend + "/signup/enterpriseDetails", this.body, options);
  }

  onboard() {
    let body = {
      "comments": this.comment
    }
    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    return this.http.post(environment.urls.nodeBackend + "/signup/onboarded", body, options);
  }

  customerQuery() {
    let body = {
      "purpose": this.customerQuery1.purpose,
      "businessType": this.customerQuery1.businessType,
      "noOfLocations": this.customerQuery1.noOfLocations,
      "numberOfEmployees": this.customerQuery1.numberOfEmployees,
      "firstName": this.customerQuery1.firstName,
      "enterpriseName": this.customerQuery1.enterpriseName,
      "email": this.customerQuery1.email,
      "role":this.customerQuery1.role,
      "city": this.customerQuery1.city,
      "mobile":this.customerQuery1.mobile
    }
    const options = {
      headers:
        {
          'content-type': 'application/json'
        }
    };
    localStorage.setItem('currentUser', JSON.stringify({ name:this.customerQuery1.firstName,enterpriseName:this.customerQuery1.enterpriseName,city:this.customerQuery1.city,numberOfEmployees:this.customerQuery1.numberOfEmployees,role:this.customerQuery1.role,mobile:this.customerQuery1.mobile,email: this.customerQuery1.email }));
    return this.http.post(environment.urls.nodeBackend + "/newCustomer/customer-query", body, options);
  }

  

  bannerCustomerQuery() {
    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    return this.http.get(environment.urls.cmsUrl + "/o/CMSTelecomDemo/v1/webPageAssets/Banners", options);
    // return this.http.get("./../assets/banners.json");
  }

  secondBannerCustomerQuery() {
    const options = {
      headers:
        {
          'content-type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
    };
    // return this.http.get(environment.urls.cmsUrl + "/o/CMSTelecomDemo/v1/webPageAssets/SecondaryBanners", options);
    return this.http.get("./../assets/banners.json");
  }

  postAccount() {
    const options = {
      headers:
        {
          'content-type': 'application/json'
        }
    };
    return this.http.post(environment.urls.nodeBackend+"/postAccount",options);
  }

  createOpportunity(){
    const options = {
      headers:
        {
          'content-type': 'application/json'
        }
    }; 
    return this.http.post(environment.urls.nodeBackend+"/postOpportunity",options);
  }

  getProducts(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.get(environment.urls.nodeBackend+"/getProducts",options);
  }

  getLogin(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.post(environment.urls.nodeBackend+"/login",options);
  }

  getOpportunity(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.get(environment.urls.nodeBackend+"/getOpportunity",options);
  }

  recommendations(){
    return this.http.get('./../../assets/recommendations.json');
  }

  getMail(){
    return this.http.get(environment.urls.nodeBackend+"/mail");
  }

  getMenu(){
    let options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
    return this.http.get(environment.urls.nodeBackend+"/menu",options);
  }

  getSalesMail(){
    return this.http.get(environment.urls.nodeBackend+"/getSalesMail");
  }

  getOrders(){
    return this.http.get(environment.urls.nodeBackend+"/orders");
  }

  getWhatsApp(){
    return this.http.get(environment.urls.nodeBackend+"/whatsapp");
  }

  getCPOmail(){
    return this.http.get(environment.urls.nodeBackend+"/getCPOmail");
  }

  getAuthOTP(){
    return this.http.get(environment.urls.nodeBackend+"/otpAuth");
  }

  setBanners(banners){
    this.banners = banners;
  }
  getBanners(){
    return this.banners;
  }

  getAccountMail(){
    return this.http.get(environment.urls.nodeBackend+"/getAccountMail");
  }

  getCustomerDetails(id){
    return this.http.get(environment.urls.nodeBackend+"/getCustomerDetails/"+id);
  }
}
