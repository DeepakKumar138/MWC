import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class StepperService {
    private _canGoNext = new Subject<any>();
    private _callNext = new Subject<any>();
    // private _canGoPrevious = new Subject<any>();
    // private _callPrevious = new Subject<any>();

    initiateNext() {
        this._canGoNext.next();
      }
    goToNextStep(){
       this._callNext.next();
    }

    // initiatePrevious() {
    //     this._canGoPrevious.next();
    //   }
    // goToPreviousStep(){
    //    this._callPrevious.next();
    // }
    
    canGoNext$ = this._canGoNext.asObservable();
    callNext$ = this._callNext.asObservable();

    // canGoPrevious$ = this._canGoPrevious.asObservable();
    // callPrevious$ = this._callPrevious.asObservable();
}