import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { map } from 'rxjs/operators';

// import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  constructor(private http: Http) { }

  getLogin(){
    let headers = new Headers({
      "Content-Type":"application/json"
    });
    return this.http.post('http://52.5.252.249:3000/login',{headers:headers})
  }


  // get All Product
  getProduct() {
    //  headers = new Headers();
    let headers = new Headers({
    //   'Access-Control-Allow-Origin': '*',
    //  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT,DELETE',
      'Content-Type': 'application/json',
    //  'Accept': 'application/json',
    //  'Authorization':''+ environment.token,
    //  'X-CCAsset-Language': 'en-US'
   });

   //  let options = new RequestOptions({ headers:headers,withCredentials: true});
   return this.http.get('http://52.5.252.249:3000/getProducts', { headers: headers })
     .pipe(map(res => res.json()));

  }

}
