import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { NewCustomerComponent } from './new-customer.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CustomerQueryComponent } from './customer-query/customer-query.component';
// import { ProductsComponent } from './products/products.component';

const routes: Routes = [
    {
        path: 'newCustomer',
        component:NewCustomerComponent,
        children: [ 
            {path: '', redirectTo:'newCustomer/customer-query', pathMatch:'full'},
            {path: 'customer-query', component: CustomerQueryComponent},
            {path: 'order-summary', component: OrderSummaryComponent},
            // {path: 'products',component: ProductsComponent}
        ]
    }
];

@NgModule({
    exports: [RouterModule,CustomerQueryComponent,OrderSummaryComponent],
    imports: [RouterModule.forChild(routes)]
})
export class NewCustomerRoutingModule { }
