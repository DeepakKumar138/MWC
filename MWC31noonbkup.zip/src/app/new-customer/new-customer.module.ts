import { NewCustomerRoutingModule } from './new-customer.routing';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewCustomerComponent } from './new-customer.component';
import { CustomerQueryComponent } from './customer-query/customer-query.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
// import { ProductsComponent } from './products/products.component';
import { OwlModule } from 'ngx-owl-carousel';

@NgModule({
  imports: [
    CommonModule,
    NewCustomerRoutingModule,
    OwlModule
  ],
  exports:[
    CommonModule,
    CustomerQueryComponent,
    OrderSummaryComponent,
    // ProductsComponent
],
  declarations: [CustomerQueryComponent, OrderSummaryComponent, 
    // ProductsComponent
  ]
})
export class NewCustomerModule { }
