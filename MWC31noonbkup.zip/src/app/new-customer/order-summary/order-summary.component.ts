import { Component, OnInit } from '@angular/core';
import { ApicallsService } from 'src/app/shared/services/apicalls.service';
import { CustomerQueryComponent } from '../customer-query/customer-query.component';
import { WindowRefService } from 'src/app/shared/services/window-ref.service';
import { Router } from '@angular/router';
import * as jwt from 'jsonwebtoken';

@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.component.html',
  styleUrls: ['./order-summary.component.css']
})
export class OrderSummaryComponent implements OnInit {
  recommendations: any = [];
  _w: any;
  chatBox: any;
  orderno: string;

  constructor(private _as: ApicallsService, private winRef: WindowRefService, private router:Router) {
    this._as.recommendations().subscribe((data: any) => {
      console.log(data);
      this.recommendations = data;
    });
    this.orderno = "36958866";
    let user = JSON.parse(localStorage.getItem('currentUser'));
    console.log(user);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": user.name,
      "trigger_reason": "FEEDBACK"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    this._w = winRef.nativeWindow;
    console.log(this._w);
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    console.log(this.chatBox);
  }

  ngOnInit() {
  }

  feedback() {
    this._w.Avaamo.openChatBox();
    // var window1 = window.open('http://localhost:8080/documents/20126/0/CPQ-351.pdf', '_blank', 'location=yes,scrollbars=yes,status=yes');
    // setTimeout(() => {
    //   window1.close();
    // }, 15000);
  }

  login(){
    this.router.navigate(['mwcLogin']);
  }


}
