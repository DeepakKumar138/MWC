import { NewCustomerModule } from './new-customer.module';

describe('NewCustomerModule', () => {
  let newCustomerModule: NewCustomerModule;

  beforeEach(() => {
    newCustomerModule = new NewCustomerModule();
  });

  it('should create an instance', () => {
    expect(newCustomerModule).toBeTruthy();
  });
});
