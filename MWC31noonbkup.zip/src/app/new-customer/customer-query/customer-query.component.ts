import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import * as jwt from 'jsonwebtoken';
import { WindowRefService } from 'src/app/shared/services/window-ref.service';
import { ServicesService } from 'src/app/services/services.service';
import { Cookie } from 'ng2-cookies/ng2-cookies';

@Component({
  selector: 'app-customer-query',
  templateUrl: './customer-query.component.html',
  styleUrls: ['./customer-query.component.css']
})
export class CustomerQueryComponent implements OnInit {

  _w: any;
  chatBox: any;
  one:any=1;

  secondBannerUrl: any = [];
  secondBanners: any = [];
  bannerUrl: any = [];
  banners: any = [];
  city1: any;
  email1:any;
  firstName1:any;
  customerQuery: any = {};
  noOfLocations: any;
  numberOfEmployees: any;
  businessType: any;
  purpose: any;
  tell: string;
  marketplace: string;
  welcome: string;
  num:number = 0;
  companys:any = ["Infoarchive Ltd.", "Kenome Technologies", "Omagh Interprises","Northvalley Interprises","Seacom Private Ltd.","Carlisa Enterprises","Nanook Ltd.","Transnet Technologies","Daniel Soch Ltd.","Alexkor Tech.","Others"];
  company1: any;
  mobile1: any;
  roles:any = ["Buyer", "Executive","Decision maker","C-Level"];
  role:any;
  other = false;
  flag:boolean = true;
  
  constructor(private _as:ApicallsService, private service: ServicesService, private router:Router, private winRef:WindowRefService) {
    this._w = this.winRef.nativeWindow;
    this.welcome = "Explore our";
    this.marketplace = "5G for business";
    this.tell = "Tell us about you to help you better";
    
    // this.bannerUrl = [
    //   "./../../../assets/banner.jpg","./../../../assets/mwc_mock_banner.jpg"
    // ]
    
    this.bannerUrl = ['http://52.5.252.249:8080/documents/20126/35667/ethernet_speed_scale.jpg','http://52.5.252.249:8080/documents/20126/35667/buscontent_banner.jpg']; 
    ///documents/20126/35667/buscontent_banner.jpg

    // this.bannerUrl = ['./../../../assets/Card3.png','./../../../assets/Card2.png']
    // this._as.secondBannerCustomerQuery().subscribe((data:any)=>{
    //   this.secondBanners = data.webPageAssets.banners;
    //   console.log(this.secondBanners);
    //   for(let i=0;i<this.secondBanners.length;i++){
    //     this.secondBannerUrl.push("http://localhost:8080"+this.secondBanners[i].url);
    //   }
    // })
    // this.secondBannerUrl = ["./../../../assets/youtube.jpg","./../../../assets/youtube.jpg"];
   }

  ngOnInit() {
    // this.login();
    this.firstbot();
    
  }

  login() {
   
    this._as.getLogin()
  
      .subscribe((login:any) => {
        // localStorage.setItem('product_internet', JSON.stringify(data));
        console.log(login);
  
          // environment.customer_id = login.CustomerId;
          // environment.token = login.access_token;
        // Cookie.set('token',login.access_token);
        Cookie.set('customer_id',login.CustomerId);
  
          console.log(Cookie.get('token'));
          // console.log(localStorage.getItem('customer_id'));
          this.getUser();
          this.getProduct();
  
          
      });
  
  }

  getProduct() {
    this._as.getProducts()
      .subscribe((data:any) => {
        console.log(data);
        localStorage.setItem('product_internet', JSON.stringify(data));
  
        console.log(localStorage.getItem('product_internet'));
        // for (let index = 0; index < data.products.length; index++) {
        //   environment.product.push(data.products[index]);
  
        // }

      });
  
    // console.log(environment.product);
  
  }

  getUser() {
    let id =Cookie.get('customer_id'); 
    // console.log("ehlloo",id);
    
    
    this._as.getCustomerDetails(id)
          .subscribe((user) => {
            // localStorage.setItem('product_internet', JSON.stringify(data));
            console.log(user);
    
          });
    
      }

  firstbot(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": "there",
      "trigger_reason": "WELCOME_BOT"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      if(this.service.once != '1'){
        this._w.Avaamo.openChatBox();
        this.service.setvalue(this.one);
      }
      
    },8000);
   
  }

  cleanup() {
    [].forEach.call(document.querySelectorAll('.avaamo__chat__widget'), (x) => x.remove());
    [].filter.call(document.querySelectorAll('script'), x => x.src.indexOf('avaamo')!=-1).forEach(x => x.remove());
  }

  valueEmployees(event){
    console.log(event);
    this.numberOfEmployees = event;
  }

  valueLocation(event){
    console.log(event);
    this.noOfLocations = event;
  }

  start(job){
    if(this.flag==true){
    document.getElementById('start').style.backgroundColor = '#f5cc00';
    document.getElementById('start').style.color = '#000000';
    this.purpose = "start business";
    this.flag = false;
    }else{
    document.getElementById('start').style.backgroundColor = 'black';
    document.getElementById('start').style.color = 'white';
    this.purpose = "";
    this.flag = true;
    }
  }

  upgrade(job){
    if(this.flag==true){
      document.getElementById('upgrade').style.backgroundColor = '#f5cc00';
      document.getElementById('upgrade').style.color = '#000000';
      this.purpose = "upgrade connectivity";
      this.flag = false;
      }else{
      document.getElementById('upgrade').style.backgroundColor = 'black';
      document.getElementById('upgrade').style.color = 'white';
      this.purpose = "";
      this.flag = true;
      }
    }

  raise(job){
    if(this.flag==true){
      document.getElementById('raise').style.backgroundColor = '#f5cc00';
      document.getElementById('raise').style.color = '#000000';
      this.purpose = "raise concern";
      this.flag = false;
      }else{
      document.getElementById('raise').style.backgroundColor = 'black';
      document.getElementById('raise').style.color = 'white';
      this.purpose = "";
      this.flag = true;
      }
    // document.getElementById('raise').style.backgroundColor = '#f5cc00';
    // document.getElementById('raise').style.color = '#000000';
    // this.purpose = "raise concern";
  }

  small(job){
    if(this.flag==true){
      document.getElementById('small').style.backgroundColor = '#f5cc00';
      document.getElementById('small').style.color = '#000000';
      this.purpose = "small business";
      this.flag = false;
      }else{
      document.getElementById('small').style.backgroundColor = 'black';
      document.getElementById('small').style.color = 'white';
      this.purpose = "";
      this.flag = true;
      }
    // document.getElementById('small').style.backgroundColor = '#f5cc00';
    // document.getElementById('small').style.color = '#000000';
    // this.businessType = "small business";
  }

  medium(job){
    if(this.flag==true){
      document.getElementById('medium').style.backgroundColor = '#f5cc00';
      document.getElementById('medium').style.color = '#000000';
      this.purpose = "medium business";
      this.flag = false;
      }else{
      document.getElementById('medium').style.backgroundColor = 'black';
      document.getElementById('medium').style.color = 'white';
      this.purpose = "";
      this.flag = true;
      }
    // document.getElementById('medium').style.backgroundColor = '#f5cc00';
    // document.getElementById('medium').style.color = '#000000';
    // this.businessType = "medium business";
  }

  large(job){
    if(this.flag==true){
      document.getElementById('large').style.backgroundColor = '#f5cc00';
      document.getElementById('large').style.color = '#000000';
      this.purpose = "small business";
      this.flag = false;
      }else{
      document.getElementById('large').style.backgroundColor = 'black';
      document.getElementById('large').style.color = 'white';
      this.purpose = "";
      this.flag = true;
      }
    // document.getElementById('large').style.backgroundColor = '#f5cc00';
    // document.getElementById('large').style.color = '#000000';
    // this.businessType = "large business";
  }

  firstName(event){
    console.log(event);
    this.firstName1 = event;
  }

  email(event){
    this.email1 = event;
  }

  city(event){
    this.city1 = event;
  }

  mobile(event){
    this.mobile1 = event;
  }

  content(){
    window.open(environment.urls.morphUrl+"/ContentForBusiness","_self");
  }

  company(event){
    this.company1 = event;
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
  }
  companySelect(event){
    // console.log("event", event);
    // console.log("conp",this.company1);
    if(this.company1 == "Others"){
      this.other = true;
      this.myFunction();
    }
    else
      this.other = false;
  }
  awsRoute(){
    this.router.navigate(['./select-service']);
  }

  next(event){
    console.log(event);
    
    if(this.num==0){
    this.tell = "Tailor your solutions, by sharing your details";
    document.getElementById('tell').style.fontWeight = '600';
    document.getElementById('second').style.display = 'unset';
    document.getElementById('first').style.display = 'none';
    this.customerQuery['purpose'] = this.purpose;
    this.customerQuery['businessType'] = this.businessType;
    this.customerQuery['noOfLocations'] = this.noOfLocations;
    this.customerQuery['numberOfEmployees'] = this.numberOfEmployees;
    }
    if(this.num==1){
      this.welcome = "Joy is in the journey,";
      this.marketplace = "Begin it with us!";
      document.getElementById('second').style.display = 'none';
      document.getElementById('third').style.display = 'unset';
      document.getElementById('cloud-solutions').style.display = "none";
      this.customerQuery['firstName'] = this.firstName1;
      this.customerQuery['email'] = this.email1;
      this.customerQuery['enterpriseName'] = this.company1;
    }
    if(this.num==2){
      
      console.log("role", this.role);
      this.customerQuery['city'] = this.city1;
      this.customerQuery['mobile'] = this.mobile1;
      this.customerQuery['role'] = this.role;
            // this.customerQuery.push(this.city1,this.mobile1);

      this._as.setCustomerQuery(this.customerQuery);
      var x = document.getElementById("snackbar1");
      x.className = "show";
      setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
      this._as.customerQuery().subscribe((data2:any)=>{
        console.log(data2);
        this._as.postAccount().subscribe((data:any)=>{
          console.log(data);
          this._as.createOpportunity().subscribe((data1:any)=>{
            console.log(data1);
            this._as.getMail().subscribe((data3:any)=>{
              console.log(data3);
              this._as.getWhatsApp().subscribe((data4:any)=>{
                console.log(data4);
                this._as.getAccountMail().subscribe((data5:any) =>{
                  console.log(data5);
                })
              })
            })
          });
        });
      });
      
      
      
    }
    console.log("role", this.role);
    this.num++;
  }

  demand(){
    this.router.navigate(['demands']);
  }

  myFunction() {
    this._as.getCPOmail().subscribe((data: any) => {
      console.log(data);
    })
    // var x = document.getElementById("snackbar");
    // x.className = "show";
    // setTimeout(function(){ x.className = x.className.replace("show", ""); }, 2000);
  }

}
