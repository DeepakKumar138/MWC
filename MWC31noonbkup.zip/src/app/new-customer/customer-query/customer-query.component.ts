import { ApicallsService } from '../../shared/services/apicalls.service';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-query',
  templateUrl: './customer-query.component.html',
  styleUrls: ['./customer-query.component.css']
})
export class CustomerQueryComponent implements OnInit {

  secondBannerUrl: any = [];
  secondBanners: any = [];
  bannerUrl: any = [];
  banners: any = [];
  city1: any;
  email1:any;
  firstName1:any;
  customerQuery: any = [];
  noOfLocations: any;
  numberOfEmployees: any;
  businessType: any;
  purpose: any;
  tell: string;
  marketplace: string;
  welcome: string;
  num:number = 0;
  company1: any;
  mobile1: any;

  
  constructor(private _as:ApicallsService, private router:Router) {
    this.welcome = "Explore our";
    this.marketplace = "5G for business";
    this.tell = "Tell us about you to help you better";
    
    // this.bannerUrl = [
    //   "./../../../assets/banner.jpg","./../../../assets/mwc_mock_banner.jpg"
    // ]
    this._as.bannerCustomerQuery().subscribe((data:any)=>{
      this.banners = data.webPageAssets.banners;
      console.log(this.banners);
      // for(let i=0;i<this.banners.length;i++){
        this.bannerUrl.push(environment.urls.cmsUrl+this.banners[1].url);
        this.bannerUrl.push(environment.urls.cmsUrl+this.banners[9].url);
        // this.secondBannerUrl.push(environment.urls.cmsUrl+this.banners[7].url);
      // }
    })
    // this.bannerUrl = ['./../../../assets/Card3.png','./../../../assets/Card2.png']
    // this._as.secondBannerCustomerQuery().subscribe((data:any)=>{
    //   this.secondBanners = data.webPageAssets.banners;
    //   console.log(this.secondBanners);
    //   for(let i=0;i<this.secondBanners.length;i++){
    //     this.secondBannerUrl.push("http://localhost:8080"+this.secondBanners[i].url);
    //   }
    // })
    // this.secondBannerUrl = ["./../../../assets/youtube.jpg","./../../../assets/youtube.jpg"];
   }

  ngOnInit() {
  }

  valueEmployees(event){
    console.log(event);
    this.numberOfEmployees = event;
  }

  valueLocation(event){
    console.log(event);
    this.noOfLocations = event;
  }

  start(job){
    document.getElementById('start').style.backgroundColor = '#f5cc00';
    document.getElementById('start').style.color = '#000000';
    this.purpose = "start business";
  }

  upgrade(job){
    document.getElementById('upgrade').style.backgroundColor = '#f5cc00';
    document.getElementById('upgrade').style.color = '#000000';
    this.purpose = "upgrade connectivity";
  }

  raise(job){
    document.getElementById('raise').style.backgroundColor = '#f5cc00';
    document.getElementById('raise').style.color = '#000000';
    this.purpose = "raise concern";
  }

  small(job){
    document.getElementById('small').style.backgroundColor = '#f5cc00';
    document.getElementById('small').style.color = '#000000';
    this.businessType = "small business";
  }

  medium(job){
    document.getElementById('medium').style.backgroundColor = '#f5cc00';
    document.getElementById('medium').style.color = '#000000';
    this.businessType = "medium business";
  }

  large(job){
    document.getElementById('large').style.backgroundColor = '#f5cc00';
    document.getElementById('large').style.color = '#000000';
    this.businessType = "large business";
  }

  firstName(event){
    console.log(event);
    this.firstName1 = event;
  }

  email(event){
    this.email1 = event;
  }

  city(event){
    this.city1 = event;
  }

  mobile(event){
    this.mobile1 = event;
  }

  company(event){
    this.company1 = event;
  }

  next(event){
    console.log(event);
    
    if(this.num==0){
    this.tell = "Tailor your solutions, by sharing your details";
    document.getElementById('tell').style.fontWeight = '600';
    document.getElementById('second').style.display = 'unset';
    document.getElementById('first').style.display = 'none';
    this.customerQuery.push(this.purpose,this.businessType,this.noOfLocations,this.numberOfEmployees);
    }
    if(this.num==1){
      this.welcome = "Joy is in the journey,";
      this.marketplace = "Begin it with us!";
      document.getElementById('second').style.display = 'none';
      document.getElementById('third').style.display = 'unset';
      document.getElementById('cloud-solutions').style.display = "none";
      this.customerQuery.push(this.firstName1,this.email1,this.company1);
    }
    if(this.num==2){
      this.customerQuery.push(this.city1,this.mobile1);
      this._as.setCustomerQuery(this.customerQuery);
      this._as.customerQuery().subscribe((data2:any)=>{
        console.log(data2);
        this._as.postAccount().subscribe((data:any)=>{
          console.log(data);
          this._as.createOpportunity().subscribe((data1:any)=>{
            console.log(data1);
            this._as.getMail().subscribe((data3:any)=>{
              console.log(data3);
              this._as.getWhatsApp().subscribe((data4:any)=>{
                console.log(data4);
              })
            })
          });
        });
      });
      
      
      
    }
    this.num++;
  }

  demand(){
    this.router.navigate(['demands']);
  }

}
