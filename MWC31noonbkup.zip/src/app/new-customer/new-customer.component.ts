import { Component, OnInit } from '@angular/core';
import { ApicallsService } from '../shared/services/apicalls.service';
import { Router } from '@angular/router';
declare var $:any;

@Component({
  selector: 'app-new-customer',
  templateUrl: './new-customer.component.html',
  styleUrls: ['./new-customer.component.css']
})
export class NewCustomerComponent implements OnInit {
  navbar: any = [];
  menu: any = [];
  submenu: any = [];
  show:boolean;

  constructor(private _as:ApicallsService, private router:Router) {
    this._as.getMenu().subscribe((data:any)=>{
      console.log(data[0].menu);
      this.navbar = data[0].menu;
    })
   }

  ngOnInit() {
   
  }

  hovering(){
    document.getElementById('dropdown-menu').style.display = 'block';
    console.log("hovering");
  }

  connectivity(){
    document.getElementById('dropdown-menu1').style.display = 'block';
    document.getElementById('dropdown-item').style.backgroundColor = '#757373';
    document.getElementById('dropdown-item').style.color = '#f5cc00';
  }

  internet(){
    document.getElementById('dropdown-menu1').style.display = 'block';
    document.getElementById('dropdown-item').style.backgroundColor = '#757373';
    document.getElementById('dropdown-item').style.color = '#f5cc00';
  }

  products(){
    this.router.navigate(['/newCustomer/products']);
  }

  remove_nav(){
    document.getElementById('dropdown-content').style.display = 'none';
  }
  
}
