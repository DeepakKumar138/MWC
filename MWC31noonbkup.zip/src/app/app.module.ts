import { OrderSummaryComponent } from './new-customer/order-summary/order-summary.component';
import { AuthService } from './shared/services/auth.service';
import { NewCustomerModule } from './new-customer/new-customer.module';
import { NewCustomerRoutingModule } from './new-customer/new-customer.routing';
import { CustomerQueryComponent } from './new-customer/customer-query/customer-query.component';
import { StepperComponent } from './shared/stepper/stepper.component';
import { RouterModule } from '@angular/router';
import { SignupRoutingModule } from './signup/signup.routing';
import { SignupModule } from './signup/signup.module';
import { StepperService } from './shared/services/stepper.service';
import { SharedModule } from './shared/shared.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Approutes } from './app.routing';
import { AppComponent } from './app.component';
import { EnterpriseDetailsComponent } from './signup/enterprise-details/enterprise-details.component';
import { ProfessionComponent } from './signup/profession/profession.component';
import { IdentificationComponent } from './signup/identification/identification.component';
import { GenerateOtpComponent } from './signup/generate-otp/generate-otp.component';
import { OnboardedComponent } from './signup/onboarded/onboarded.component';
import { SignupComponent } from './signup/signup.component';
import { HttpClientModule } from '@angular/common/http';
import { NewCustomerComponent } from './new-customer/new-customer.component';

import { environment } from '../environments/environment';
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { EventComponent } from './pages/event/event.component';
import { Modal1Component } from './pages/modal1/modal1.component';
import { OrderComponent } from './pages/order/order.component';
import { SelectServiceComponent } from './pages/select-service/select-service.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgmCoreModule } from '@agm/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
// import { ProductsComponent } from './new-customer/products/products.component';
import { GoogleMapsAPIWrapper } from '@agm/core';
import { OwlModule } from 'ngx-owl-carousel';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { HttpModule } from '@angular/http';
import { Ng5SliderModule } from 'ng5-slider';
import { ProductComponent } from './product/product.component';
import { PersonalizedPageComponent } from './personalized-page/personalized-page.component';
import { SmartWorkplaceBundleComponent } from './smart-workplace-bundle/smart-workplace-bundle.component';
import { ProductEthernetComponent } from './product-ethernet/product-ethernet.component';
import { InfrastructureSecurityProductComponent } from './infrastructure-security-product/infrastructure-security-product.component';
import { ContentForBusinessComponent } from './content-for-business/content-for-business.component';
import { IotSmartWorkplaceComponent } from './iot-smart-workplace/iot-smart-workplace.component';
import { HeaderComponent } from './header/header.component';
import { CartSummaryComponent } from './cart-summary/cart-summary.component';
import { DesignYourOwnBundleComponent } from './design-your-own-bundle/design-your-own-bundle.component';
import { SmartWorkplaceComponent } from './smart-workplace/smart-workplace.component';
import { DemandsComponent } from './demands/demands.component';
import { VideoOnDemandComponent } from './video-on-demand/video-on-demand.component';
import { SliceAsBundleComponent } from './sliceAsBundle/sliceAsBundle.component';



@NgModule({
  declarations: [
    AppComponent,
    EnterpriseDetailsComponent,
    ProfessionComponent,
    IdentificationComponent,
    GenerateOtpComponent,
    OnboardedComponent,
    SignupComponent,
    NewCustomerComponent,
    CustomerQueryComponent,
    OrderSummaryComponent,
    ProductComponent,
    PersonalizedPageComponent,
    SmartWorkplaceBundleComponent,
    ProductEthernetComponent,
    InfrastructureSecurityProductComponent,
    ContentForBusinessComponent,
    IotSmartWorkplaceComponent,
    HeaderComponent,
    CartSummaryComponent,
    DesignYourOwnBundleComponent,
    EventComponent,
    Modal1Component,
    OrderComponent,
    SelectServiceComponent,
    SmartWorkplaceComponent,
    DemandsComponent,
    VideoOnDemandComponent,
    SliceAsBundleComponent
  ],
  imports: [
    HttpModule,
    Ng5SliderModule,
    BrowserModule,
    NgbModule,
    // AppRoutingModule,
    SharedModule,
    RouterModule.forRoot(Approutes,{useHash:true}),
    HttpClientModule,
    AngularFireModule.initializeApp(environment.firebase, 'angular-auth-firebase'),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    FormsModule,
    OwlModule,
    ReactiveFormsModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDdhxztr2cV9SAYGP1Mvntn_yYEbQluFHI'
    }),
  ],
  exports:[NavbarComponent],
  providers: [AuthService,GoogleMapsAPIWrapper],
  bootstrap: [AppComponent]
})
export class AppModule { }
