// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase:{
    apiKey: "AIzaSyDor05Odzj_6FywrxyQZ2z5dnSNYB3BwYc",
    authDomain: "smsapp-b948e.firebaseapp.com",
    databaseURL: "https://smsapp-b948e.firebaseio.com",
    projectId: "smsapp-b948e",
    storageBucket: "",
    messagingSenderId: "588137407598"
  },
  urls:{
    nodeBackend: 'http://52.5.252.249:3000',
    cmsUrl:'http://52.5.252.249:8080',
    morphUrl:'http://52.6.121.116/#',
    // morphUrl:'http://localhost:4300'
  },
  token:"Bearer eyJhbGciOiJSUzI1NiIsImprdSI6InR6MHlhMGMwIiwia2lkIjpudWxsLCJ4NWMiOm51bGwsIng1dSI6Imh0dHBzOi8vY2NhZG1pbi16MHlhLm9yYWNsZW91dHNvdXJjaW5nLmNvbS9jY2FkbWluL3YxL3RlbmFudENlcnRDaGFpbiJ9.eyJpYXQiOjE1NDg2ODIyNjQsImV4cCI6MTU0ODY4MjU2NCwic3ViIjoiMWU2ZWY5NTItZDhiZS00YmZmLWI2ZTYtNzQ5ZGI4N2M5OWIxIiwiYXVkIjoiYXBwbGljYXRpb25BY2Nlc3MiLCJjb20ub3JhY2xlLmF0Zy5jbG91ZC5jb21tZXJjZS5yb2xlcyI6WyJzZXR0aW5nc1JvbGUiLCJtYXJrZXRpbmdSb2xlIiwicHVibGlzaGluZ1JvbGUiLCJkYXNoYm9hcmRSb2xlIiwicmVwb3J0aW5nUm9sZSIsImNhdGFsb2dSb2xlIiwiZGVzaWduUm9sZSIsIm1lZGlhUm9sZSIsInByZXZpZXdSb2xlIiwiYWNjb3VudE1hbmFnZXJSb2xlIiwic2VhcmNoUm9sZSJdLCJvY2NzLmFkbWluLnJvbGVzIjpbInNldHRpbmdzUm9sZSIsIm1hcmtldGluZ1JvbGUiLCJwdWJsaXNoaW5nUm9sZSIsImRhc2hib2FyZFJvbGUiLCJyZXBvcnRpbmdSb2xlIiwiY2F0YWxvZ1JvbGUiLCJkZXNpZ25Sb2xlIiwibWVkaWFSb2xlIiwicHJldmlld1JvbGUiLCJhY2NvdW50TWFuYWdlclJvbGUiLCJzZWFyY2hSb2xlIl0sImlzcyI6Imh0dHBzOi8vY2NhZG1pbi16MHlhLm9yYWNsZW91dHNvdXJjaW5nLmNvbS9vY2NzLWFkbWluIiwib2Njcy5hZG1pbi5sb2NhbGUiOiJlbl9VUyIsIm9jY3MuYWRtaW4udHoiOm51bGwsIm9jY3MuYWRtaW4udGVuYW50VHoiOiJFdGMvVVRDIiwib2Njcy5hZG1pbi5rZWVwQWxpdmVVUkwiOiJodHRwczovL2NjYWRtaW4tejB5YS5vcmFjbGVvdXRzb3VyY2luZy5jb20va2VlcGFsaXZlIiwib2Njcy5hZG1pbi50b2tlblJlZnJlc2hVUkwiOiJodHRwczovL2NjYWRtaW4tejB5YS5vcmFjbGVvdXRzb3VyY2luZy5jb20vY2NhZG1pbi92MS9zc29Ub2tlbnMvcmVmcmVzaCIsIm9jY3MuYWRtaW4udmVyc2lvbiI6IjE4LjQuMSIsIm9jY3MuYWRtaW4uYnVpbGQiOiJqZW5raW5zLUFzc2VtYmxlX0Nsb3VkX0NvbW1lcmNlX0VBUnNfLTE4XzRQYXRjaGVzLTYiLCJvY2NzLmFkbWluLmVtYWlsIjpudWxsLCJvY2NzLmFkbWluLnByb2ZpbGVJZCI6IjFlNmVmOTUyLWQ4YmUtNGJmZi1iNmU2LTc0OWRiODdjOTliMSIsIm9jY3MuYWdlbnQub2JvIjpudWxsLCJvY2NzLmFkbWluLmZpcnN0TmFtZSI6bnVsbCwib2Njcy5hZG1pbi5sYXN0TmFtZSI6bnVsbCwib2Njcy5hZG1pbi5wdW5jaG91dFVzZXIiOmZhbHNlfQ==.LXyXCAS0NipuUsXOmvIY+UyirOw/FVUM0T6dnc900Lz8SRraiA8hvSV4K+CHW68p/o4NWOOfpBmQkDtBVF/Yj18+S051CP22vHm+tARlsfn6G+CkfVjLsOzBPX9hW6pzG7poK3Q1YC5AyWQNauIJuawJI6MEATmg5KNHCe0g5/zNhVO0HMLRhOxgMHVTXwpIA++57tHtBFU7xzhY+mbB/YpUZtOEHP5WYkqepvgfbUwYgMbIn+R2UMlH2bHsqX/G5YU+2GjFaN+r4C8JTdbXeVSP1QU/rO0xLMXSm0ws3CPllRr4sJl0Gd2zVBhlJU5A/phb5021wn0jvRibL1Ijlg==",
  // api_url:'https://ccadmin-z0ya.oracleoutsourcing.com/ccadmin/v1'
   api_url:'52.5.252.249:3000',
   product: [],
   internet_cart:[],
   smartbundle_cart:[],
  i_bandwidth: String
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
