var mongoose = require('mongoose');
var dateSchema = mongoose.Schema({
    name:String,
    date:Date,
    time:String
});
module.exports = mongoose.model('Date',dateSchema);