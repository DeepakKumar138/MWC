var mongoose = require('mongoose');
var cartSchema = mongoose.Schema({
    bandwidth: String,
    displayName:  String,
    id: String,
    recurrencePeriod: String,
    recurrencecost: Number,
    salePrice: Number
});
module.exports = mongoose.model('Cart',cartSchema);