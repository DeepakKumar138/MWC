module.exports = (app)=>{
    var customers = require('./../controllers/controller');
    var navbars = require('./../controllers/controller');
    var opportunities = require('./../controllers/controller');
    var dates = require('./../controllers/controller');
    var carts = require('./../controllers/controller');


    app.post('/signup/enterpriseDetails',customers.createEnterpriseDetails);
    app.post('/signup/onboarded',customers.createOnboarded);
    app.post('/newCustomer/customer-query',customers.createNewCustomer);
    app.get('/getOpportunity',opportunities.getOpportunity);
    app.post('/login',customers.login);
    app.get('/getProducts',customers.getProducts);
    app.post('/postOpportunity',opportunities.postOpportunity);
    app.post('/postAccount',opportunities.postAccount);
    app.get('/menu',navbars.getMenu);
    app.post('/menu',navbars.postMenu);
    app.put('/menu/:menuId',navbars.updateMenu);
    app.get('/mail',customers.getMail);
    app.get('/alexamail',customers.getAlexaMail);
    app.get('/getSalesMail',customers.getSalesMail);
    app.get('/getCustomerDetails/:customerId',customers.getCustomerDetails);
    app.post('/scheduledDate',dates.postScheduledDate);
    app.get('/scheduledDate',dates.getScheduledDate);
    app.get('/whatsapp',customers.whatsapp);
    app.get('/orders',customers.orders);
    app.get('/getCPOmail',customers.getCPOMail);
    app.get('/otpAuth',customers.otpAuth);
    app.get('/getQuote',customers.getQuote);
    app.get('/getEnterpriseDetails',customers.getEnterpriseDetails);
    app.get('/getAccountMail',customers.getAccountMail);
    app.post('/postCart',carts.postcart);
    app.get('/getCart',carts.getcart);

    var cors = require('cors');
    app.use(cors());
}