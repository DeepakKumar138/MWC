var Customer = require('./../models/model');
var Navbar = require('./../models/navbarmodel');
var NewCustomer = require('./../models/newCustomerModel');
var Opportunity = require('./../models/opportunitymodel');
var Date = require('./../models/dateModel');
var request = require('request');
var cloudConfig = require('./../../config/cloud.config');
var auth = 'Basic ' + Buffer.from("vaidya_rohan" + ':' + "Wiproce@12345").toString('base64');
var nodemailer = require('nodemailer');
var mailconfig = require('./../../config/mail.config');
var item = new Array();
var product = new Array();


////-- API to get mail ---/////

exports.getMail = (req, res) => {
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: mailconfig.mailId,
            pass: mailconfig.password
        }
    });

    var mailOptions = {
        from: mailconfig.mailId,
        to: email,
        subject: 'Welcome to Rapids family',
        html: '<div class="container" style="margin-left: 3%;font-size: 20px;"> <span> <img style="width:100%;height:80%;" src="cid:unique@kreata.ee" alt="banner for mail"> </span> <div style="font-size: 20px;"> <br><b>Dear ' + name + ',</b> <span style="margin-left: 48%;"></span> </div> <br> <div style="font-size:16px;"> Thanks for showing interest in our solutions. We are delighted to see you again. </div> <br> <div style="font-size: 16px;"> We have some personalised products for you which might be useful in your upcoming business pursuits. Please check them out by clicking the button below. </div> <br> <div style="text-align: center;margin-top: 2%;"><a style="font-size: 15px;margin-right: 2%;width: 160px; height: 35px; border-radius: 13px;color: white; background-color: #ee3442; font-weight: 700;text-decoration: none;padding: 1%;" href="http://localhost:4200/signup">REGISTER NOW</a><a style="font-size: 15px;margin-right: 2%;width: 160px; height: 35px; border-radius: 13px;color: black; background-color: #f5cc00; font-weight: 700;text-decoration: none;padding: 1%;" href="http://52.6.121.116">VIEW PRODUCTS</a></div> <br> <div style="font-size: 16px;"> Thanks once again and looking forward to see you in the future ! </div> <br> <div style="font-size:14px;">** Please note that before submitting the order you may have to be onboarded using our 3 min. digital onboarding process. </div> <br> <div> <div style="font-size: 16px;">Best Regards </div> <div style="font-size: 16px;">Mark Richardson </div> <div style="font-size: 16px;">Sales Manager - Emerging accounts </div> <div style="font-weight: 700;"> <a style="color: #010910;">RAPIDS</a> <a style="color: #f5cc00;">BUSINESS</a> </div> </div> </div>',
        attachments: [{
            fileName: "BannerMail.jpg",
            path: './BannerMail.jpg',
            cid: 'unique@kreata.ee'
        }]
    };
    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
    res.json({
        "message": "mail sent"
    })
}

exports.whatsapp = (req,res) => {
    const accountSid = 'AC3033e0959c7b6b125d2a145a617f7085';
    const authToken = '03615474e584df2af71f8e9a1900b3c2';
    const client = require('twilio')(accountSid, authToken);

    client.messages
        .create({
            body: 'Hello there! We have sent you some personalized offers in your email. Please take a look. Rapids Business Team',
            from: 'whatsapp:+1 415 523 8886',
            to: 'whatsapp:+91 99028 61005'
        })
        .then(message => console.log(message.sid))
        .done();

    res.send("success");
    // const accountSid = 'AC3033e0959c7b6b125d2a145a617f7085';
// const authToken = 'your_auth_token';
// const client = require('twilio')(accountSid, authToken);

// client.messages
//       .create({from: '+1 415 523 8886', body: 'Hello there! We have sent you some personalized offers in your email. Please take a look. Rapids Business Team', to: '+91 99028 61005'})
//       .then(message => console.log(message.sid))
//       .done();
}

exports.orders = (req,res) => {
    const soapRequest = require('easy-soap-request');
    const fs = require('fs');
    var auth = "Basic "+new Buffer("admin"+":"+"Osmadmin@123").toString("base64");

    // example data
    const url = 'http://52.206.138.129:8001/OrderManagement/wsapi';
    const headers = {
    'user-agent': 'sampleTest',
    'Content-Type': 'text/xml;charset=UTF-8',
    'soapAction': './Order_Status/SOAP.wsdl',
        'Authorization': auth
    };
    const xml = fs.readFileSync('./Order_Status/FindOrderRequest.xml', 'utf-8');

    // usage of module
    (async () => {
    const { response } = await soapRequest(url, headers, xml, 5000); // Optional timeout parameter(milliseconds)
    const { body, statusCode } = response;
    //   console.log(body);

    res.json({"xml":body.toString()})
    })();
}

exports.getSalesMail = (req, res) => {
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: mailconfig.mailId,
            pass: mailconfig.password
        }
    });

    var mailOptions = {
        from: mailconfig.mailId,
        to: mailconfig.salesMailId,
        subject: 'Quote rejected!!!',
        html: '<div class="container" style="margin-left: 3%;font-size: 24px;"><div><b>Hi Sales Team,</b><span style="margin-left: 48%;"><img src="./social-networks.png" alt="" width="500" height="100"></span></div><br><div>The quote with id: CPQ-483 has been rejected. Please <a href="https://wiproeu.bigmachines.com/commerce/display_company_profile.jsp">click here</a> to view details.</div><br><div style="margin-left: 65%;"> <div>Best Regards </div> <div>Sales Admin </div> <div style="margin-top: 3%;font-weight: 700;"> <a style="color: #010910;">RAPIDS</a> <a style="color: #f5cc00;">BUSINESS</a> </div> </div> </div>',
        // attachments: [{
        //     fileName: "social-networks.png",
        //     path: './social-networks.png',
        //     cid: 'unique@kreata.ee'
        // }]
    };
    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
    res.json({
        "message": "mail sent"
    })
}

////-- mail API ends here ---///////

/////////////---- engagement cloud APIs starts ------///////////////////

/////-- creating a new customer account in mongoDB as well as engagement cloud ---////
exports.createNewCustomer = (req, res) => {
    var newCustomers = new NewCustomer({
        purpose: req.body.purpose,
        businessType: req.body.businessType,
        noOfLocations: req.body.noOfLocations,
        numberOfEmployees: req.body.numberOfEmployees,
        firstName: req.body.firstName,
        enterpriseName: req.body.enterpriseName,
        email: req.body.email,
        city: req.body.city,
        mobile:req.body.mobile,
        country: "IN"
    });

    ////-- saving it to mongoDB collection newCustomers --////
    newCustomers.save()
        .then(data => {
            console.log(data);
            request.post({
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Basic dmFpZHlhX3JvaGFuOldpcHJvY2VAMTIzNDU="
                },
                "url": cloudConfig.engagementCloud + "/contacts",
                "body": JSON.stringify({

                    "FirstName": data.firstName,
                    "EmailAddress":data.email,
                    "MobileNumber":data.mobile,
                    "LastName": "",
                    "Address": [
                        {
                            "Address1": "",
                            "City": data.city,
                            "Country": "IN",
                            "State": ""
                        }
                    ]

                })
            }, (error, response, body) => {
                if (error) {
                    return console.dir(error);
                }
                console.dir(body);
                var body = JSON.parse(body);
                res.send({
                    "customerId": data._id,
                    "partyId": body.PartyId
                })
                global.mobile = data.mobile,
                global.customerId = data._id;
                global.partyId1 = body.PartyId;
                global.name = data.firstName;
                global.enterpriseName = data.enterpriseName;
                global.email = data.email;
                global.city = data.city;
            });
        })
        .catch(err => {
            res.status(500).send({
                message: err.message
            })
        });
}

exports.postAccount = (req,res) =>{
    request.post({
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Basic dmFpZHlhX3JvaGFuOldpcHJvY2VAMTIzNDU="
        },
        "url": cloudConfig.engagementCloud + "/accounts",
        "body": JSON.stringify({
            "OrganizationName": enterpriseName,
            "Type": "ZCA_CUSTOMER",
            "PrimaryContactPartyId": partyId1,
            "PrimaryAddress": [{
                "AddressLine1": "",
                "City": city,
                "State": "",
                "Country": "IN"
            }]
        })
    }, (error, response, body) => {
        if (error) {
            return console.dir(error);
        }
        console.dir(body);
        var body = JSON.parse(body);
        res.send({
            "partyId": body.PartyId,
            "PartyNumber": body.PartyNumber,
            "Type": body.Type,
            "SalesProfileNumber": body.SalesProfileNumber,
            "OwnerPartyId": body.OwnerPartyId,
            "SalesProfileStatus": body.SalesProfileStatus,
            "CurrencyCode": body.CurrencyCode,
            "PartyStatus": body.PartyStatus,
            "PartyType": body.PartyType,
            "CreationDate": body.CreationDate,
            "LastUpdateDate": body.LastUpdateDate,
            "PrimaryAddress": body.PrimaryAddress,
            "PrimaryContactName":body.PrimaryContactName
        })
        global.partyId = body.PartyId;
        global.primaryContactName = body.PrimaryContactName;
    });
    
}
                
            
            
        

/////-- API to create an opportunity in engagement cloud with same name fetched from account --/////

exports.postOpportunity = (req, res) => {
    try {
        request.post({
            "headers": {
                "content-type": "application/json",
                "Authorization": "Basic dmFpZHlhX3JvaGFuOldpcHJvY2VAMTIzNDU="
            },
            "url": cloudConfig.engagementCloud + "/opportunities",
            "body": JSON.stringify({
                "Name": enterpriseName,
                "KeyContactId": partyId1,
                "TargetPartyId": partyId
            })
        }, (error, response, body) => {
            if (error) {
                res.send("error: " + error);
            }
            else {
                var body = JSON.parse(body);

                var opportunities = new Opportunity({
                    PrimaryOrganizationId: body.PrimaryOrganizationId,
                    CreatedBy: body.CreatedBy,
                    CreationDate: body.CreationDate,
                    CurrencyCode: body.CurrencyCode,
                    SalesMethodId: body.SalesMethodId,
                    SalesStageId: body.SalesStageId,
                    Description: body.Description,
                    LastUpdateDate: body.LastUpdateDate,
                    LastUpdatedBy: body.LastUpdatedBy,
                    LastUpdateLogin: body.LastUpdateLogin,
                    Name: body.Name,
                    OptyId: body.OptyId,
                    OptyNumber: body.OptyNumber,
                    OwnerResourcePartyId: body.OwnerResourcePartyId,
                    PrimaryRevenueId: body.PrimaryRevenueId,
                    SalesMethod: body.SalesMethod,
                    SalesStage: body.SalesStage,
                    DescriptionText: body.DescriptionText,
                    AverageDaysAtStage: body.AverageDaysAtStage,
                    MaximumDaysInStage: body.MaximumDaysInStage,
                    PhaseCd: body.PhaseCd,
                    QuotaFactor: body.QuotaFactor,
                    RcmndWinProb: body.RcmndWinProb,
                    StageStatusCd: body.StageStatusCd,
                    StgOrder: body.StgOrder,
                    EffectiveDate: body.EffectiveDate,
                    Revenue: body.Revenue,
                    WinProb: body.WinProb,
                    SourceType: body.SourceType,
                    PrimaryContactPartyName: body.PrimaryContactPartyName,
                    PrimaryContactFormattedPhoneNumber: body.PrimaryContactFormattedPhoneNumber,
                    PrimaryContactEmailAddress: body.PrimaryContactEmailAddress,
                    Comments: body.Comments,
                    PartyName1: body.PartyName1,
                    EmailAddress: body.EmailAddress,
                    LookupCategory: body.LookupCategory,
                    OptyCreationDate: body.OptyCreationDate,
                    ExpectAmount: body.ExpectAmount,
                    OptyCreatedBy: body.OptyCreatedBy,
                    ForecastOverrideCode: body.ForecastOverrideCode,
                    OptyLastUpdateDate: body.OptyLastUpdateDate,
                    OptyLastUpdatedBy: body.OptyLastUpdatedBy,
                    SalesChannelCd: body.SalesChannelCd,
                    PredWinProb: body.PredWinProb,
                    TargetPartyName: body.TargetPartyName
                });

                opportunities.save()
                    .then(data => {
                        res.send("success");
                    })
                    .catch(err => {
                        res.status(500).send({
                            message: err.message
                        })
                    });

                res.send({
                    "PrimaryContactName": body.PrimaryContactPartyName,
                    "PrimaryContactEmailAddress": body.PrimaryContactEmailAddress,
                    "PrimaryContactNumber": mobile,
                    "PrimaryOrganizationId": body.PrimaryOrganizationId,
                    "CreatedBy": body.CreatedBy,
                    "CreationDate": body.CreationDate,
                    "CurrencyCode": body.CurrencyCode,
                    "SalesMethodId": body.SalesMethodId,
                    "SalesStageId": body.SalesStageId,
                    "Description": body.Description,
                    "LastUpdateDate": body.LastUpdateDate,
                    "LastUpdatedBy": body.LastUpdatedBy,
                    "LastUpdateLogin": body.LastUpdateLogin,
                    "Name": body.Name,
                    "OptyId": body.OptyId,
                    "OptyNumber": body.OptyNumber,
                    "OwnerResourcePartyId": body.OwnerResourcePartyId,
                    "PrimaryRevenueId": body.PrimaryRevenueId,
                    "SalesMethod": body.SalesMethod,
                    "SalesStage": body.SalesStage,
                    "DescriptionText": body.DescriptionText,
                    "AverageDaysAtStage": body.AverageDaysAtStage,
                    "MaximumDaysInStage": body.MaximumDaysInStage,
                    "PhaseCd": body.PhaseCd,
                    "QuotaFactor": body.QuotaFactor,
                    "RcmndWinProb": body.RcmndWinProb,
                    "StageStatusCd": body.StageStatusCd,
                    "StgOrder": body.StgOrder,
                    "EffectiveDate": body.EffectiveDate,
                    "Revenue": body.Revenue,
                    "WinProb": body.WinProb,
                    "SourceType": body.SourceType,
                    "PrimaryContactPartyName": body.PrimaryContactPartyName,
                    "PrimaryContactFormattedPhoneNumber": body.PrimaryContactFormattedPhoneNumber,
                    "PrimaryContactEmailAddress": body.PrimaryContactEmailAddress,
                    "Comments": body.Comments,
                    "PartyName1": body.PartyName1,
                    "EmailAddress": body.EmailAddress,
                    "LookupCategory": body.LookupCategory,
                    "OptyCreationDate": body.OptyCreationDate,
                    "ExpectAmount": body.ExpectAmount,
                    "OptyCreatedBy": body.OptyCreatedBy,
                    "ForecastOverrideCode": body.ForecastOverrideCode,
                    "OptyLastUpdateDate": body.OptyLastUpdateDate,
                    "OptyLastUpdatedBy": body.OptyLastUpdatedBy,
                    "SalesChannelCd": body.SalesChannelCd,
                    "PredWinProb": body.PredWinProb,
                    "TargetPartyName": body.TargetPartyName
                });
            }
        })
    }
    catch (err) {
        console.log(err);
    }
}

/////-- API to get opportunity list from engagement cloud --//////

exports.getOpportunity = (req, res) => {
    request.get({
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Basic dmFpZHlhX3JvaGFuOldpcHJvY2VAMTIzNDU="
        },
        "url": cloudConfig.engagementCloud + "/opportunities?orderBy=CreationDate:desc"

    }, (error, response, body) => {
        if (error) {
            Opportunity.find()
                .then(opportunities => {
                    res.send(opportunities);
                }).catch(err => {
                    res.status(500).send({
                        message: err.message || "Some error occurred while retrieving opportunities"
                    });
                });
        }

        var body = JSON.parse(body);
        
        for (let i = 0; i < 10; i++) {
            // if(body.creationDate.){
            item[i] = {
                "PrimaryContactName": body.items[i].PrimaryContactPartyName,
                "PrimaryContactEmailAddress": body.items[i].PrimaryContactEmailAddress,
                "PrimaryContactNumber": body.items[i].PrimaryContactFormattedPhoneNumber,
                "PrimaryOrganizationId": body.items[i].PrimaryOrganizationId,
                "CreatedBy": body.items[i].CreatedBy,
                "CreationDate": body.items[i].CreationDate,
                "CurrencyCode": body.items[i].CurrencyCode,
                "SalesMethodId": body.items[i].SalesMethodId,
                "SalesStageId": body.items[i].SalesStageId,
                "Description": body.items[i].Description,
                "LastUpdateDate": body.items[i].LastUpdateDate,
                "LastUpdatedBy": body.items[i].LastUpdatedBy,
                "LastUpdateLogin": body.items[i].LastUpdateLogin,
                "Name": "Opportunity for "+body.items[i].Name,
                "OptyId": body.items[i].OptyId,
                "OptyNumber": body.items[i].OptyNumber,
                "OwnerResourcePartyId": body.items[i].OwnerResourcePartyId,
                "PrimaryRevenueId": body.items[i].PrimaryRevenueId,
                "SalesMethod": body.items[i].SalesMethod,
                "SalesStage": body.items[i].SalesStage,
                "DescriptionText": body.items[i].DescriptionText,
                "AverageDaysAtStage": body.items[i].AverageDaysAtStage,
                "MaximumDaysInStage": body.items[i].MaximumDaysInStage,
                "PhaseCd": body.items[i].PhaseCd,
                "QuotaFactor": body.items[i].QuotaFactor,
                "RcmndWinProb": body.items[i].RcmndWinProb,
                "StageStatusCd": body.items[i].StageStatusCd,
                "StgOrder": body.items[i].StgOrder,
                "EffectiveDate": body.items[i].EffectiveDate,
                "Revenue": body.items[i].Revenue,
                "WinProb": body.items[i].WinProb,
                "SourceType": body.items[i].SourceType,
                "PrimaryContactPartyName": body.items[i].PrimaryContactPartyName,
                "PrimaryContactFormattedPhoneNumber": body.items[i].PrimaryContactFormattedPhoneNumber,
                "PrimaryContactEmailAddress": body.items[i].PrimaryContactEmailAddress,
                "Comments": body.items[i].Comments,
                "PartyName1": body.items[i].PartyName1,
                "EmailAddress": body.items[i].EmailAddress,
                "LookupCategory": body.items[i].LookupCategory,
                "OptyCreationDate": body.items[i].OptyCreationDate,
                "ExpectAmount": body.items[i].ExpectAmount,
                "OptyCreatedBy": body.items[i].OptyCreatedBy,
                "ForecastOverrideCode": body.items[i].ForecastOverrideCode,
                "OptyLastUpdateDate": body.items[i].OptyLastUpdateDate,
                "OptyLastUpdatedBy": body.items[i].OptyLastUpdatedBy,
                "SalesChannelCd": body.items[i].SalesChannelCd,
                "PredWinProb": body.items[i].PredWinProb,
                "TargetPartyName": body.items[i].TargetPartyName
            }
        // }
        }
        res.send({
            "CustomerId": customerId,
            "items": item
        });
    });
}

//////////////////-- engagement cloud APIs ends -----/////////////////////


/////////////////--- commerce cloud APIs starts ------//////////////

////-- Login API to commerce cloud. Need to call this API before any other API from commerce cloud --////

exports.login = (req, res) => {
    token = "";
    request.post({
        "headers": {
            "content-type": "application/x-www-form-urlencoded"
        },
        "url": cloudConfig.commerceCloud + "/ccadmin/v1/login",
        "form": {
            grant_type: "client_credentials",
            client_id: "1e6ef952-d8be-4bff-b6e6-749db87c99b1",
            client_secret: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxZTZlZjk1Mi1kOGJlLTRiZmYtYjZlNi03NDlkYjg3Yzk5YjEiLCJpc3MiOiJhcHBsaWNhdGlvbkF1dGgiLCJleHAiOjE1Njg3ODY0NTcsImlhdCI6MTUzNzI1MDQ1N30=.sLTISKBJ47F1RJGolHwT647KNNBTqWJuayuaWh3LTK8="
        }
    }, (error, response, body) => {
        if (error) {
            return console.dir(error);
            return console.warn(xhr.responseText)
        }
        var body = JSON.parse(body);

        res.send({
            "CustomerId":customerId,
            "access_token": body.access_token
        })
        global.token = body.access_token;
    });
}

////-- Commerce cloud API to get product list --/////

exports.getProducts = (req, res) => {
    console.dir(token);
    request.get({
        "headers": {
            "content-type": "application/json",
            "Authorization": "Bearer " + token
        },
        "url": cloudConfig.commerceCloud + "/ccstore/v1/products"

    }, (error, response, body) => {
        if (error) {
            return console.dir(error);

        }
        var body = JSON.parse(body);
        console.log(body.items);

        // for (let i = 0; i < body.items.length; i++) {
        //     product[i] = {
        //         "displayName": body.items[i].displayName,
        //         "description": body.items[i].description,
        //         "longDescription": body.items[i].longDescription,
        //         "addOnProducts": body.items[i].addOnProducts,
        //         "listPrice": body.items[i].listPrice,
        //         "type": body.items[i].type,
        //         "id": body.items[i].id,
        //         "orderLimit": body.items[i].orderLimit,
        //         "parentCategories": body.items[i].parentCategories,
        //         "seoKeywordsDerived": body.items[i].seoKeywordsDerived,
        //         "active": body.items[i].active,
        //         "route": body.items[i].route,
        //         "salePrice": body.items[i].salePrice,
        //         "brand": body.items[i].brand
        //     }
        // }
        res.send({
            "products": body.items
        });
    });
}

////////////--- commerce cloud APIs ends ---/////////

///////////--- mongoDB APIs starts ----/////////////

exports.createEnterpriseDetails = (req, res) => {
    var customers = new Customer({
        enterpriseName: req.body.enterpriseName,
        registrationNumber: req.body.registrationNumber,
        address: req.body.address,
        city: req.body.city,
        zip: req.body.zip,
        country: req.body.country,
        businessNature: req.body.businessNature,
        numberOfEmployees: req.body.numberOfEmployees,
        firstName: req.body.firstName,
        surName: req.body.surName,
        id: req.body.id,
        role: req.body.role,
        mobile: req.body.mobile
    });

    customers.save()
        .then(data => {
            res.send("success");
        })
        .catch(err => {
            res.status(500).send({
                message: err.message
            })
        });
}

exports.createOnboarded = (req, res) => {
    var customers = new Customer({
        comments: req.body.comments
    });

    customers.save()
        .then(data => {
            res.send("success");
        })
        .catch(err => {
            res.status(500).send({
                message: err.message
            })
        });
}

exports.postMenu = (req, res) => {
    var navbars = new Navbar({
        menu: req.body.menu
    })

    navbars.save()
        .then(data => {
            res.send("success");
        })
        .catch(err => {
            res.status(500).send({
                message: err.message
            })
        });
}

exports.getMenu = (req, res) => {
    Navbar.find()
        .then(navbars => {
            res.send(navbars);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving notes."
            });
        });
}

exports.updateMenu = (req, res) => {
    if (!req.body.menu) {
        return res.status(400).send({
            message: "menu content can not be empty"
        });
    }

    Navbar.findOneAndUpdate(req.params.menuId, {
        menu: req.body.menu
    }, { new: true })
        .then(navbars => {
            if (!navbars) {
                return res.status(404).send({
                    message: "menu not found with id " + req.params.menuId
                });
            }
            res.send(navbars);
        }).catch(err => {
            if (err.kind === 'ObjectId') {
                return res.status(404).send({
                    message: "menu not found with id " + req.params.menuId
                });
            }
            return res.status(500).send({
                message: "Error updating menu with id " + req.params.menuId
            });
        });
}

exports.getCustomerDetails = (req, res) => {
    NewCustomer.findById(req.params.customerId)
        .then(note => {
            if (!note) {
                return res.status(404).send({
                    message: "customer not found with id " + req.params.customerId
                });
            }
            res.send(note);
        }).catch(err => {
            if (err.kind === 'ObjectId') {
                return res.status(404).send({
                    message: "customer not found with id " + req.params.customerId
                });
            }
            return res.status(500).send({
                message: "Error retrieving customer with id " + req.params.customerId
            });
        });
}

exports.postScheduledDate = (req, res) => {
    var dates = new Date({
        name: req.body.name,
        date: req.body.date
    })
    dates.save()
        .then(date => {
            res.send("meeting scheduled on " + date.date + " for " + date.name);
        })
        .catch(err => {
            res.status(500).send({
                message: err.message
            })
        });
}

exports.getScheduledDate = (req, res) => {
    Date.find()
        .then(dates => {
            res.send(dates);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving notes."
            });
        });
}
//////-- mongoDB APIs ends --//////