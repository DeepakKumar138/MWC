module.exports = {
    url: "mongodb://deepak:dpak211211@ds143953.mlab.com:43953/mwc-application"
}