module.exports = {
    mailId:"dpak211211@gmail.com",
    password:"dpak211211Madhavlaldas",
    salesMailId:"rapidsbusiness@gmail.com",
    custMailId:"rapidscustomer@gmail.com"
}