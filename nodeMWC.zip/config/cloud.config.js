module.exports = {
    commerceCloud:"https://ccadmin-z0ya.oracleoutsourcing.com",
    engagementCloud:"https://ejtp.fa.em2.oraclecloud.com/crmRestApi/resources/11.13.18.05"
}