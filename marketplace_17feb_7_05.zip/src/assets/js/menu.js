/*global jQuery:false */
jQuery(document).ready(function($) {
"use strict";
		
	(function() {

		var $menu = $('.navigation nav'),
			optionsList = '<option value="" selected>Go to..</option>';

		$menu.find('li').each(function() {
			var $this   = $(this),
				$anchor = $this.children('a'),
				depth   = $this.parents('ul').length - 1,
				indent  = '';

			if( depth ) {
				while( depth > 0 ) {
					indent += ' - ';
					depth--;
				}

			}
			$(".nav li").parent().addClass("bold");

			optionsList += '<option value="' + $anchor.attr('href') + '">' + indent + ' ' + $anchor.text() + '</option>';
		}).end()
		.after('<select class="selectmenu">' + optionsList + '</select>');
		
		$('select.selectmenu').on('change', function() {
			window.location = $(this).val();
		});
		
	})();
		
});

// Remove Last Border of li
$(".multilevel_drop li a:last").addClass("border-last"); 
$(".sub-menu li a:last").addClass("border-last"); 


function funreasmeu(x) {
  	if (x.matches) { // If media query matches
  		$('ul.navbar-nav li.dropdown').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true);
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true);
		});

  	 	$(".dropdown > a").click(function(){
		  	// $(".multilevel_drop").css("display", "block");
		  	 $(this).parent().find('.multilevel_drop').slideToggle('slow');

		  	// event.preventDefault();
		  	// $(".multilevel_drop").toggle();

		});
	
		$(".multilevel_drop > li > a").click(function(){
		  	$(".sub-menu").css("visibility","visible");
		  	$(".sub-menu").css("min-height","auto");
		  	$(".sub-menu").css("position","relative");

			$(this).parent().find('.sub-menu').slideToggle('slow');
          });
          
          $(".sub-menu > li > a").click(function(){
            $(".sub-menu-level2").css("visibility","visible");
            $(".sub-menu-level2").css("min-height","auto");
            $(".sub-menu-level2").css("position","relative");
            $(".sub-menu-level2").css("left","30px");
            $(".sub-menu-level2").css("border","none");
            $(this).parent().find('.sub-menu-level2').slideToggle('slow');
        });
  	} 
  	else {
  		//Navi hover
		$('ul.navbar-nav li.dropdown').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn();
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut();
		});
  		$(".sub-menu").css("position","absolute");
  	}
}

var x = window.matchMedia("(max-width:767px)")
funreasmeu(x) // Call listener function at run time
x.addListener(funreasmeu) // Attach listener function on state changes
 

/* ---------------------------------------------------
	Quantity minus and plus
-------------------------------------------------- */
$(function ($) {
    "use strict";
	//Quantity plus minus 
    $.initQuantity = function ($control) {
        $control.each(function () {
            var $this = $(this),
                data = $this.data("inited-control"),
                $plus = $(".input-group-text:last", $this),
                $minus = $(".input-group-text:first", $this),
                $value = $(".form-control", $this);
            if (!data) {
                $control.attr("unselectable", "on").css({
                    "-moz-user-select": "none",
                    "-o-user-select": "none",
                    "-khtml-user-select": "none",
                    "-webkit-user-select": "none",
                    "-ms-user-select": "none",
                    "user-select": "none"
                }).bind("selectstart", function () {
                    return false
                });
                $plus.click(function () {
                    var val =
                        parseInt($value.val()) + 1;
                    $value.val(val);
                    return false
                });
                $minus.click(function () {
                    var val = parseInt($value.val()) - 1;
                    $value.val(val > 0 ? val : 1);
                    return false
                });
                $value.blur(function () {
                    var val = parseInt($value.val());
                    $value.val(val > 0 ? val : 1)
                })
            }
        })
    };
    $.initQuantity($(".quantity-control"));
    $.initSelect = function ($select) {
        $select.each(function () {
            var $this = $(this),
                data = $this.data("inited-select"),
                $value = $(".value", $this),
                $hidden = $(".input-hidden", $this),
                $items = $(".dropdown-menu li > a", $this);
            if (!data) {
                $items.click(function (e) {
                    if ($(this).closest(".sort-isotope").length >
                        0) e.preventDefault();
                    var data = $(this).attr("data-value"),
                        dataHTML = $(this).html();
                    $this.trigger("change", {
                        value: data,
                        html: dataHTML
                    });
                    $value.html(dataHTML);
                    if ($hidden.length) $hidden.val(data)
                });
                $this.data("inited-select", true)
            }
        })
    };
    $.initSelect($(".btn-select"));
	
	if(!window.startRangeValues) return;
	var startValues = window.startRangeValues,
		min = startValues[0].toFixed(2),
		max = startValues[1].toFixed(2);

	$('.filter_reset').on('click', function(){

		var form = $(this).closest('form'),
			range = form.find('.range');

			console.log(startValues);

		// form.find('#slider').slider('option','values', startValues);

		form.find('#slider').slider('values', 0, min);
		form.find('#slider').slider('values', 1, max);

		form.find('.options_list').children().eq(0).children().trigger('click');

		range.children('.min_value').val(min).next().val(max);

		range.children('.min_val').text('$' + min).next().text('$' + max);

	});
	
	
});





$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
  if (!$(this).next().hasClass('show')) {
    $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
  }
  var $subMenu = $(this).next(".dropdown-menu");
  $subMenu.toggleClass('show');


  $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
    $('.dropdown-submenu .show').removeClass("show");
  });


  return false;
});
