export const environment = {
  production: true,
  add:false,
  firebase:{
    apiKey: "AIzaSyDor05Odzj_6FywrxyQZ2z5dnSNYB3BwYc",
    authDomain: "smsapp-b948e.firebaseapp.com",
    databaseURL: "https://smsapp-b948e.firebaseio.com",
    projectId: "smsapp-b948e",
    storageBucket: "",
    messagingSenderId: "588137407598"
  },
  urls:{
    nodeBackend: 'http://52.5.252.249:3000',
    cmsUrl:'http://52.5.252.249:8080',
    morphUrl:'http://52.6.121.116/#',
    // morphUrl:'http://localhost:4300'
  }
};
