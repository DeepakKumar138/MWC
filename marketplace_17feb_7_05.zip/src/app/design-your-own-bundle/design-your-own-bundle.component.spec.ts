import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignYourOwnBundleComponent } from './design-your-own-bundle.component';

describe('DesignYourOwnBundleComponent', () => {
  let component: DesignYourOwnBundleComponent;
  let fixture: ComponentFixture<DesignYourOwnBundleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesignYourOwnBundleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignYourOwnBundleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
