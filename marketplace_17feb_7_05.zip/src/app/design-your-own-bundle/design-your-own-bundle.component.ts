import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product';
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
declare var bandwidth: String;

@Component({
  selector: 'app-design-your-own-bundle',
  templateUrl: './design-your-own-bundle.component.html',
  styleUrls: ['./design-your-own-bundle.component.css']
})
export class DesignYourOwnBundleComponent implements OnInit {

  bandwidth: number = 0;
  location: number = 0;
  employe: number = 0;
  latency: number = 0;
  Contract: number = 0;
  channel: number = 0;
  // ch_options:number = 0;
  cart_btn: String;
  Hours:number = 0;
  reliability:number = 0;
  isolation:number = 0;
  options: Options = {
    floor: 0,
    ceil: 1024
  };

  l_options: Options = {
    floor: 0,
    ceil: 15
  };
  ch_options: Options = {
    floor: 0,
    ceil: 15
  };
  fortinet:String;
  cisco:String;


  locations = ['Indoor - 500 Mbps (Default)', 'Dense Urban - 100 Mbps ', 'Broadcast services - 300 Mbps', 'Rural - 100 Mbps'];
  loc = "";
  availability = ['99.999% ( 5 mins downtime/Year) - Default', '99.9999% ( 31 secs downtime/Year) - + $ 399.00', '99.99999% ( 3 secs downtime/Year) - + $ 699.00', '99.999999% ( 315 milisecs downtime/Year) - + $ 999.00'];
  avail = "";
  route: string;

  i_product = [];
  e_product = [];
  c_product = [];
  s_product = [];
  viewDetail = [];
  total_bundle_cost = 0;
  bundle_name: String;
  cart_update: Number;
  status = 0;
  constructor(private service:ServiceService) { }

  ngOnInit() {

    this.service.login().subscribe((data:any)=>{
      this.service.getProduct().subscribe((data:any)=>{
        console.log(data);
        localStorage.setItem('product_internet',JSON.stringify(data));
      });
    });

    // image gallery
    $(".image-checkbox").each(function () {
      if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
        $(this).addClass('image-checkbox-checked ');

      }
      else {
        $(this).removeClass('image-checkbox-checked');
      }
    });

    // sync the state to the input
    $(".image-checkbox").on("click", function (e) {
      $(this).toggleClass('proicon_chkbox phovercontent_active');
      // $(this).toggleClass('image-checkbox-checked');
      var $checkbox = $(this).find('input[type="checkbox"]');
      $checkbox.prop("checked", !$checkbox.prop("checked"))

      e.preventDefault();
    });

    this.viewTempBundle();
  }




  show_product() {
    this.i_getAllProduct();
    $('#product_carousel').css('display', 'block');
    // console.log(' hlloe '+this.bandwidth);


  }
  e_show_product() {
    this.e_getAllProduct();
    $('#product_carousel').css('display', 'block');
  }
  c_show_product() {
    this.c_getAllProduct();
    $('#product_carousel').css('display', 'block');
  }
  s_show_product() {
    this.s_getAllProduct();
    $('#product_carousel').css('display', 'block');
  }
  // internet product
  i_getAllProduct() {
    this.i_product = [];
    // this.cart_btn = "Add to cart";
    let tempproduct = {

    }
    // let tempB = null;
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    console.log(temp_product);


    for (let index = 0; index < temp_product.products.length; index++) {


      if (temp_product.products[index].parentCategories[0].repositoryId == 'CON_001') {
        let tempdata = {
          catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
          id: temp_product.products[index].id,
          rid: temp_product.products[index].parentCategories[0].repositoryId,
          type: temp_product.products[index].type,
          displayName: temp_product.products[index].displayName,
          salePrice: temp_product.products[index].listPrice,
          bandwidth: temp_product.products[index].x_bANDWIDTH,
          recurrencecost: temp_product.products[index].x_recurrencecost,
          recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
          description: temp_product.products[index].description
        }
        this.i_product.push(tempdata);
        this.i_product.forEach((item, index) => {
          if (index !== this.i_product.findIndex(i => i.id === item.id)) {
            this.i_product.splice(index, 1);
          }

        });
        //   let tempB = temp_product.products[index].x_bANDWIDTH.split(' ')
        //   if (tempB[1] == "Gbps") {
        //     tempB[0] = tempB[0]*1024;

        //   }
        //   console.log('hello',tempB[0]);
        //   console.log(this.bandwidth);

        //   if (tempB[0] <= this.bandwidth && this.bandwidth <= 100 && tempB[0] <= 100) {
        //     let tempdata = {
        //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //       id: temp_product.products[index].id,
        //       type: temp_product.products[index].type,
        //       displayName: temp_product.products[index].displayName,
        //       salePrice: temp_product.products[index].listPrice,
        //       bandwidth: temp_product.products[index].x_bANDWIDTH,
        //       recurrencecost: temp_product.products[index].x_recurrencecost,
        //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //       description: temp_product.products[index].description
        //     }
        //     this.product.push(tempdata);
        //     this.product.forEach((item, index) => {
        //       if (index !== this.product.findIndex(i => i.id === item.id)) {
        //         this.product.splice(index, 1);
        //       }

        //     });
        //     tempB = null;

        //     console.log(this.product);

        //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
        //   }

        //  else if (tempB[0] <= this.bandwidth && this.bandwidth <= 500) {
        //     let tempdata = {
        //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //       id: temp_product.products[index].id,
        //       type: temp_product.products[index].type,
        //       displayName: temp_product.products[index].displayName,
        //       salePrice: temp_product.products[index].listPrice,
        //       bandwidth: temp_product.products[index].x_bANDWIDTH,
        //       recurrencecost: temp_product.products[index].x_recurrencecost,
        //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //       description: temp_product.products[index].description
        //     }
        //     this.product.push(tempdata);
        //     this.product.forEach((item, index) => {
        //       if (index !== this.product.findIndex(i => i.id === item.id)) {
        //         this.product.splice(index, 1);
        //       }

        //     });
        //     tempB = null;

        //     console.log(this.product);

        //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
        //   }

        //   else if ( tempB[0] > '500' && tempB[0] <= this.bandwidth ) {
        //     let tempdata = {
        //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //       id: temp_product.products[index].id,
        //       type: temp_product.products[index].type,
        //       displayName: temp_product.products[index].displayName,
        //       salePrice: temp_product.products[index].listPrice,
        //       bandwidth: temp_product.products[index].x_bANDWIDTH,
        //       recurrencecost: temp_product.products[index].x_recurrencecost,
        //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //       description: temp_product.products[index].description
        //     }
        //     this.product.push(tempdata);
        //     this.product.forEach((item, index) => {
        //       if (index !== this.product.findIndex(i => i.id === item.id)) {
        //         this.product.splice(index, 1);
        //       }

        //     });
        //     tempB = null;

        //     console.log('hello',this.product);

        //   }
      }

    }

  }


  // ethernet product
  e_getAllProduct() {
    let bandwidthValueID = $("#bandwidthValueID")[0]['innerText'];

    let needToValid = 1;

    console.log(needToValid);

    this.e_product = [];
    // this.cart_btn = "Add to cart";
    let tempproduct = {}
    // let tempB = null;
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    console.log(temp_product);
    for (let index = 0; index < temp_product.products.length; index++) {
      let price = 0;
      if (temp_product.products[index].x_recurrencecost != null) {
        price = temp_product.products[index].x_recurrencecost;
        //   price = (Number(price) > 0) ? price : 0;  
      }

      if (temp_product.products[index].parentCategories[0].repositoryId == 'CON_002') {


        let tempdata = {
          catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
          id: temp_product.products[index].id,
          rid: temp_product.products[index].parentCategories[0].repositoryId,
          type: temp_product.products[index].type,
          displayName: temp_product.products[index].displayName,
          salePrice: temp_product.products[index].listPrice,
          bandwidth: temp_product.products[index].x_bANDWIDTH,
          recurrencecost: price,
          recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
          description: temp_product.products[index].description
        }
        this.e_product.push(tempdata);
        this.e_product.forEach((item, index) => {
          if (index !== this.e_product.findIndex(i => i.id === item.id)) {
            this.e_product.splice(index, 1);
          }

        });


        // localStorage.setItem('product_internet', JSON.stringify(this.product));

      }

    }

  }

  // content product
  c_getAllProduct() {
    this.c_product = [];
    // this.cart_btn = "Add to cart";
    let tempproduct = {

    }
    // let tempB = null;
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    console.log(temp_product);


    for (let index = 0; index < temp_product.products.length; index++) {

      if (temp_product.products[index].parentCategories[0].repositoryId == 'CONTC_001') {
        let tempdata = {
          catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
          id: temp_product.products[index].id,
          rid: temp_product.products[index].parentCategories[0].repositoryId,
          type: temp_product.products[index].type,
          displayName: temp_product.products[index].displayName,
          salePrice: temp_product.products[index].listPrice,
          channel: temp_product.products[index].x_cHANNEL,
          recurrencecost: temp_product.products[index].x_recurrencecost,
          recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
          description: temp_product.products[index].description
        }
        this.c_product.push(tempdata);
        this.c_product.forEach((item, index) => {
          if (index !== this.c_product.findIndex(i => i.id === item.id)) {
            this.c_product.splice(index, 1);
          }

        });


        console.log(this.c_product);


        //   if (temp_product.products[index].x_cHANNEL <= this.channel &&  this.channel <= 100 && temp_product.products[index].x_cHANNEL <= 100) {
        //     let tempdata = {
        //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //       id: temp_product.products[index].id,
        //       type: temp_product.products[index].type,
        //       displayName: temp_product.products[index].displayName,
        //       salePrice: temp_product.products[index].listPrice,
        //       channel: temp_product.products[index].x_cHANNEL,
        //       recurrencecost: temp_product.products[index].x_recurrencecost,
        //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //       description: temp_product.products[index].description
        //     }
        //     this.product.push(tempdata);
        //     this.product.forEach((item, index) => {
        //       if (index !== this.product.findIndex(i => i.id === item.id)) {
        //         this.product.splice(index, 1);
        //       }

        //     });


        //     console.log(this.product);

        //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
        //   }
        //  else if (temp_product.products[index].x_cHANNEL <= this.channel &&  this.channel <= 300 && temp_product.products[index].x_cHANNEL <= 300) {
        //     let tempdata = {
        //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //       id: temp_product.products[index].id,
        //       type: temp_product.products[index].type,
        //       displayName: temp_product.products[index].displayName,
        //       salePrice: temp_product.products[index].listPrice,
        //       channel: temp_product.products[index].x_cHANNEL,
        //       recurrencecost: temp_product.products[index].x_recurrencecost,
        //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //       description: temp_product.products[index].description
        //     }
        //     this.product.push(tempdata);
        //     this.product.forEach((item, index) => {
        //       if (index !== this.product.findIndex(i => i.id === item.id)) {
        //         this.product.splice(index, 1);
        //       }

        //     });


        //     console.log(this.product);

        //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
        //   }

        //   else if (temp_product.products[index].x_cHANNEL > 300) {
        //     let tempdata = {
        //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //       id: temp_product.products[index].id,
        //       type: temp_product.products[index].type,
        //       displayName: temp_product.products[index].displayName,
        //       salePrice: temp_product.products[index].listPrice,
        //       bandwidth: temp_product.products[index].x_bANDWIDTH,
        //       recurrencecost: temp_product.products[index].x_recurrencecost,
        //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //       description: temp_product.products[index].description
        //     }
        //     this.product.push(tempdata);
        //     this.product.forEach((item, index) => {
        //       if (index !== this.product.findIndex(i => i.id === item.id)) {
        //         this.product.splice(index, 1);
        //       }

        //     });


        //     console.log(this.product);

        //   }
      }

    }

  }


  // security product
  s_getAllProduct() {

    let fortinet = ($('#fortinet').is(":checked")) ? 1 : 0;
    let cisco = ($('#cisco').is(":checked")) ? 1 : 0;

    let bandwidthValueID = $("#bandwidthValueID")[0]['innerText'];

    let needToValid = 1 + Number(fortinet) + Number(cisco);

    console.log(needToValid);

    this.s_product = [];
    // this.cart_btn = "Add to cart";
    let tempproduct = {}
    // let tempB = null;
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    console.log(temp_product);

    for (let index = 0; index < temp_product.products.length; index++) {

      if (temp_product.products[index].parentCategories[0].repositoryId == 'SECC_001') {

        let tempdata = {
          catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
          id: temp_product.products[index].id,
          rid: temp_product.products[index].parentCategories[0].repositoryId,

          type: temp_product.products[index].type,
          displayName: temp_product.products[index].displayName,
          salePrice: temp_product.products[index].listPrice,
          bandwidth: temp_product.products[index].x_bANDWIDTH,
          recurrencecost: temp_product.products[index].x_recurrencecost,
          recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
          description: temp_product.products[index].description
        }
        this.s_product.push(tempdata);
        this.s_product.forEach((item, index) => {
          if (index !== this.s_product.findIndex(i => i.id === item.id)) {
            this.s_product.splice(index, 1);
          }

        });
        // tempB = null;

        console.log(this.s_product);
        let tempB = temp_product.products[index].x_bANDWIDTH.split(' ')
        console.log(tempB[0]);
        console.log(this.bandwidth);
        //  if (tempB[1] == "Gbps") {
        //    tempB[0] = tempB[0]*1024;

        //  }
        //  // console.log('hello',tempB[0]);
        //  console.log(this.bandwidth);

        //  if (tempB[0] <= this.bandwidth && this.bandwidth <= 100 && tempB[0] <= 100) {

        //    if(this.cisco && temp_product.products[index].x_hARDWARE=="CISCO"){

        //        let tempdata = {
        //            catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //            id: temp_product.products[index].id,
        //            type: temp_product.products[index].type,
        //            displayName: temp_product.products[index].displayName,
        //            salePrice: temp_product.products[index].listPrice,
        //            bandwidth: temp_product.products[index].x_bANDWIDTH,
        //            recurrencecost: temp_product.products[index].x_recurrencecost,
        //            recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //            description: temp_product.products[index].description
        //          }
        //          this.product.push(tempdata);
        //          this.product.forEach((item, index) => {
        //            if (index !== this.product.findIndex(i => i.id === item.id)) {
        //              this.product.splice(index, 1);
        //            }

        //          });
        //          tempB = null;

        //          console.log(this.product);
        //    }    
        //    else if(this.fortinet && temp_product.products[index].x_hARDWARE=="FORTINET"){

        //    let tempdata = {
        //        catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //        id: temp_product.products[index].id,
        //        type: temp_product.products[index].type,
        //        displayName: temp_product.products[index].displayName,
        //        salePrice: temp_product.products[index].listPrice,
        //        bandwidth: temp_product.products[index].x_bANDWIDTH,
        //        recurrencecost: temp_product.products[index].x_recurrencecost,
        //        recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //        description: temp_product.products[index].description
        //      }
        //      this.product.push(tempdata);
        //      this.product.forEach((item, index) => {
        //        if (index !== this.product.findIndex(i => i.id === item.id)) {
        //          this.product.splice(index, 1);
        //        }

        //      });
        //      tempB = null;

        //      console.log(this.product);
        //    }

        //    // localStorage.setItem('product_internet', JSON.stringify(this.product));
        //  }

        //  if (tempB[0] <= this.bandwidth && this.bandwidth <= 500) {

        //    if(this.cisco && temp_product.products[index].x_hARDWARE=="CISCO"){

        //        let tempdata = {
        //            catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //            id: temp_product.products[index].id,
        //            type: temp_product.products[index].type,
        //            displayName: temp_product.products[index].displayName,
        //            salePrice: temp_product.products[index].listPrice,
        //            bandwidth: temp_product.products[index].x_bANDWIDTH,
        //            recurrencecost: temp_product.products[index].x_recurrencecost,
        //            recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //            description: temp_product.products[index].description
        //          }
        //          this.product.push(tempdata);
        //          this.product.forEach((item, index) => {
        //            if (index !== this.product.findIndex(i => i.id === item.id)) {
        //              this.product.splice(index, 1);
        //            }

        //          });
        //          tempB = null;

        //          console.log(this.product);
        //    }    
        //    else if(this.fortinet && temp_product.products[index].x_hARDWARE=="FORTINET"){

        //    let tempdata = {
        //        catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //        id: temp_product.products[index].id,
        //        type: temp_product.products[index].type,
        //        displayName: temp_product.products[index].displayName,
        //        salePrice: temp_product.products[index].listPrice,
        //        bandwidth: temp_product.products[index].x_bANDWIDTH,
        //        recurrencecost: temp_product.products[index].x_recurrencecost,
        //        recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //        description: temp_product.products[index].description
        //      }
        //      this.product.push(tempdata);
        //      this.product.forEach((item, index) => {
        //        if (index !== this.product.findIndex(i => i.id === item.id)) {
        //          this.product.splice(index, 1);
        //        }

        //      });
        //      tempB = null;

        //      console.log(this.product);
        //    }


        //    // localStorage.setItem('product_internet', JSON.stringify(this.product));
        //  }

        //  else if ( tempB[0] > 500 ) {
        //    if(this.cisco  && temp_product.products[index].x_hARDWARE=="CISCO"){

        //        let tempdata = {
        //            catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //            id: temp_product.products[index].id,
        //            type: temp_product.products[index].type,
        //            displayName: temp_product.products[index].displayName,
        //            salePrice: temp_product.products[index].listPrice,
        //            bandwidth: temp_product.products[index].x_bANDWIDTH,
        //            recurrencecost: temp_product.products[index].x_recurrencecost,
        //            recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //            description: temp_product.products[index].description
        //          }
        //          this.product.push(tempdata);
        //          this.product.forEach((item, index) => {
        //            if (index !== this.product.findIndex(i => i.id === item.id)) {
        //              this.product.splice(index, 1);
        //            }

        //          });
        //          tempB = null;

        //          console.log(this.product);
        //    }  
        //      else if(this.fortinet && temp_product.products[index].x_hARDWARE=="FORTINET"){

        //    let tempdata = {
        //        catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
        //        id: temp_product.products[index].id,
        //        type: temp_product.products[index].type,
        //        displayName: temp_product.products[index].displayName,
        //        salePrice: temp_product.products[index].listPrice,
        //        bandwidth: temp_product.products[index].x_bANDWIDTH,
        //        recurrencecost: temp_product.products[index].x_recurrencecost,
        //        recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
        //        description: temp_product.products[index].description
        //      }
        //      this.product.push(tempdata);
        //      this.product.forEach((item, index) => {
        //        if (index !== this.product.findIndex(i => i.id === item.id)) {
        //          this.product.splice(index, 1);
        //        }

        //      });
        //      tempB = null;

        //      console.log(this.product);
        //    }



        //  }
      }

    }
  }


  // temp save bundle
  saveBundle(id, pid) {

    // document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove" ? "Add to cart" : "Remove";

    let p_id = pid;
    let r_id = id;
    // this.cart_btn ="Remove";
    let savebundle = [];
    console.log(r_id);

    if (r_id == "CON_001") {
      // console.log(p_id);

      for (let index = 0; index < this.i_product.length; index++) {
        if (this.i_product[index].id === p_id) {
          // this.modal_prodcut_name = this.i_product[index].displayName;
          let internet = {
            id: this.i_product[index].id,
            displayName: this.i_product[index].displayName,
            salePrice: this.i_product[index].salePrice,
            bandwidth: this.i_product[index].bandwidth,
            recurrencecost: this.i_product[index].recurrencecost,
            recurrencePeriod: this.i_product[index].recurrencePeriod,

          }

          if (JSON.parse(localStorage.getItem("savebundle")) == null) {
            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            // environment.savebundle.push(internet)
            console.log(localStorage.getItem('savebundle'));

          }
          else {
            savebundle = JSON.parse(localStorage.getItem("savebundle"));

            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            //  console.log()
            // console.log(localStorage.getItem('savebundle'));

          }
        }

      }
      // console.log(localStorage.getItem('savebundle'));

    }

    else if (r_id == "CON_002") {
      console.log(p_id);

      for (let index = 0; index < this.e_product.length; index++) {
        if (this.e_product[index].id === p_id) {
          // this.modal_prodcut_name = this.i_product[index].displayName;
          let internet = {
           
            id: this.e_product[index].id,
            displayName: this.e_product[index].displayName,
            salePrice: this.e_product[index].salePrice,
            bandwidth: this.e_product[index].bandwidth,
            recurrencecost: this.e_product[index].recurrencecost,
            recurrencePeriod: this.e_product[index].recurrencePeriod,

          }

          if (JSON.parse(localStorage.getItem("savebundle")) == null) {
            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            // environment.savebundle.push(internet)
          }
          else {
            savebundle = JSON.parse(localStorage.getItem("savebundle"));

            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            //  console.log()
          }
        }

      }
    }
    else if (r_id == "CONTC_001") {
      for (let index = 0; index < this.c_product.length; index++) {
        if (this.c_product[index].id === p_id) {
          // this.modal_prodcut_name = this.i_product[index].displayName;
          let internet = {
            
            id: this.c_product[index].id,
            displayName: this.c_product[index].displayName,
            salePrice: this.c_product[index].salePrice,
            bandwidth: this.c_product[index].bandwidth,
            recurrencecost: this.c_product[index].recurrencecost,
            recurrencePeriod: this.c_product[index].recurrencePeriod,

          }

          if (JSON.parse(localStorage.getItem("savebundle")) == null) {
            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            // environment.savebundle.push(internet)
          }
          else {
            savebundle = JSON.parse(localStorage.getItem("savebundle"));

            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            //  console.log()
          }
        }

      }
    }

    else if (r_id == "SECC_001") {
      for (let index = 0; index < this.s_product.length; index++) {
        if (this.s_product[index].id === p_id) {
          // this.modal_prodcut_name = this.s_product[index].displayName;
          let internet = {
            
            id: this.s_product[index].id,
            displayName: this.s_product[index].displayName,
            salePrice: this.s_product[index].salePrice,
            bandwidth: this.s_product[index].bandwidth,
            recurrencecost: this.s_product[index].recurrencecost,
            recurrencePeriod: this.s_product[index].recurrencePeriod,

          }

          if (JSON.parse(localStorage.getItem("savebundle")) == null) {
            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            // environment.savebundle.push(internet)
          }
          else {
            savebundle = JSON.parse(localStorage.getItem("savebundle"));

            savebundle.push(internet);
            localStorage.setItem('savebundle', JSON.stringify(savebundle));
            //  console.log()
          }
        }

      }
    }


    // console.log(environment.internet_cart);
    // this.router.navigate(['cart_summary/']);
    // let add_to_cart_val=document.getElementById('headCount').innerText;
    // document.getElementById('headCount').innerText=String(Number(add_to_cart_val)+1);

    console.log(localStorage.getItem('savebundle'));
    this.viewTempBundle();
  }

  // final save bundle and add to cart
  save() {
    let prod =[];
    let product=[];
    let tempbundle = JSON.parse(localStorage.getItem('savebundle'));
    let  final_bundle = {
      bundleName: this.bundle_name,
      product_Array: tempbundle
    }
product.push(final_bundle);

    // final_bundle.push(tempbundle,this.bundle_name)
    // localStorage.setItem('bundle_info', JSON.stringify(final_bundle));


    if (JSON.parse(localStorage.getItem("bundle_info")) == null ) {
      localStorage.setItem('bundle_info', JSON.stringify(product));
      // environment.internet_cart.push(internet)
    }
    else{
      prod = JSON.parse(localStorage.getItem("bundle_info"));
    
      prod.push(final_bundle);
      localStorage.setItem('bundle_info', JSON.stringify(prod));
    //  console.log()
    } // final_bundle.push(tempbundle,this.bundle_name)
    let temp = JSON.parse(localStorage.getItem('bundle_info'));


    this.status = 1;
    console.log('hello', JSON.parse(localStorage.getItem('bundle_info')));

   
    let add_to_cart_val = document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText = String(Number(add_to_cart_val) + 1);

    localStorage.removeItem('savebundle');
    this.viewTempBundle();
  }
  edit() {
    this.status = 0;
  }

  fsaveBundle() {
    let tempbundle =[];
    let t_cart:any;
    this.status = 1;
      let temp_array =[];
    
    tempbundle = JSON.parse(localStorage.getItem('savebundle'));
     let  final_bundle = {
      bundleName: this.bundle_name,
      product_Array: tempbundle
    }
    temp_array.push(final_bundle);      

    t_cart = JSON.parse(localStorage.getItem('e_savebundle'));
    if (t_cart != null) {
      for (let index = 0; index < t_cart.length; index++) {
        temp_array.push(t_cart[index]);      
        
      }
    }
    console.log(temp_array);
    console.log('old',t_cart);

    // final_bundle.push(tempbundle,this.bundle_name)
    localStorage.setItem('e_savebundle', JSON.stringify(temp_array));

  }

  // view bundle Detail
  viewTempBundle() {
    this.total_bundle_cost = 0;

    this.viewDetail = JSON.parse(localStorage.getItem('savebundle'));

      console.log(this.viewDetail);
      
    console.log(this.viewDetail);
    if(this.viewDetail !=null){
    for (let index = 0; index < this.viewDetail.length; index++) {
      this.total_bundle_cost = Number(this.total_bundle_cost) + Number(this.viewDetail[index].recurrencecost);

    }

  }



  }

  // remove one item for bundle
  removeItem(id) {
    let temp_id = id;
    this.viewDetail = JSON.parse(localStorage.getItem('savebundle'));

    this.viewDetail.forEach((item, index) => {
      if (index !== this.viewDetail.findIndex(i => i.id === temp_id)) {
        this.viewDetail.splice(index, 1);
      }
      localStorage.setItem('savebundle', JSON.stringify(this.viewDetail));

    });

    this.viewTempBundle();
  }


  // clear savebundle
  clear_saveBundle() {
    localStorage.removeItem('savebundle');
    localStorage.removeItem('e_savebundle');
    this.status = 0
    this.bundle_name ="";
    this.viewTempBundle();
  }

}
