import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartSummaryNewComponent } from './cart-summary-new.component';

describe('CartSummaryNewComponent', () => {
  let component: CartSummaryNewComponent;
  let fixture: ComponentFixture<CartSummaryNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartSummaryNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartSummaryNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
