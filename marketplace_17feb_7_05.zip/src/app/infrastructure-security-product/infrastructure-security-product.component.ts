import { Component,ElementRef, OnInit } from '@angular/core';
declare var $: any;
import {OwlCarousel} from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product';
declare var bandwidth: String;
import { ActivatedRoute, Router } from '@angular/router';
import { Options } from 'ng5-slider';

@Component({
  selector: 'app-infrastructure-security-product',
  templateUrl: './infrastructure-security-product.component.html',
  styleUrls: ['./infrastructure-security-product.component.css']
})
export class InfrastructureSecurityProductComponent implements OnInit {

  bandwidth: number = 0;
  location: number = 1;
  contract: number = 1;
  product= [];
  modal_prodcut_name:string;
 options: Options = {
       floor: 10,
       ceil: 10000
   };

   c_options: Options = {
       floor: 1,
       ceil: 50
   };
   l_options: Options = {
       floor: 1,
       ceil: 110
   };

   //for check box
   fortinet: any;
   cisco : any;
   
 constructor(private service: ServiceService,
    private route: ActivatedRoute,
    private router: Router,) { }

 ngOnInit() {

    this.service.login().subscribe((data:any)=>{
        this.service.getProduct().subscribe((data:any)=>{
          console.log(data);
          localStorage.setItem('product_internet',JSON.stringify(data));
        });
      });

   // (function () {

   //   let selector = '[data-rangeSlider]',
   //     elements = document.querySelectorAll(selector);
   //   // Basic rangeSlider initialization
   //   rangeSlider.create(elements, {

   //     // Callback function
   //     onInit: function () {
   //     },

   //     // Callback function
   //     onSlideStart: function (value, percent, position) {
   //       console.info('onSlideStart', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
   //     },

   //     // Callback function
   //     onSlide: function (value, percent, position) {
   //       console.log('onSlide', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
   //     },

   //     // Callback function
   //     onSlideEnd: function (value, percent, position) {
   //       console.warn('onSlideEnd', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
   //     }
   //   });
   // })();
   

   $('.fitment-carousel').owlCarousel({
     loop:true,
     margin:10,
     nav:true,
      navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
     responsive:{
         0:{
             items:1
         },
         600:{
             items:2
         },
         1000:{
             items:2
         }
     }
 })



 $('.rightpro-carousel').owlCarousel({
     loop:true,
     margin:10,
     nav:true,
      navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
     responsive:{
         0:{
             items:1
         },
         600:{
             items:2
         },
         1000:{
             items:3
         }
     }
 })
 // image gallery
 $(".image-checkbox").each(function () {
   if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
     $(this).addClass('image-checkbox-checked');
   }
   else {
     $(this).removeClass('image-checkbox-checked');
   }
 });

 // sync the state to the input
 $(".image-checkbox").on("click", function (e) {
   $(this).toggleClass('image-checkbox-checked phovercontent_active proicon_chkbox');
   let $checkbox = $(this).find('input[type="checkbox"]');
   $checkbox.prop("checked",!$checkbox.prop("checked"))

   e.preventDefault();
 });
 }

 show_product()
   {
       this.getAllProduct();
       $('#product_carousel').css('display', 'block');
       // console.log(' hlloe '+this.bandwidth);
   }

   getAllProduct()
   {

       let fortinet = ($('#fortinet').is(":checked")) ? 1 : 0;
       let cisco = ($('#cisco').is(":checked")) ? 1 : 0;
       
       let bandwidthValueID = $("#bandwidthValueID")[0]['innerText'];
       
       let needToValid = 1 + Number(fortinet) + Number(cisco);

       console.log(needToValid);

       this.product = [];
       // this.cart_btn = "Add to cart";
       let tempproduct = {}
       // let tempB = null;
       let temp_product = JSON.parse(localStorage.getItem('product_internet'));
       console.log(temp_product);
  
       for (let index = 0; index < temp_product.products.length; index++) {

           if (temp_product.products[index].parentCategories[0].repositoryId == 'SECC_001') {

            let tempdata = {
              catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
              id: temp_product.products[index].id,
              type: temp_product.products[index].type,
              displayName: temp_product.products[index].displayName,
              salePrice: temp_product.products[index].listPrice,
              bandwidth: temp_product.products[index].x_bANDWIDTH,
              recurrencecost: temp_product.products[index].x_recurrencecost,
              recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
              description: temp_product.products[index].description
            }
            this.product.push(tempdata);
            this.product.forEach((item, index) => {
              if (index !== this.product.findIndex(i => i.id === item.id)) {
                this.product.splice(index, 1);
              }
  
            });
            // tempB = null;
  
            console.log(this.product);
             let tempB = temp_product.products[index].x_bANDWIDTH.split(' ')
             console.log(tempB[0]);
             console.log(this.bandwidth);
            //  if (tempB[1] == "Gbps") {
            //    tempB[0] = tempB[0]*1024;
               
            //  }
            //  // console.log('hello',tempB[0]);
            //  console.log(this.bandwidth);
     
            //  if (tempB[0] <= this.bandwidth && this.bandwidth <= 100 && tempB[0] <= 100) {
          
            //    if(this.cisco && temp_product.products[index].x_hARDWARE=="CISCO"){

            //        let tempdata = {
            //            catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
            //            id: temp_product.products[index].id,
            //            type: temp_product.products[index].type,
            //            displayName: temp_product.products[index].displayName,
            //            salePrice: temp_product.products[index].listPrice,
            //            bandwidth: temp_product.products[index].x_bANDWIDTH,
            //            recurrencecost: temp_product.products[index].x_recurrencecost,
            //            recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
            //            description: temp_product.products[index].description
            //          }
            //          this.product.push(tempdata);
            //          this.product.forEach((item, index) => {
            //            if (index !== this.product.findIndex(i => i.id === item.id)) {
            //              this.product.splice(index, 1);
            //            }
           
            //          });
            //          tempB = null;
           
            //          console.log(this.product);
            //    }    
            //    else if(this.fortinet && temp_product.products[index].x_hARDWARE=="FORTINET"){
                   
            //    let tempdata = {
            //        catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
            //        id: temp_product.products[index].id,
            //        type: temp_product.products[index].type,
            //        displayName: temp_product.products[index].displayName,
            //        salePrice: temp_product.products[index].listPrice,
            //        bandwidth: temp_product.products[index].x_bANDWIDTH,
            //        recurrencecost: temp_product.products[index].x_recurrencecost,
            //        recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
            //        description: temp_product.products[index].description
            //      }
            //      this.product.push(tempdata);
            //      this.product.forEach((item, index) => {
            //        if (index !== this.product.findIndex(i => i.id === item.id)) {
            //          this.product.splice(index, 1);
            //        }
       
            //      });
            //      tempB = null;
       
            //      console.log(this.product);
            //    }

            //    // localStorage.setItem('product_internet', JSON.stringify(this.product));
            //  }
     
            //  if (tempB[0] <= this.bandwidth && this.bandwidth <= 500) {

            //    if(this.cisco && temp_product.products[index].x_hARDWARE=="CISCO"){

            //        let tempdata = {
            //            catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
            //            id: temp_product.products[index].id,
            //            type: temp_product.products[index].type,
            //            displayName: temp_product.products[index].displayName,
            //            salePrice: temp_product.products[index].listPrice,
            //            bandwidth: temp_product.products[index].x_bANDWIDTH,
            //            recurrencecost: temp_product.products[index].x_recurrencecost,
            //            recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
            //            description: temp_product.products[index].description
            //          }
            //          this.product.push(tempdata);
            //          this.product.forEach((item, index) => {
            //            if (index !== this.product.findIndex(i => i.id === item.id)) {
            //              this.product.splice(index, 1);
            //            }
           
            //          });
            //          tempB = null;
           
            //          console.log(this.product);
            //    }    
            //    else if(this.fortinet && temp_product.products[index].x_hARDWARE=="FORTINET"){
                   
            //    let tempdata = {
            //        catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
            //        id: temp_product.products[index].id,
            //        type: temp_product.products[index].type,
            //        displayName: temp_product.products[index].displayName,
            //        salePrice: temp_product.products[index].listPrice,
            //        bandwidth: temp_product.products[index].x_bANDWIDTH,
            //        recurrencecost: temp_product.products[index].x_recurrencecost,
            //        recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
            //        description: temp_product.products[index].description
            //      }
            //      this.product.push(tempdata);
            //      this.product.forEach((item, index) => {
            //        if (index !== this.product.findIndex(i => i.id === item.id)) {
            //          this.product.splice(index, 1);
            //        }
       
            //      });
            //      tempB = null;
       
            //      console.log(this.product);
            //    }

     
            //    // localStorage.setItem('product_internet', JSON.stringify(this.product));
            //  }
     
            //  else if ( tempB[0] > 500 ) {
            //    if(this.cisco  && temp_product.products[index].x_hARDWARE=="CISCO"){

            //        let tempdata = {
            //            catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
            //            id: temp_product.products[index].id,
            //            type: temp_product.products[index].type,
            //            displayName: temp_product.products[index].displayName,
            //            salePrice: temp_product.products[index].listPrice,
            //            bandwidth: temp_product.products[index].x_bANDWIDTH,
            //            recurrencecost: temp_product.products[index].x_recurrencecost,
            //            recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
            //            description: temp_product.products[index].description
            //          }
            //          this.product.push(tempdata);
            //          this.product.forEach((item, index) => {
            //            if (index !== this.product.findIndex(i => i.id === item.id)) {
            //              this.product.splice(index, 1);
            //            }
           
            //          });
            //          tempB = null;
           
            //          console.log(this.product);
            //    }  
            //      else if(this.fortinet && temp_product.products[index].x_hARDWARE=="FORTINET"){
                   
            //    let tempdata = {
            //        catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
            //        id: temp_product.products[index].id,
            //        type: temp_product.products[index].type,
            //        displayName: temp_product.products[index].displayName,
            //        salePrice: temp_product.products[index].listPrice,
            //        bandwidth: temp_product.products[index].x_bANDWIDTH,
            //        recurrencecost: temp_product.products[index].x_recurrencecost,
            //        recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
            //        description: temp_product.products[index].description
            //      }
            //      this.product.push(tempdata);
            //      this.product.forEach((item, index) => {
            //        if (index !== this.product.findIndex(i => i.id === item.id)) {
            //          this.product.splice(index, 1);
            //        }
       
            //      });
            //      tempB = null;
       
            //      console.log(this.product);
            //    }

     
     
            //  }
           }
     
         }

       
   }

   // ADD TO CART
//    addToCart(id) 
//    {
//        document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove" ? "Add to cart" : "Remove";
//        let p_id = id;
//        let infra_cart = [];
//        for (let index = 0; index < this.product.length; index++) 
//        {
//            if (this.product[index].id == p_id)
//            {
//                this.modal_prodcut_name = this.product[index].displayName;
//                let infraCartData = {
//                    id: this.product[index].id,
//                    displayName: this.product[index].displayName,
//                    salePrice: this.product[index].salePrice,
//                    bandwidth: this.product[index].bandwidth,
//                    recurrencecost: this.product[index].recurrencecost,
//                    recurrencePeriod: this.product[index].recurrencePeriod,

//                }

//                if (JSON.parse(localStorage.getItem("infra_cart")) == null)
//                {
//                    infra_cart.push(infraCartData);
//                    localStorage.setItem('infra_cart', JSON.stringify(infra_cart));
//                }
//                else {
//                    infra_cart = JSON.parse(localStorage.getItem("infra_cart"));

//                    infra_cart.push(infraCartData);

//                    console.log(infra_cart);


//                    // infraData.forEach((item, index) =>
//                    // {
//                    //     if (index !== this.infra_cart.findIndex(i => i.id === item.id))
//                    //     {
//                    //         this.infra_cart.splice(index, 1);
//                    //     }
//                    // });

//                    localStorage.setItem('infra_cart', JSON.stringify(infra_cart));

//                }
//            }
//        }
//        console.log('infra');
//        console.log(infra_cart);
//        // this.router.navigate(['cart_summary/']);
//        // console.log(localStorage.getItem('product_internet'));
//    }



    // ADD TO CART
    viewdetail(id) 
    {
        // document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove" ? "Add to cart" : "Remove";
        let p_id = id;
        let infra_detail = [];
        for (let index = 0; index < this.product.length; index++) 
        {
            if (this.product[index].id == p_id)
            {
                this.modal_prodcut_name = this.product[index].displayName;
                let infradata = {
                    id: this.product[index].id,
                    displayName: this.product[index].displayName,
                    salePrice: this.product[index].salePrice,
                    bandwidth: this.product[index].bandwidth,
                    recurrencecost: this.product[index].recurrencecost,
                    recurrencePeriod: this.product[index].recurrencePeriod,
                    description:this.product[index].description
                }

                    infra_detail.push(infradata);
                    localStorage.setItem('infra_detail', JSON.stringify(infra_detail));
               
            }
        }
        console.log('infra');
        console.log(infra_detail);
        // this.router.navigate(['cart_summary/']);
        console.log(JSON.parse(localStorage.getItem('infra_detail')));
        this.router.navigate(['/infra_detail']);
    }



   addfortinet(event){
       this.fortinet= this.fortinet;
       console.log(this.fortinet);
   }

   addcisco(event){
       this.cisco=this.cisco;
       console.log(this.cisco);
   }

}
