import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfrastructureSecurityProductComponent } from './infrastructure-security-product.component';

describe('InfrastructureSecurityProductComponent', () => {
  let component: InfrastructureSecurityProductComponent;
  let fixture: ComponentFixture<InfrastructureSecurityProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfrastructureSecurityProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfrastructureSecurityProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
