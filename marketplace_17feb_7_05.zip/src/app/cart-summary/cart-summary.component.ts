import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
declare var jquery: any;
declare var $: any;
import * as jwt from 'jsonwebtoken';
import { WindowRefService } from '../services/window-ref.service';
import { ApicallsService } from '../services/apicalls.service';


@Component({
  selector: 'app-cart-summary',
  templateUrl: './cart-summary.component.html',
  styleUrls: ['./cart-summary.component.css']
})
export class CartSummaryComponent implements OnInit {
  banner: String;
  cart_array = new Array;
  monthly_cost_total: Number = 0;
  one_time_cost_total: Number = 0;
  display_name = new Array;
  c_display_name = new Array;
  i_display_name = new Array;
  s_display_name = new Array;

  i_monthly_cost_total: Number;

  s_one_time_cost_total: number = 0;
  s_monthly_cost_total: Number = 0;
  iot_monthly_cost_total: Number = 0;

  infra_monthly_cost_total: Number = 0;
  c_monthly_cost_total: Number = 0;

  cart_total: Number = 0;
  s_i_display_name: String;
  s_s_display_name: String;
  s_c_display_name: String;
  ethernet_display_name = [];
  iot_display_name = [];
  infra_display_name = [];
  ethernet_monthly_cost_total: Number = 0;
  ethernet_cart_status: boolean = true;
  i_cart_status: boolean = true;
  c_cart_status: boolean = true;
  iot_cart_status: boolean = true;
  infra_cart_status: boolean = true;
  s_cart_status: boolean = true;
  cart_status: boolean = true;

  c_o_monthly_total:Number = 0;
  c_o_onetime_total:Number = 0;
  c_o_cart_status: boolean = true;
  c_o_display_name = [];
  c_o_bundle_name:String;
  s_promo:Boolean = false;
  cb_promo:Boolean = false;
  i_promo:Boolean = false;
  iot_promo:Boolean = false;
  c_promo:Boolean = false;
  infra_promo:Boolean = false;
  
  cartItems:any = [];
  e_devided_cost:Number;
  e_add_1 =[];
  e_add_2= [];
  _w: any;
  chatBox: any;
  obj: {};
  sendCart: any = [];

  
  constructor(private service: ServiceService,
    private location: Location,
    private winRef:WindowRefService,
    private _as:ApicallsService,
    private aroute: ActivatedRoute,
    private router: Router) {
      this._w = this.winRef.nativeWindow;
     }

     cleanup() {
      [].forEach.call(document.querySelectorAll('.avaamo__chat__widget'), (x) => x.remove());
      [].filter.call(document.querySelectorAll('script'), x => x.src.indexOf('avaamo')!=-1).forEach(x => x.remove());
    }

    reject_quote(){
      this._as.getSalesMail().subscribe((data:any)=>{
        console.log(data);
      })
      this.cleanup();
      // let user = JSON.parse(localStorage.getItem('currentUser'));
      // console.log(user);
      // console.log(this._w);
      let token = jwt.sign({
        "uuid": Math.random()*1000,
        "FirstName": "there",
        "trigger_reason": "REJECT_QUOTE"
      }, '9e181236-6850-48a8-8807-d8947436ac12');
      
      this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
      this.chatBox.load();
      setTimeout(()=>{
        this._w.Avaamo.openChatBox();
      },1000);
    }


   

  ngOnInit() {
    
    $(document).ready(function()
    {
      $("#dtBox").DateTimePicker({
      
        dateFormat: "MM-dd-yyyy",
        timeFormat: "HH:mm",
        dateTimeFormat: "MM-dd-yyyy HH:mm:ss AA"
      
      });
    });

    // localStorage.removeItem('iot_cart');
    this.getBannerImage();
    this.getInternetCart();
    this.getSmartCart();
    this.getInfraCart();
    this.getIOTCart();
    this.getContentCart();
    this.getEthernetCart();
    this.getownbundleCart();

  }

  ngAfterViewInit(){
    console.log(this.cartItems.length);
    for(let i=0;i<this.cartItems.length;i++){
      for(let j=0;j<this.cartItems[i].length;j++){
        console.log(this.cartItems[i][j]);
        this.sendCart.push(this.cartItems[i][j]);
      }
    }
  }

  ngOnDestroy(){
    this._as.postCart(this.sendCart).subscribe((data:any)=>{
      console.log(data);
    });
  }

  s_promocode(){
    this.s_promo = true;
  }
  cb_promocode(){
    this.cb_promo = true;
  }

  i_promocode(){
    this.i_promo = true;
  }

  iot_promocode(){
    this.iot_promo = true;
  }
  c_promocode(){
    this.c_promo = true;
  }
  infra_promocode(){
    this.infra_promo = true;
  }
  // get banner image

  getBannerImage() {
    this.service.getBannerImages()
      .subscribe((bannerdata) => {
        console.log(bannerdata);

        this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[6].url;
        console.log(' hello' + this.banner);

      });
  }
  //get product image
  getInternetCart() {
    this.i_display_name = [];
    let temp_i_cart = JSON.parse(localStorage.getItem('internet_cart'));
    this.i_monthly_cost_total = 0;
    this.monthly_cost_total = 0;


    console.log(temp_i_cart);
    if (temp_i_cart != null) {
      for (let index = 0; index < temp_i_cart.length; index++) {
        this.i_display_name.push(temp_i_cart[index])
        this.i_monthly_cost_total += (temp_i_cart[index].recurrencecost);
        this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_i_cart[index].recurrencecost);
        this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_i_cart[index].salePrice);
        this.i_cart_status = false;
        this.cart_status = false;
        this.cart_total = Number(this.cart_total) + 1;
        
        
      }

      this.obj = {};
        this.obj['name']=this.i_display_name;
        this.obj['monthly-cost']=this.i_monthly_cost_total;
    }
    this.cartItems.push(this.i_display_name);
    // localStorage.removeItem('internet_cart');
    if (temp_i_cart == null) {
      this.i_cart_status = true;

    }

    console.log(this.one_time_cost_total);


    // console.log(this.display_name);
    // console.log(this.monthly_cost_total);
    // console.log(this.one_time_cost_total);



  }

  // get content for business cart

  getContentCart() {
    this.c_display_name = [];
    let temp_c_cart = JSON.parse(localStorage.getItem('content_for_business_cart'));


    this.c_monthly_cost_total = 0;


    console.log(temp_c_cart);
    if (temp_c_cart != null) {
      for (let index = 0; index < temp_c_cart.length; index++) {
        this.c_display_name.push(temp_c_cart[index])
        this.c_monthly_cost_total += (temp_c_cart[index].recurrencecost);
        this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_c_cart[index].recurrencecost);
        this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_c_cart[index].salePrice);
        this.c_cart_status = false;
        this.cart_status = false;
        this.cart_total = Number(this.cart_total) + 1;
        
      }
      this.obj = {};
        this.obj['name']=this.c_display_name;
        this.obj['monthly-cost']=this.c_monthly_cost_total;

    }
    this.cartItems.push(this.c_display_name);
    if (temp_c_cart == null) {
      this.c_cart_status = true;

    }

    // console.log(this.display_name);
    // console.log(this.monthly_cost_total);
    // console.log(this.one_time_cost_total);



  }

  // get smartbundle cart
  getSmartCart() {
    let temp_s_cart = JSON.parse(localStorage.getItem('smart_bunddle_cart'));

    // this.monthly_cost_total = 0;
    this.s_monthly_cost_total = 0;
    this.s_one_time_cost_total = 0;
    console.log(temp_s_cart);
    if (temp_s_cart != null) {


      for (let index = 0; index < temp_s_cart.length; index++) {
        this.s_i_display_name = temp_s_cart[0].displayName;
        this.s_c_display_name = temp_s_cart[1].displayName;
        this.s_s_display_name = temp_s_cart[2].displayName;
      
        this.s_monthly_cost_total += (temp_s_cart[index].recurrencecost);
        this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_s_cart[index].recurrencecost);
        this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_s_cart[index].salePrice);
        this.s_cart_status = false;
        this.cart_status = false;
        this.cart_total = Number(this.cart_total) + 1;
        
      }
      this.obj = {};
        this.obj['name']=this.s_i_display_name;
        this.obj['monthly-cost']=this.s_monthly_cost_total;
    }
    if(temp_s_cart!=null){
    this.cartItems.push(temp_s_cart);
    }
  }
// get own cart
getownbundleCart() {
  this.c_o_display_name = [];
  let temp_co_cart = JSON.parse(localStorage.getItem('bundle_info'));
  this.c_o_monthly_total = 0;



  console.log(temp_co_cart);
  if (temp_co_cart != null) {
    // this.c_o_bundle_name = temp_co_cart[0].bundleName;
    for (let index = 0; index < temp_co_cart.length; index++) {
      this.c_o_monthly_total = 0;
      for (let secondindex = 0; secondindex < temp_co_cart[index].product_Array.length; secondindex++) {
      this.c_o_monthly_total += (temp_co_cart[index].product_Array[secondindex].recurrencecost);
      this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_co_cart[index].product_Array[secondindex].recurrencecost);
      this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_co_cart[index].product_Array[secondindex].salePrice);
  }

  this.c_o_cart_status = false;
  this.cart_status = false;
  let temp={
    dundleName:temp_co_cart[index].bundleName,
    c_o_monthly_total: this.c_o_monthly_total,
    product:temp_co_cart[index].product_Array
  }
  this.c_o_display_name.push(temp);
  
  

}
    // for (let index = 0; index < temp_co_cart[0].product_Array.length; index++) {
    //   this.c_o_display_name.push(temp_co_cart[0].product_Array[index]);
    //   this.c_o_monthly_total += (temp_co_cart[0].product_Array[index].recurrencecost);
    //   this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_co_cart[0].product_Array[index].recurrencecost);
    //   this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_co_cart[0].product_Array[index].salePrice);
    // 
    // }
    this.obj = {};
  this.obj['name']=this.c_o_display_name;
  this.obj['monthly-cost']=this.c_o_monthly_total;
  }
  this.cartItems.push(this.c_o_display_name);
  if (temp_co_cart == null) {
    this.c_o_cart_status = true;
  }
  console.log(this.c_o_display_name);
   
}

  // get iot cart
  getIOTCart() {
    this.iot_display_name = [];
    let temp_iot_cart = JSON.parse(localStorage.getItem('iot_cart'));
    this.iot_monthly_cost_total = 0;



    console.log(temp_iot_cart);
    if (temp_iot_cart != null) {
      for (let index = 0; index < temp_iot_cart.length; index++) {
        this.iot_display_name.push(temp_iot_cart[index])
        this.iot_monthly_cost_total += (temp_iot_cart[index].recurrencecost);
        this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_iot_cart[index].recurrencecost);
        this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_iot_cart[index].salePrice);
        this.iot_cart_status = false;
        this.cart_status = false;
        
      }
      this.obj = {};
        this.obj['name']=this.iot_display_name;
        this.obj['monthly-cost']=this.iot_monthly_cost_total;
    }
    this.cartItems.push(this.iot_display_name);
    if (temp_iot_cart == null) {
      this.iot_cart_status = true;
    }
  }

  // get infra cart
  getInfraCart() {
    // localStorage.removeItem('infra_cart');
    let temp_infra_cart = JSON.parse(localStorage.getItem('infra_cart'));
    this.infra_monthly_cost_total = 0;



    console.log('infra', temp_infra_cart);
    if (temp_infra_cart != null) {
      for (let index = 0; index < temp_infra_cart.length; index++) {
        this.infra_display_name.push(temp_infra_cart[index])
        this.infra_monthly_cost_total += (temp_infra_cart[index].recurrencecost);
        this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_infra_cart[index].recurrencecost);
        this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_infra_cart[index].salePrice);
        this.infra_cart_status = false;
        this.cart_status = false;
        this.cart_total = Number(this.cart_total) + 1;
        
      }
      this.obj = {};
        this.obj['name']=this.infra_display_name;
        this.obj['monthly-cost']=this.infra_monthly_cost_total;
    }
    this.cartItems.push(this.infra_display_name);

    if (temp_infra_cart == null) {
      this.infra_cart_status = true;
    }
  }

  // get ethernet cart
  getEthernetCart() {
    this.ethernet_display_name = [];
    let temp_ethernet_cart = JSON.parse(localStorage.getItem('ethernet_cart'));
    this.ethernet_monthly_cost_total = 0;
    // this.one_time_cost_total = 0;


    console.log(temp_ethernet_cart);
    if (temp_ethernet_cart != null) {
      for (let index = 0; index < temp_ethernet_cart.length; index++) {
        this.ethernet_display_name = temp_ethernet_cart[index].displayName;
        this.ethernet_monthly_cost_total = Number(this.ethernet_monthly_cost_total) + Number(temp_ethernet_cart[index].recurrencecost);
        this.monthly_cost_total = Number(this.monthly_cost_total) + Number(temp_ethernet_cart[index].recurrencecost);
        this.one_time_cost_total = Number(this.one_time_cost_total) + Number(temp_ethernet_cart[index].salePrice);
        this.ethernet_cart_status = false;
        this.e_devided_cost = Number(this.ethernet_monthly_cost_total) / 2;
        this.e_add_1 = temp_ethernet_cart[index].address1;
        this.e_add_2 = temp_ethernet_cart[index].address2;
        this.cart_status = false;
        this.cart_total = Number(this.cart_total) + 1;
        console.log(this.ethernet_display_name);
        
      }
      this.obj = {};
        this.obj['name']=this.ethernet_display_name;
        this.obj['monthly-cost']=this.ethernet_monthly_cost_total;
    }
    this.cartItems.push(temp_ethernet_cart);

    if (temp_ethernet_cart == null) {
      this.ethernet_cart_status = true;
    }
  }

  // remove internet cart product

  internet_remove(id) {

    let internet_id = id;
    let temp_cart = JSON.parse(localStorage.getItem('internet_cart'));

    for (let index = 0; index < temp_cart.length; index++) {
      if (temp_cart[index].id == internet_id) {
        temp_cart.splice(index, 1);
        console.log(temp_cart);

      }
      localStorage.setItem('internet_cart', JSON.stringify(temp_cart));
    }
    this.getInternetCart();
  }

  // content for business delete

  content_remove(id) {

    let internet_id = id;
    let temp_cart = JSON.parse(localStorage.getItem('content_for_business_cart'));


    let con_b_c=0;
    let temp_product_content_b = JSON.parse(localStorage.getItem('content_for_business_cart'));
    if(temp_product_content_b!=null){
      con_b_c=temp_product_content_b.length;
    }else{
      con_b_c=0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_b_c);

    for (let index = 0; index < temp_cart.length; index++) {
      if (temp_cart[index].id == internet_id) {
        temp_cart.splice(index, 1);
        console.log(temp_cart);
      }
      localStorage.setItem('content_for_business_cart', JSON.stringify(temp_cart));
    }


    this.getContentCart();
  }

  // iot remove
  
  // infra structure
  // iot remove
  // infra_remove(id) {
  //   this.monthly_cost_total = 0;
  //   let internet_id = id;
  //   let temp_cart = JSON.parse(localStorage.getItem('infra_cart'));

  //   for (let index = 0; index < temp_cart.length; index++) {
  //     if (temp_cart[index].id == internet_id) {
  //       temp_cart.splice(index, 1);
  //       console.log(temp_cart);
  //     }
  //     localStorage.setItem('infra_cart', JSON.stringify(temp_cart));
  //   }
  //   this.getInfraCart();
  // }


  // ethernet remove
  e_remove() {
    console.log('hello');
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;

    // this.monthly_cost_total = Number(this.monthly_cost_total) - Number(this.i_monthly_cost_total);

    let con_c=0;
    let temp_product = JSON.parse(localStorage.getItem('ethernet_cart'));
    if(temp_product!=null){
      con_c=temp_product.length;
    }else{
      con_c=0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_c);

    localStorage.removeItem('ethernet_cart');
    this.ethernet_cart_status = true;
    this.getInternetCart();
    this.getEthernetCart();
    this.getContentCart();
    this.getSmartCart();
    this.getIOTCart();
    this.getInfraCart();
    this.getownbundleCart();

    console.log(this.s_cart_status);

  }

  // bundle remove


  smart_bunddle_remove() {
    console.log('hello');
    // this.monthly_cost_total = 0;
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;

    let con_c=0;
    let temp_product = JSON.parse(localStorage.getItem('smart_bunddle_cart'));
    if(temp_product!=null){
      con_c= 1;
    }else{
      con_c=0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_c);

    localStorage.removeItem('smart_bunddle_cart');
    this.s_cart_status = true;
    this.getInternetCart();
    this.getEthernetCart();
    this.getContentCart();
    this.getSmartCart();
    this.getIOTCart();
    this.getInfraCart();
    this.getownbundleCart();

    console.log(this.s_cart_status);

  }


  i_remove() {
    console.log('hello');
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;

    let con_c=0;
    let temp_product = JSON.parse(localStorage.getItem('internet_cart'));
    if(temp_product!=null){
      con_c=temp_product.length;
    }else{
      con_c=0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_c);

    // this.monthly_cost_total = Number(this.monthly_cost_total) - Number(this.i_monthly_cost_total);

    localStorage.removeItem('internet_cart');
    this.i_cart_status = true;
    this.getInternetCart();
    this.getEthernetCart();
    this.getContentCart();
    this.getSmartCart();
    this.getIOTCart();
    this.getInfraCart();
    this.getownbundleCart();

    console.log(this.s_cart_status);


  }


  c_remove() {
    console.log('hello');
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;
    // this.monthly_cost_total = Number(this.monthly_cost_total) - Number(this.c_monthly_cost_total);

    let con_c=0;
    let temp_product = JSON.parse(localStorage.getItem('content_for_business_cart'));
    if(temp_product!=null){
      con_c=temp_product.length;
    }else{
      con_c=0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_c);

    localStorage.removeItem('content_for_business_cart');
    this.c_cart_status = true;
    this.getInternetCart();
    this.getEthernetCart();
    this.getContentCart();
    this.getSmartCart();
    this.getIOTCart();
    this.getInfraCart();
    this.getownbundleCart();

    console.log(this.s_cart_status);

    
  }
  
  iot_remove() {
    console.log('hello');
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;
    // this.monthly_cost_total = Number(this.monthly_cost_total) - Number(this.c_monthly_cost_total);

    let con_c=0;
    let temp_product = JSON.parse(localStorage.getItem('iot_cart'));
    if(temp_product!=null){
      con_c=temp_product.length;
    }else{
      con_c=0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_c);

    localStorage.removeItem('iot_cart');
    this.c_cart_status = true;
    this.getInternetCart();
    this.getEthernetCart();
    this.getContentCart();
    this.getSmartCart();
    this.getIOTCart();
    this.getInfraCart();
    this.getownbundleCart();

    console.log(this.s_cart_status);

  }
  infra_remove() {
    console.log('hello');
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;

    let con_c=0;
    let temp_product = JSON.parse(localStorage.getItem('infra_cart'));
    if(temp_product!=null){
      con_c=temp_product.length;
    }else{
      con_c=0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_c);

    // this.monthly_cost_total = Number(this.monthly_cost_total) - Number(this.c_monthly_cost_total);

    localStorage.removeItem('infra_cart');
    this.c_cart_status = true;
    this.getInternetCart();
    this.getEthernetCart();
    this.getContentCart();
    this.getSmartCart();
    this.getIOTCart();
    this.getInfraCart();
    this.getownbundleCart();

    console.log(this.s_cart_status);

  

  }

co_remove(id) {
    console.log(id);
    this.monthly_cost_total = 0;
    this.one_time_cost_total = 0;
    let temp_product = JSON.parse(localStorage.getItem('bundle_info'));
    let bundlename:String;
    bundlename = id;
    let con_c=0;
    console.log(bundlename);
    
    for (let index = 0; index < temp_product.length; index++) {

       if (temp_product[index].bundleName == bundlename) {
        temp_product.splice(index, 1);
        console.log(temp_product);
      }

    }
    localStorage.setItem('bundle_info', JSON.stringify(temp_product));
    con_c =1;
    if(temp_product = null){
      con_c= 0;
    }

    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-con_c);

    this.monthly_cost_total = Number(this.monthly_cost_total) - Number(this.c_monthly_cost_total);

    // localStorage.removeItem('bundle_info');
    this.c_cart_status = true;
    this.getInternetCart();
    this.getEthernetCart();
    this.getContentCart();
    this.getSmartCart();
    this.getIOTCart();
    this.getInfraCart();
    this.getownbundleCart();

    console.log(this.s_cart_status);

  

  }
}
