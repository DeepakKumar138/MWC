import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
declare var bandwidth: String;
@Component({
  selector: 'app-content-for-business',
  templateUrl: './content-for-business.component.html',
  styleUrls: ['./content-for-business.component.css']
})
export class ContentForBusinessComponent implements OnInit {
  channel: number = 0;
  location: number = 10;
  Hours: number = 10;
  contact: number = 10;
  options: Options = {
    floor: 10,
    ceil: 1000
  };

  cart_update = 0;
  ch_options: Options = {
    floor: 0,
    ceil: 350
  };
  text = 'Add to cart';
banner:String;
product =[];
modal_prodcut_name:String;
  constructor(private service: ServiceService) { }

  ngOnInit() {
 
    this.service.login().subscribe((data:any)=>{
      this.service.getProduct().subscribe((data:any)=>{
        console.log(data);
        localStorage.setItem('product_internet',JSON.stringify(data));
      });
    });

    // image gallery
    $(".image-checkbox").each(function () {
      if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
        $(this).addClass('image-checkbox-checked');

      }
      else {
        $(this).removeClass('image-checkbox-checked');
      }
    });

    // sync the state to the input
    $(".image-checkbox").on("click", function (e) {
      $(this).toggleClass('phovercontent_active proicon_chkbox');
      $(this).toggleClass('image-checkbox-checked');
      var $checkbox = $(this).find('input[type="checkbox"]');
      $checkbox.prop("checked", !$checkbox.prop("checked"))

      e.preventDefault();
    });
    this.getBannerImage();
  }

 
  getBannerImage() {
    this.service.getBannerImages()
      .subscribe((bannerdata) => {
console.log(bannerdata);

        this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[7].url;
        // console.log(' banner' + this.banner);

      });
  }




  getAllProduct() {
    this.product = [];
    // this.cart_btn = "Add to cart";
    let tempproduct = {

    }
    // let tempB = null;
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    console.log(temp_product);


    for (let index = 0; index < temp_product.products.length; index++) {

      if (temp_product.products[index].parentCategories[0].repositoryId == 'CONTC_001') {
        let tempdata = {
          catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
          id: temp_product.products[index].id,
          type: temp_product.products[index].type,
          displayName: temp_product.products[index].displayName,
          salePrice: temp_product.products[index].listPrice,
          channel: temp_product.products[index].x_cHANNEL,
          recurrencecost: temp_product.products[index].x_recurrencecost,
          recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
          description: temp_product.products[index].description
        }
        this.product.push(tempdata);
        this.product.forEach((item, index) => {
          if (index !== this.product.findIndex(i => i.id === item.id)) {
            this.product.splice(index, 1);
          }

        });
      

        console.log(this.product);

      
      //   if (temp_product.products[index].x_cHANNEL <= this.channel &&  this.channel <= 100 && temp_product.products[index].x_cHANNEL <= 100) {
      //     let tempdata = {
      //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
      //       id: temp_product.products[index].id,
      //       type: temp_product.products[index].type,
      //       displayName: temp_product.products[index].displayName,
      //       salePrice: temp_product.products[index].listPrice,
      //       channel: temp_product.products[index].x_cHANNEL,
      //       recurrencecost: temp_product.products[index].x_recurrencecost,
      //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
      //       description: temp_product.products[index].description
      //     }
      //     this.product.push(tempdata);
      //     this.product.forEach((item, index) => {
      //       if (index !== this.product.findIndex(i => i.id === item.id)) {
      //         this.product.splice(index, 1);
      //       }

      //     });
        

      //     console.log(this.product);

      //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
      //   }
      //  else if (temp_product.products[index].x_cHANNEL <= this.channel &&  this.channel <= 300 && temp_product.products[index].x_cHANNEL <= 300) {
      //     let tempdata = {
      //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
      //       id: temp_product.products[index].id,
      //       type: temp_product.products[index].type,
      //       displayName: temp_product.products[index].displayName,
      //       salePrice: temp_product.products[index].listPrice,
      //       channel: temp_product.products[index].x_cHANNEL,
      //       recurrencecost: temp_product.products[index].x_recurrencecost,
      //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
      //       description: temp_product.products[index].description
      //     }
      //     this.product.push(tempdata);
      //     this.product.forEach((item, index) => {
      //       if (index !== this.product.findIndex(i => i.id === item.id)) {
      //         this.product.splice(index, 1);
      //       }

      //     });
        

      //     console.log(this.product);

      //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
      //   }

      //   else if (temp_product.products[index].x_cHANNEL > 300) {
      //     let tempdata = {
      //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
      //       id: temp_product.products[index].id,
      //       type: temp_product.products[index].type,
      //       displayName: temp_product.products[index].displayName,
      //       salePrice: temp_product.products[index].listPrice,
      //       bandwidth: temp_product.products[index].x_bANDWIDTH,
      //       recurrencecost: temp_product.products[index].x_recurrencecost,
      //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
      //       description: temp_product.products[index].description
      //     }
      //     this.product.push(tempdata);
      //     this.product.forEach((item, index) => {
      //       if (index !== this.product.findIndex(i => i.id === item.id)) {
      //         this.product.splice(index, 1);
      //       }

      //     });
        

      //     console.log(this.product);

      //   }
      }

    }

  }
 



  // ADD TO CART

  
  addToCart(id) {

    document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove" ? "Add to cart" : "Remove";

    let p_id = id;
    // this.cart_btn ="Remove";
    let internet_cart = [];
    for (let index = 0; index < this.product.length; index++) {
      if (this.product[index].id === p_id) {
        this.modal_prodcut_name = this.product[index].displayName;
        let internet = {
          id: this.product[index].id,
          displayName: this.product[index].displayName,
          salePrice: this.product[index].salePrice,
          bandwidth: this.product[index].bandwidth,
          recurrencecost: this.product[index].recurrencecost,
          recurrencePeriod: this.product[index].recurrencePeriod,

        }

        if (JSON.parse(localStorage.getItem("content_for_business_cart")) == null ) {
          internet_cart.push(internet);
          localStorage.setItem('content_for_business_cart', JSON.stringify(internet_cart));
          // environment.internet_cart.push(internet)
        }
        else{
          internet_cart = JSON.parse(localStorage.getItem("content_for_business_cart"));

          internet_cart.push(internet);
          localStorage.setItem('content_for_business_cart', JSON.stringify(internet_cart));
        //  console.log()
        }
      }


    }


    let cart_ary=JSON.parse(localStorage.getItem('content_for_business_cart')); 
    if(cart_ary !=null ){
      this.cart_update =cart_ary.length;  
      } 
      else{
        this.cart_update = 0;

      }

        let add_to_cart_val=document.getElementById('headCount').innerText;
      document.getElementById('headCount').innerText=String(Number(add_to_cart_val)+this.cart_update);



    // console.log(environment.internet_cart);
    // this.router.navigate(['cart_summary/']);

    console.log(JSON.parse(localStorage.getItem('content_for_business_cart')));
  }
}
