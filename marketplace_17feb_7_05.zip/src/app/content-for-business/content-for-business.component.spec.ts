import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentForBusinessComponent } from './content-for-business.component';

describe('ContentForBusinessComponent', () => {
  let component: ContentForBusinessComponent;
  let fixture: ComponentFixture<ContentForBusinessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentForBusinessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentForBusinessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
