import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product';
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
declare var bandwidth: String;

@Component({
  selector: 'app-infra-detail',
  templateUrl: './infra-detail.component.html',
  styleUrls: ['./infra-detail.component.css']
})
export class InfraDetailComponent implements OnInit {

  product =[];
  monthly_cost:Number;
  displayName:String;
  description:String;
  cart_update = 0;
  
  constructor(private service:ServiceService) { }

  ngOnInit() {
    this.service.login().subscribe((data:any)=>{
      this.service.getProduct().subscribe((data:any)=>{
        console.log(data);
        localStorage.setItem('product_internet',JSON.stringify(data));
      });
    });
  this.fetchProduct();
  }

  fetchProduct(){
    let tmp_infra = JSON.parse(localStorage.getItem('infra_detail'));
    this.product.push(tmp_infra[0]);
   this.monthly_cost =tmp_infra[0].recurrencecost;
   this.displayName =tmp_infra[0].displayName;
   this.description =tmp_infra[0].description;
   console.log(this.product);
  }

  addtocart() {

    // document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove" ? "Add to cart" : "Remove";

    // let p_id = id;
    // this.cart_btn ="Remove";
    let infra_cart = [];
    for (let index = 0; index < this.product.length; index++) {
        // this.modal_prodcut_name = this.product[index].displayName;
        let infradata = {
          id: this.product[index].id,
          displayName: this.product[index].displayName,
          salePrice: this.product[index].salePrice,
          // bandwidth: this.product[index].bandwidth,
          recurrencecost: this.product[index].recurrencecost,
          recurrencePeriod: this.product[index].recurrencePeriod,

        }

        if (JSON.parse(localStorage.getItem("infra_cart")) == null ) {
          infra_cart.push(infradata);
          localStorage.setItem('infra_cart', JSON.stringify(infra_cart));
          // environment.infra_cart.push(infradata)
        }
        else{
          infra_cart = JSON.parse(localStorage.getItem("infra_cart"));

          infra_cart.push(infradata);
          localStorage.setItem('infra_cart', JSON.stringify(infra_cart));
        //  console.log()
        }
      


    }

    
    let cart_ary=JSON.parse(localStorage.getItem('infra_cart')); 
    if(cart_ary !=null ){
      this.cart_update =cart_ary.length;  
      } 
      else{
        this.cart_update = 0;

      }

        let add_to_cart_val=document.getElementById('headCount').innerText;
      document.getElementById('headCount').innerText=String(Number(add_to_cart_val)+this.cart_update);







    // console.log(environment.infra_cart);
    // this.router.navigate(['cart_summary/']);

    console.log(JSON.parse(localStorage.getItem('infra_cart')));
  }
  
}
