import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBroadbandComponent } from './product-broadband.component';

describe('ProductBroadbandComponent', () => {
  let component: ProductBroadbandComponent;
  let fixture: ComponentFixture<ProductBroadbandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductBroadbandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBroadbandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
