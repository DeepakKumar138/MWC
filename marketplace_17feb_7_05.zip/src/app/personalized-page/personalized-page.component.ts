import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { WindowRefService } from '../services/window-ref.service';
import * as jwt from 'jsonwebtoken';

@Component({
  selector: 'app-personalized-page',
  templateUrl: './personalized-page.component.html',
  styleUrls: ['./personalized-page.component.css']
})
export class PersonalizedPageComponent implements OnInit {

  _w: any;
  chatBox: any;
  one: any=1;

  banner:String;
  firstname:String;
  counter_2:boolean =true;
  products= [];
  i_prod_name :String;
  i_prod_price:Number;
  e_prod_name :String;
  e_prod_price:Number;
  c_prod_name :String;
  c_prod_price:Number;
  monthly_total: Number =0;
  constructor(private service: ServiceService,
    private location: Location,
    private aroute: ActivatedRoute,
    private winRef:WindowRefService,
    private router: Router) {
      this._w = this.winRef.nativeWindow;
     }

    //cart counter
    cart_update : any;

  ngOnInit() {
    
    this.login();
    this.getproductsuggests();
    this.getBannerImage();
  this.getUser();
  

  }

  getproductsuggests(){

    console.log("entered the chatbot function");
      this.cleanup();
      let user = JSON.parse(localStorage.getItem('currentUser'));
      let token = jwt.sign({
        "uuid": Math.random()*1000,
        "FirstName": "there",
        "trigger_reason": "SELECT_PRODUCT"
      }, '9e181236-6850-48a8-8807-d8947436ac12');
      this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
      this.chatBox.load();
      console.log("once is ", this.service.once);
      setTimeout(()=>{
        if(this.service.once != '1'){
          this._w.Avaamo.openChatBox();
          this.service.setvalue(this.one);
        }
        
      },10000);

  }

  compareProducts(){
    this.cleanup();
    let user = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(user);
    // console.log(this._w);
    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": "there",
      "trigger_reason": "COMPARE_OFFER"
    }, '9e181236-6850-48a8-8807-d8947436ac12');
    
    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    setTimeout(()=>{
      this._w.Avaamo.openChatBox();
    },2000);
   
  }

  cleanup() {
    [].forEach.call(document.querySelectorAll('.avaamo__chat__widget'), (x) => x.remove());
    [].filter.call(document.querySelectorAll('script'), x => x.src.indexOf('avaamo')!=-1).forEach(x => x.remove());
  }

  // banner image get
getBannerImage() {
  this.service.getBannerImages()
    .subscribe((bannerdata) => {
      console.log(bannerdata);
      
      this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[2].url;
      console.log(' hello' + this.banner);

    });
}

login() {
   
  this.service.login()

    .subscribe((login) => {
      // localStorage.setItem('product_internet', JSON.stringify(data));
      console.log(login);

        // environment.customer_id = login.CustomerId;
        // environment.token = login.access_token;
      localStorage.setItem('token',login.access_token);
      localStorage.setItem('customer_id',login.CustomerId);

        // console.log(localStorage.getItem('token'));
        // console.log(localStorage.getItem('customer_id'));
        this.getUser();
        this.getProduct();

        
    });

}



getProduct() {
  this.service.getProduct()
    .subscribe((data) => {
      localStorage.setItem('product_internet', JSON.stringify(data));

      console.log(JSON.parse(localStorage.getItem('product_internet')));
      // for (let index = 0; index < data.products.length; index++) {
      //   environment.product.push(data.products[index]);

      // }
     this.productFetch();
	 this.smartBundleProductFetch();

    });

  // console.log(environment.product);

}


// get user detail
getUser() {
  let id =localStorage.getItem('customer_id'); 
  // console.log("ehlloo",id);
  
  
  this.service.getcustomer(id)
        .subscribe((user) => {
          // localStorage.setItem('product_internet', JSON.stringify(data));
          console.log(user);
  
            this.firstname= user.firstName;
        });
  
    }
  
// product fetch
productFetch(){
  

  let tempproduct = {

  }
  let temp_product = JSON.parse(localStorage.getItem('product_internet'));
  console.log('temp', JSON.parse(localStorage.getItem('product_internet')));

  for (let index = 0; index < temp_product.products.length; index++) {
    if (temp_product.products[index].id == "INT_001") {
      this.i_prod_name = temp_product.products[index].displayName;
      this.i_prod_price =temp_product.products[index].x_recurrencecost;
      console.log(this.i_prod_name);
      console.log(this.i_prod_price);
      
      
    }

    else if (temp_product.products[index].id == 'ETH_001') {
      this.e_prod_name = temp_product.products[index].displayName;
      this.e_prod_price =temp_product.products[index].x_recurrencecost;
      console.log(this.e_prod_name);
      console.log(this.e_prod_price);
      

    }
    else if (temp_product.products[index].id == 'OFF_001') {
      this.c_prod_name = temp_product.products[index].displayName;
      this.c_prod_price =temp_product.products[index].x_recurrencecost;
      console.log(this.c_prod_name);
      console.log(this.c_prod_price);
    
    }
   
  }


  // check smart bundle added

  let temp_smart_cart = JSON.parse(localStorage.getItem('smart_bunddle_cart'));
  console.log('hello',temp_smart_cart);
  
    if(temp_smart_cart != null){
      this.counter_2 =false;
    }      

 
}

smartBundleProductFetch(){
  this.products = [];


  let tempproduct = {

  }
  let temp_product = JSON.parse(localStorage.getItem('product_internet'));
  console.log('temp', JSON.parse(localStorage.getItem('product_internet')));

  for (let index = 0; index < temp_product.products.length; index++) {
    if (temp_product.products[index].id == "INT_001") {
      console.log(temp_product.products[index]);
      this.products.push(temp_product.products[index]);
      
      this.monthly_total =  Number(this.monthly_total)+ Number(temp_product.products[index].x_recurrencecost);
      console.log(this.monthly_total);
    }

    else if (temp_product.products[index].id == 'ASST_001') {

      this.monthly_total =  Number(this.monthly_total)+ Number(temp_product.products[index].x_recurrencecost);
      // this.monthly_total += temp_product.products[index].x_recurrencecost;
      console.log(this.monthly_total);
      this.products.push(temp_product.products[index]);
      console.log(temp_product.products[index]);
    }
    else if (temp_product.products[index].id == 'OFF_001') {
      this.monthly_total =  Number(this.monthly_total)+ Number(temp_product.products[index].x_recurrencecost);
      // this.monthly_total += temp_product.products[index].x_recurrencecost;
      this.products.push(temp_product.products[index]);
      console.log(this.monthly_total);
      console.log(temp_product.products[index]);

    }
  }
}
// smart bundle add to cart
addtocart_smartbundle(){
  this.counter_2 =false;
let add_product =[];
let smart_cart = JSON.parse(localStorage.getItem('smart_bunddle_cart')); 
 
for (let index = 0; index < this.products.length; index++) {
    let temp ={
      displayName:this.products[index].displayName,
      salePrice:this.products[index].listPrice,
      recurrencecost:this.products[index].x_recurrencecost
    }
     add_product.push(temp);
  }
  // console.log(add_product);
  
  // environment.smartbundle_cart.push(internet)
  localStorage.setItem('smart_bunddle_cart', JSON.stringify(add_product));
  // console.log('11111111111111', JSON.parse(localStorage.getItem('smart_bunddle_cart')));
  

  if(smart_cart !=null ){
    this.cart_update = 0;
  } 
  else{
    this.cart_update =1;  }
  let add_to_cart_val=document.getElementById('headCount').innerText;
  document.getElementById('headCount').innerText=String(Number(add_to_cart_val)+this.cart_update);
  console.log(JSON.parse(localStorage.getItem('smart_bunddle_cart')));
}


removesmartBundleCart(){
  this.counter_2 =true;
  let add_to_cart_val=document.getElementById('headCount').innerText;
  document.getElementById('headCount').innerText=String(Number(add_to_cart_val)-1);
  localStorage.removeItem('smart_bunddle_cart');
}


}
