import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { Ng5SliderModule } from 'ng5-slider';
import { OwlModule } from 'ngx-owl-carousel';


import { HeaderComponent } from './header/header.component';
import { InternetComponent } from './internet/internet.component';
import { PersonalizedPageComponent } from './personalized-page/personalized-page.component';
import { SmartWorkplaceBundleComponent } from './smart-workplace-bundle/smart-workplace-bundle.component';
import { ProductEthernetComponent } from './product-ethernet/product-ethernet.component';
import { InfrastructureSecurityProductComponent } from './infrastructure-security-product/infrastructure-security-product.component';
import { ContentForBusinessComponent } from './content-for-business/content-for-business.component';
import { IotSmartWorkplaceComponent } from './iot-smart-workplace/iot-smart-workplace.component';
import { CartSummaryComponent } from './cart-summary/cart-summary.component';
import { DesignYourOwnBundleComponent } from './design-your-own-bundle/design-your-own-bundle.component';
import { InternetBundleComponent } from './internet-bundle/internet-bundle.component';
import { IotBundleComponent } from './iot-bundle/iot-bundle.component';
import { ContentForBusinessBundleComponent } from './content-for-business-bundle/content-for-business-bundle.component';
import { ExistingUserComponent } from './existing-user/existing-user.component';
import { BillingandshipmentComponent } from './billingandshipment/billingandshipment.component';
import { InfraDetailComponent } from './infra-detail/infra-detail.component';
import { EthernetAndTrasportComponent } from './ethernet-and-trasport/ethernet-and-trasport.component';
import { ProductBroadbandComponent } from './product-broadband/product-broadband.component';
import { SliceAsBundleComponent } from './slice-as-bundle/slice-as-bundle.component';
import { VideoOnDemandComponent } from './video-on-demand/video-on-demand.component';
import { GoogleMapsAPIWrapper, AgmCoreModule, MapsAPILoader } from '@agm/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CartSummaryNewComponent } from './cart-summary-new/cart-summary-new.component';
import { BillingNewComponent } from './billing-new/billing-new.component';
import { RedirectComponent } from './redirect/redirect.component';
import { HttpClientModule } from '@angular/common/http';

const appRoutes = [
  { path: '', component: PersonalizedPageComponent },
  { path: 'product_broadband', component: ProductBroadbandComponent },
  { path: 'video-on-demand', component: VideoOnDemandComponent },
  { path: 'sliceasbundle', component: SliceAsBundleComponent },
  { path: 'internet', component: InternetComponent },
  { path: 'header', component: HeaderComponent },
  // { path: 'BillingAndShipping', component: BillingAndShippingComponent },
  { path: 'internet-bundle', component: InternetBundleComponent },
  { path: 'iot-bundle', component: IotBundleComponent },
  { path: 'content-bundle', component: ContentForBusinessBundleComponent },
  { path: 'PersonalizedPage', component: PersonalizedPageComponent },
  { path: 'product_ethernet', component: ProductEthernetComponent },
  { path: 'SmartWorkplaceBundle', component: SmartWorkplaceBundleComponent },
  { path: 'infrastructure_product', component: InfrastructureSecurityProductComponent },
  { path: 'ContentForBusiness', component: ContentForBusinessComponent },
  { path: 'ContentForBusiness/office_enterprise', component: ContentForBusinessComponent },
  { path: 'ContentForBusiness/travelhospitality', component: ContentForBusinessComponent },
  { path: 'iot_smartWork_Place', component: IotSmartWorkplaceComponent },
  { path: 'cart_summary', component: CartSummaryComponent },
  { path: 'slice_your_own_bundle', component: DesignYourOwnBundleComponent },
  { path: 'existing_user', component: ExistingUserComponent },
  { path: 'infra_detail', component: InfraDetailComponent },
  { path: 'ethernet_transport', component: EthernetAndTrasportComponent },
  { path: 'billing', component: BillingandshipmentComponent },
  {path:'cart_summary_new', component:CartSummaryNewComponent},
  {path:'billing_new',component:BillingNewComponent},
  {path:'redirect',component:RedirectComponent}

]


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    InternetComponent,
    PersonalizedPageComponent,
    SmartWorkplaceBundleComponent,
    ProductEthernetComponent,
    InfrastructureSecurityProductComponent,
    ContentForBusinessComponent,
    IotSmartWorkplaceComponent,
    CartSummaryComponent,
    DesignYourOwnBundleComponent,
    InternetBundleComponent,
    IotBundleComponent,
    ContentForBusinessBundleComponent,
    ExistingUserComponent,
    BillingandshipmentComponent,
    InfraDetailComponent,
    EthernetAndTrasportComponent,
    ProductBroadbandComponent,
    SliceAsBundleComponent,
    VideoOnDemandComponent,
    CartSummaryNewComponent,
    BillingNewComponent,
    RedirectComponent
  ],
  imports: [
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDdhxztr2cV9SAYGP1Mvntn_yYEbQluFHI'
    }),
    BrowserModule,
    HttpModule,
    OwlModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
    Ng5SliderModule,
    RouterModule.forRoot(appRoutes,{useHash:true})
  ],
  providers: [GoogleMapsAPIWrapper],
  bootstrap: [AppComponent]
})
export class AppModule { }
