import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';

@Component({
  selector: 'app-billing-new',
  templateUrl: './billing-new.component.html',
  styleUrls: ['./billing-new.component.css']
})
export class BillingNewComponent implements OnInit {
  banner: String;
  monthly_cost_total: Number = 0;
  one_time_cost_total: Number = 0;
  // display_name :String;
  c_display_name :String;
  // i_display_name :String;
  // s_display_name :String;
  // s_i_display_name: String;
  // s_s_display_name: String;
  // s_c_display_name: String;
  // ethernet_display_name :String;
  iot_display_name :String;
  infra_display_name :String;
 name_array =[];

  i_monthly_cost_total: Number;
  s_one_time_cost_total: number = 0;
  s_monthly_cost_total: Number = 0;
  iot_monthly_cost_total: Number = 0;
  infra_monthly_cost_total: Number = 0;
  c_monthly_cost_total: Number = 0;
  ethernet_monthly_cost_total: Number = 0;
  
  constructor(private service: ServiceService,
    private location: Location,
    private aroute: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.getBannerImage();
    this.getInternetCart();
    this.getSmartCart();
    this.getInfraCart();
    this.getIOTCart();
    this.getContentCart();
    this.getEthernetCart();

  }
    // get banner image

    getBannerImage() {
      this.service.getBannerImages()
        .subscribe((bannerdata) => {
          console.log(bannerdata);
  
          this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[5].url;
          console.log(' hello' + this.banner);
  
        });
    }
    //get product image
    getInternetCart() {
      let temp_i_cart = JSON.parse(localStorage.getItem('internet_cart'));
      this.i_monthly_cost_total = 0;
      this.monthly_cost_total = 0;
      let i_name :String;
  
      console.log(temp_i_cart);
      if (temp_i_cart != null) {
        for (let index = 0; index < temp_i_cart.length; index++) {
          i_name = "INTERNET";
          this.i_monthly_cost_total += (temp_i_cart[index].recurrencecost);
          this.i_monthly_cost_total = Number(this.i_monthly_cost_total)*0.9;
          this.monthly_cost_total = Math.floor(Number(this.monthly_cost_total)*0.9 + Number(temp_i_cart[index].recurrencecost)*0.9);
          this.one_time_cost_total = Math.floor(Number(this.one_time_cost_total)*0.9 + Number(temp_i_cart[index].salePrice)*0.9);
        }
        let tmp_detail ={
          displayName: i_name,
          t_monthly_cost_total: Math.floor(Number(this.i_monthly_cost_total)),
        }
        this.name_array.push(tmp_detail);
      }
    
      console.log(this.one_time_cost_total);
  
  
      // console.log(this.display_name);
      // console.log(this.monthly_cost_total);
      // console.log(this.one_time_cost_total);
  
  
  
    }
  
    // get content for business cart
  
    getContentCart() {
      let temp_c_cart = JSON.parse(localStorage.getItem('content_for_business_cart'));
      this.c_monthly_cost_total = 0;
  
  
      console.log(temp_c_cart);
      if (temp_c_cart != null) {
        for (let index = 0; index < temp_c_cart.length; index++) {
          this.c_display_name = "content for Business";
          this.c_monthly_cost_total += (temp_c_cart[index].recurrencecost);
          this.c_monthly_cost_total = Number(this.c_monthly_cost_total)*0.9;
          this.monthly_cost_total = Math.floor(Number(this.monthly_cost_total)*0.9 + Number(temp_c_cart[index].recurrencecost)*0.9);
          this.one_time_cost_total = Math.floor(Number(this.one_time_cost_total)*0.9 + Number(temp_c_cart[index].salePrice)*0.9);
        
        }
  
        let tmp_detail ={
          displayName: this.c_display_name,
          t_monthly_cost_total: Math.floor(Number(this.c_monthly_cost_total)),
        }
        this.name_array.push(tmp_detail);
      }
      
      // console.log(this.display_name);
      // console.log(this.monthly_cost_total);
      // console.log(this.one_time_cost_total);
  
  
  
    }
  
    // get smartbundle cart
    getSmartCart() {
      let temp_s_cart = JSON.parse(localStorage.getItem('smart_bunddle_cart'));
      let s_name:String;
      // this.monthly_cost_total = 0;
      this.s_monthly_cost_total = 0;
      this.s_one_time_cost_total = 0;
      console.log(temp_s_cart);
      if (temp_s_cart != null) {
  for (let index = 0; index < temp_s_cart.length; index++) {
    s_name = "Smart Wokplace Bundle";
          this.s_monthly_cost_total += (temp_s_cart[index].recurrencecost);
          this.s_monthly_cost_total = Number(this.s_monthly_cost_total)*0.9;
          this.monthly_cost_total = Math.floor(Number(this.monthly_cost_total)*0.9 + Number(temp_s_cart[index].recurrencecost)*0.9);
          this.one_time_cost_total = Math.floor(Number(this.one_time_cost_total)*0.9 + Number(temp_s_cart[index].salePrice)*0.9);
        }
        let tmp_detail ={
          displayName: s_name,
          t_monthly_cost_total: Math.floor(Number(this.s_monthly_cost_total)),
        }
        this.name_array.push(tmp_detail);
       
      }
     
  
    }
  
    // get iot cart
    getIOTCart() {
      let temp_iot_cart = JSON.parse(localStorage.getItem('iot_cart'));
      this.iot_monthly_cost_total = 0;
      let t_name:string;
  
  
      console.log(temp_iot_cart);
      if (temp_iot_cart != null) {
        for (let index = 0; index < temp_iot_cart.length; index++) {
          t_name= "IOT";
          this.iot_monthly_cost_total += (temp_iot_cart[index].recurrencecost);
          this.iot_monthly_cost_total = Number(this.iot_monthly_cost_total)*0.9;
          this.monthly_cost_total = Math.floor(Number(this.monthly_cost_total)*0.9 + Number(temp_iot_cart[index].recurrencecost)*0.9);
          this.one_time_cost_total = Math.floor(Number(this.one_time_cost_total)*0.9 + Number(temp_iot_cart[index].salePrice)*0.9);
        }
        let tmp_detail ={
          displayName: t_name,
          t_monthly_cost_total: Math.floor(Number(this.iot_monthly_cost_total)),
        }
        this.name_array.push(tmp_detail);
      
      }
     
      console.log(temp_iot_cart);
      

    }
  
    // get infra cart
    getInfraCart() {
      // localStorage.removeItem('infra_cart');
      let temp_infra_cart = JSON.parse(localStorage.getItem('infra_cart'));
      this.infra_monthly_cost_total = 0;
      let t_name:String;
  
  
      console.log('infra', temp_infra_cart);
      if (temp_infra_cart != null) {
        for (let index = 0; index < temp_infra_cart.length; index++) {
          t_name =  "InfraStructure Security"
          this.infra_monthly_cost_total += (temp_infra_cart[index].recurrencecost);
          this.infra_monthly_cost_total = Number(this.infra_monthly_cost_total)*0.9;
          this.monthly_cost_total = Math.floor(Number(this.monthly_cost_total)*0.9 + Number(temp_infra_cart[index].recurrencecost)*0.9);
          this.one_time_cost_total = Math.floor(Number(this.one_time_cost_total)*0.9 + Number(temp_infra_cart[index].salePrice)*0.9);
     
        }
        let tmp_detail ={
          displayName: t_name,
          t_monthly_cost_total: Math.floor(Number(this.infra_monthly_cost_total)),
        }
        this.name_array.push(tmp_detail);
      
      }
  
     

    }
  
    // get ethernet cart
    getEthernetCart() {
      let t_name:String;
      let temp_ethernet_cart = JSON.parse(localStorage.getItem('ethernet_cart'));
      this.ethernet_monthly_cost_total = 0;
      // this.one_time_cost_total = 0;
  
  
      console.log(temp_ethernet_cart);
      if (temp_ethernet_cart != null) {
        for (let index = 0; index < temp_ethernet_cart.length; index++) {
         t_name = "ETHERNET";
          this.ethernet_monthly_cost_total = Number(this.ethernet_monthly_cost_total) + Number(temp_ethernet_cart[index].recurrencecost);
          this.ethernet_monthly_cost_total = Number(this.ethernet_monthly_cost_total)*0.9;
          this.monthly_cost_total = Math.floor(Number(this.monthly_cost_total)*0.9 + Number(temp_ethernet_cart[index].recurrencecost)*0.9);
          this.one_time_cost_total = Math.floor(Number(this.one_time_cost_total)*0.9 + Number(temp_ethernet_cart[index].salePrice)*0.9);
       
        }
        
          let tmp_detail ={
            displayName: t_name,
            t_monthly_cost_total: Math.floor(Number(this.ethernet_monthly_cost_total)),
                     }
          this.name_array.push(tmp_detail);
        
      }
     
    }
  
    clear_localstorage(){

    localStorage.removeItem('internet_cart');
    localStorage.removeItem('ethernet_cart');
    localStorage.removeItem('infra_cart');
    localStorage.removeItem('iot_cart');
    localStorage.removeItem('smart_bunddle_cart');
    localStorage.removeItem('content_for_business_cart');


    this.getInternetCart();
    this.getSmartCart();
    this.getInfraCart();
    this.getIOTCart();
    this.getContentCart();
    this.getEthernetCart();
    }
  
  
  checkout(){
    console.log("checking out");
  }

}
