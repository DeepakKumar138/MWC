import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartWorkplaceBundleComponent } from './smart-workplace-bundle.component';

describe('SmartWorkplaceBundleComponent', () => {
  let component: SmartWorkplaceBundleComponent;
  let fixture: ComponentFixture<SmartWorkplaceBundleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartWorkplaceBundleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartWorkplaceBundleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
