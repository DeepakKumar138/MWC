import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
@Component({
  selector: 'app-smart-workplace-bundle',
  templateUrl: './smart-workplace-bundle.component.html',
  styleUrls: ['./smart-workplace-bundle.component.css']
})
export class SmartWorkplaceBundleComponent implements OnInit {

  product = [];
  products = [];
  monthly_total: number;
  counter_1: Number;
  counter_2: Number;
  counter_3: Number;
  check_1: boolean;
  check_2: boolean;
  check_3: boolean;

  cart_update:number;
  constructor(private service: ServiceService) { }

  ngOnInit() {
    this.service.login().subscribe((data:any)=>{
      this.service.getProduct().subscribe((data:any)=>{
        console.log(data);
        localStorage.setItem('product_internet',JSON.stringify(data));
      });
    });
    this.counter_1 = 1;
    this.counter_2 = 1;
    this.counter_3 = 1;
    this.check_1 = false;
    this.check_2 = false;
    this.check_3 = false;
    this.monthly_total = 0;
    this.getAllProduct();

    this.check_smart_cart();
  }

  onboard(){
environment.add =true;
  }
  counnter_1() {
    this.counter_1 = 2;
    this.counter_2 = 2;
    this.counter_3 = 2;
    let tempproduct = {

    }
    let temp_i={
   
    }
    let i_product= [];
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    // console.log('temp', JSON.parse(localStorage.getItem('product_internet')));

    for (let index = 0; index < temp_product.products.length; index++) {
      if (temp_product.products[index].id == "INT_001") {
        console.log(temp_product.products[index]);
          temp_i ={
            id:temp_product.products[index].id,
            displayName:temp_product.products[index].displayName,
            salePrice:temp_product.products[index].listPrice,
            recurrencecost:temp_product.products[index].x_recurrencecost
          }
        i_product.push(temp_i);
        localStorage.setItem('internet_bundle', JSON.stringify(i_product));

        // console.log(localStorage.getItem('internet_bundle'));
        
       
      }
    }
  }

  counnter_2() {

    this.counter_1 = 2;
    this.counter_2 = 2;
    this.counter_3 = 2;

    let temp_i={
   
    }
    let i_product= [];
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    // console.log('temp', JSON.parse(localStorage.getItem('product_internet')));

    for (let index = 0; index < temp_product.products.length; index++) {
      if (temp_product.products[index].id == "ASST_001") {
        // console.log(temp_product.products[index]);
          temp_i ={
            id: temp_product.products[index].id,
            displayName:temp_product.products[index].displayName,
            salePrice:temp_product.products[index].listPrice,
            recurrencecost:temp_product.products[index].x_recurrencecost

          }
        i_product.push(temp_i);
        localStorage.setItem('iot_bundle', JSON.stringify(i_product));

        console.log(localStorage.getItem('iot_bundle'));
        
       
      }
    }
  }

  counnter_3() {
    this.counter_1 = 2;
    this.counter_2 = 2;
    this.counter_3 = 2;


    let temp_i={
   
    }
    let i_product= [];
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    // console.log('temp', JSON.parse(localStorage.getItem('product_internet')));

    for (let index = 0; index < temp_product.products.length; index++) {
      if (temp_product.products[index].id == "OFF_001") {

        
        
        // console.log(temp_product.products[index]);
          temp_i ={
            id:temp_product.products[index].id,
            displayName:temp_product.products[index].displayName,
            salePrice:temp_product.products[index].listPrice,
            recurrencecost:temp_product.products[index].x_recurrencecost

          }
        i_product.push(temp_i);
        localStorage.setItem('content_bundle', JSON.stringify(i_product));

        // console.log(localStorage.getItem('content_bundle'));
        
       
      }
    }
  }



  check_smart_cart(){

      let temp_smart_cart = JSON.parse(localStorage.getItem('smart_bunddle_cart'));
      console.log('hello',temp_smart_cart);
      if(temp_smart_cart == null){
        this.check_1 = true;
        this.check_2 = true;
        this.check_3 = true;
      }
      else{
        for (let index = 0; index < temp_smart_cart.length; index++) {
          if(temp_smart_cart[index].id == "INT_001" ){
            this.counter_1 = 3;
           console.log(this.counter_1);
           }
           else if(temp_smart_cart[index].id == "ASST_001" ){
            this.counter_2 = 3;
           console.log(this.counter_1);
           }
           else if(temp_smart_cart[index].id == "OFF_001" ){
            this.counter_3 = 3;
           console.log(this.counter_1);
           }
          
      }
      }
  }
  // get product sorted by bandwidth

  getAllProduct() {
    this.products = [];


    let tempproduct = {

    }
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    // console.log('temp', JSON.parse(localStorage.getItem('product_internet')));

    for (let index = 0; index < temp_product.products.length; index++) {
      if (temp_product.products[index].id == "INT_001") {
        // console.log(temp_product.products[index]);
        this.products.push(temp_product.products[index]);
        
        this.monthly_total += temp_product.products[index].x_recurrencecost;
        // console.log(this.monthly_total);
      }

      else if (temp_product.products[index].id == 'ASST_001') {

        this.monthly_total += temp_product.products[index].x_recurrencecost;
        // console.log(this.monthly_total);
        this.products.push(temp_product.products[index]);
        // console.log(temp_product.products[index]);
      }
      else if (temp_product.products[index].id == 'OFF_001') {
        this.monthly_total += temp_product.products[index].x_recurrencecost;
        this.products.push(temp_product.products[index]);
        // console.log(this.monthly_total);
        // console.log(temp_product.products[index]);
      }
    }
  }


  addToCart() {
   let smart_cart=JSON.parse(localStorage.getItem('smart_bunddle_cart')); 

    // console.log(t  his.products);
    let add_product= [];
    for (let index = 0; index < this.products.length; index++) {
      let temp ={
        id: this.products[index].id,
        displayName:this.products[index].displayName,
        salePrice:this.products[index].listPrice,
        recurrencecost:this.products[index].x_recurrencecost
      }
       add_product.push(temp);
    }
    // console.log(add_product);

    // environment.smartbundle_cart.push(internet)
    localStorage.setItem('smart_bunddle_cart', JSON.stringify(add_product));

    this.counter_1 = 3;
    this.counter_2 = 3;
    this.counter_3 = 3;

    if(smart_cart !=null ){
      this.cart_update = 0;
    } 
    else{
      this.cart_update =1;  }
    let add_to_cart_val=document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText=String(Number(add_to_cart_val)+this.cart_update);
    console.log(JSON.parse(localStorage.getItem('smart_bunddle_cart')));
    // if(smart_cart !=null ){
    //   this.cart_update = 0;
    // } 
    // else{

    //   this.cart_update =1;  }

    // document.getElementById('headCount').innerText=this.cart_update;
    // console.log(JSON.parse(localStorage.getItem('smart_bunddle_cart')));
  }
}
