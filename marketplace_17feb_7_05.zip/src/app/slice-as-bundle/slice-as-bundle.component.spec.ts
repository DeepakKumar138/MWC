import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SliceAsBundleComponent } from './slice-as-bundle.component';

describe('SliceAsBundleComponent', () => {
  let component: SliceAsBundleComponent;
  let fixture: ComponentFixture<SliceAsBundleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SliceAsBundleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SliceAsBundleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
