import { Component } from '@angular/core';
import { ServiceService } from './services/service.service';
// import { Product } from './model/product'
import { environment } from '../environments/environment'
import { logging } from 'protractor';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'marketplace';
  
  constructor(private service: ServiceService) {
    // localStorage.clear();
    // this.login();
    // this.getUser();
  }




  ngOnit() {

  }





}
