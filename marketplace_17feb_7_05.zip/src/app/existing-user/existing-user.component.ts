import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../services/service.service';

@Component({
  selector: 'app-existing-user',
  templateUrl: './existing-user.component.html',
  styleUrls: ['./existing-user.component.css']
})
export class ExistingUserComponent implements OnInit {

  total_bundle_cost: Number;
  viewDetail = [];
  bundle_product = [];
  bundle_name: String;
  status: Number;
  cart_update: number;
  product = [];
  banner:String;
  constructor(private service:ServiceService) { }

  ngOnInit() {
    this.getBannerImage();
    this.viewBundle();
  }

  
  getBannerImage() {
    this.service.getBannerImages()
      .subscribe((bannerdata) => {
        console.log(bannerdata);

        this.banner ='http://52.5.252.249:8080/documents/20126/35667/existing_cusbanner.jpg';
        console.log(' hello' + this.banner);

      });
  }
  // view bundle Detail
  viewBundle() {
    // this.total_bundle_cost = 0;
    let monthly_price: Number;
    this.viewDetail = JSON.parse(localStorage.getItem('e_savebundle'));

    console.log(this.viewDetail);
    // this.bundle_name = this.viewDetail.;

    for (let index = 0; index < this.viewDetail.length; index++) {
      monthly_price = 0;
      for (let secondindex = 0; secondindex < this.viewDetail[index].product_Array.length; secondindex++) {
        monthly_price = Number(monthly_price) + Number(this.viewDetail[index].product_Array[secondindex].recurrencecost);

      }
      let tmep_bundle = {
        bundleName: this.viewDetail[index].bundleName,
        recurrencecost: monthly_price
      }
      this.bundle_product.push(tmep_bundle);

    }

    console.log(this.bundle_name);
    console.log(this.bundle_product);

  }

  addToCart(id) {
    let pid = id;
    let prod = [];
    let prod_temp:any;
    let tempbundle = JSON.parse(localStorage.getItem('e_savebundle'));
    for (let index = 0; index < tempbundle.length; index++) {
      if (pid == tempbundle[index].bundleName) {
        prod_temp = tempbundle[index];
      }

     
    }
    this.product.push(prod_temp);
    let olddata = JSON.parse(localStorage.getItem('bundle_info'));

    if (JSON.parse(localStorage.getItem("bundle_info")) == null) {
      localStorage.setItem('bundle_info', JSON.stringify(this.product));
      // environment.internet_cart.push(internet)
    }
    else {
      prod = JSON.parse(localStorage.getItem("bundle_info"));
      prod.push(prod_temp);
     

      localStorage.setItem('bundle_info', JSON.stringify(prod));
       console.log(prod)

    } // final_bundle.push(tempbundle,this.bundle_name)


    let temp = JSON.parse(localStorage.getItem('bundle_info'));
    this.status = 1;
    console.log('hello', JSON.parse(localStorage.getItem('bundle_info')));


    let add_to_cart_val = document.getElementById('headCount').innerText;
    document.getElementById('headCount').innerText = String(Number(add_to_cart_val) + 1);


  }

}
