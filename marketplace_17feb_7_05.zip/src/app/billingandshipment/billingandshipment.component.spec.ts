import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingandshipmentComponent } from './billingandshipment.component';

describe('BillingandshipmentComponent', () => {
  let component: BillingandshipmentComponent;
  let fixture: ComponentFixture<BillingandshipmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingandshipmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingandshipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
