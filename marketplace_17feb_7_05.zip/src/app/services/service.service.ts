import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  once: any;

  constructor(private http: Http) { }

  
  // get All Product
  getProduct() {
    let token = localStorage.getItem('token');
    //  headers = new Headers();
    let headers = new Headers({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT,DELETE',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': '' + 'Bearer ' + token,
      'X-CCAsset-Language': 'en-US'
    });

    return this.http.get('http://52.5.252.249:3000/getProducts', { headers: headers })
      .pipe(map(res => res.json()));

  }

  setvalue(val){
    console.log("val is ", val);
    this.once = val;
  }



  // get banner images
  getBannerImages() {

    return this.http.get('http://52.5.252.249:8080/o/CMSTelecomDemo/v1/webPageAssets/Banners')
      .pipe(map(res => res.json()));
  }


  // get banner images
  getaddress() {

    return this.http.get('http://52.5.252.249:3000/getEnterpriseDetails')
      .pipe(map(res => res.json()));
  }

  login() {

    let headers = new Headers({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT,DELETE',
      'Content-Type': 'application/x-www-form-urlencoded',
    });

    return this.http.post('http://52.5.252.249:3000/login', { headers: headers })
      .pipe(map(res => res.json()));
  }

  // get customer
  getcustomer(id) {
    let headers = new Headers({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT,DELETE',
    });
   
    return this.http.get('http://52.5.252.249:3000/getCustomerDetails/' + id, { headers: headers })
      .pipe(map(res => res.json()));
  }
}
