/// <reference types = "@types/googlemaps" />
import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product';
import { environment } from '../../environments/environment';
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
import { GoogleMapsAPIWrapper } from '@agm/core';
declare let google: any;
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

declare var bandwidth: String;
@Component({
  selector: 'app-ethernet-and-trasport',
  templateUrl: './ethernet-and-trasport.component.html',
  styleUrls: ['./ethernet-and-trasport.component.css']
})
export class EthernetAndTrasportComponent implements OnInit {

product = [];
address1 =[];
address2 = [];
street1:String;
city1 :String;
state1: String;
zip1:String;
street2:String;
city2 :String;
state2: String;
zip2:String; 
model_name:String;
monthly_cost:Number;
devided_cost:Number;
bandwidth:Number;

cart_update=0;


map:any;
lat: number = 12.8335794;
lng: number = 77.6449037;
search: any = "";
closeResult: string;
flag = false;
own: boolean = false;
ownMarkers: any = [];
partner: boolean = false;
trial: boolean = false;
partnerMarkers: any = [];
fiveGMarkers: any = [];
greenicon = "./../../../assets/icons/greenAgmMarker.png";
blueicon = "./../../../assets/icons/blueAgmMarker.png";
blackicon = "./../../../assets/icons/blackAgmMarker.png";



constructor(private modalService: NgbModal, public gMaps: GoogleMapsAPIWrapper) { }
mouseover(infoWindow){
  infoWindow.open();
}


  ngOnInit() {
    $(".image-checkbox").each(function () {
		  if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
		    $(this).addClass('image-checkbox-checked');
		  }
		  else {
		    $(this).removeClass('image-checkbox-checked');
		  }
		});

		// sync the state to the input
		$(".image-checkbox").on("click", function (e) {
		  $(this).toggleClass('image-checkbox-checked');
		  var $checkbox = $(this).find('input[type="checkbox"]');
		  $checkbox.prop("checked",!$checkbox.prop("checked"))

		  e.preventDefault();
		});

     
    $(document).ready(function()
    {
      $("#dtBox").DateTimePicker({
      
        dateFormat: "MM-dd-yyyy",
        timeFormat: "HH:mm",
        dateTimeFormat: "MM-dd-yyyy HH:mm:ss AA"
      
      });
    });
    this.fetchProduct();
       
  }

  markers: marker[];

  protected mapReady(map) {
    this.map = map;
    this.getLocation();
  }

  // mapabc(){
  //   window.close();
  // }

  zip(event){
    this.search = event.target.value;
    
    console.log(this.search);
  }

  getLocation() {
    if (this.flag == true) {
      this.flag = false;
    }
    var elem = document.getElementsByTagName("div")[0];
    // elem.setAttribute("style", "max-width:1300px !important;");
    var geocoder = new google.maps.Geocoder();
    console.log("search", this.search);
    var map = this.map;
    var x = this;
    geocoder.geocode({ 'address': this.search }, function (results, status) {
      if (status == 'OK') {
        map.setCenter(results[0].geometry.location);
        x.lat = results[0].geometry.location.lat();
        x.lng = results[0].geometry.location.lng();
        x.markers = [
          {

            lat: x.lat,

            lng: x.lng

          }
        ];
        console.log("lat", results[0].geometry.location.lng());
        if (this.own == true) {
          this.changed("own");
        }
        else if (this.partner == true) {
          this.changed("partner");
        }
        else {
          this.changed("five");
        }
        // var marker = new google.maps.Marker({
        //     map: map,
        //     position: results[0].geometry.location
        // });

      } else {
        alert('Geocode was not successful for the following reason: ' + status);
      }
    });
  }


  changed(value) {
    if (value == "own") {
      this.own = !this.own;
      if (this.own == true) {
        this.ownMarkers.push({

          lat: this.lat,
          status: "Active",
          b_name: "Kiko Milano",
          s_name: "Avinguda del portal",
          b_id: "16",
          b_category: "Cosmetics store",
          a_type: "OnNet",
          cabling: "No",
          lng: this.lng

        }, {

            lat: this.lat + 0.003,
            status: "Active",
            b_name: "Tibidado parc",
            s_name: "Carrer de la Canuda",
            b_category: "Amusement park",
            a_type: "OnNet",
            cabling: "No",b_id: "7",
            lng: this.lng + 0.002

          },
          {

            lat: this.lat + 0.002,
            status: "Active",
            b_name: "Alpine restaurant",
            s_name: "Avinguda alad",
            b_category: "Restaurant",
            a_type: "OnNet",
            cabling: "No",b_id: "19",
            lng: this.lng + 0.003

          },
          {

            lat: this.lat - 0.002,
            status: "Active",
            b_name: "Ronald Regan shop",
            s_name: "delo portalis",
            b_category: "Book Store",
            a_type: "OnNet",
            cabling: "No",b_id: "10",
            lng: this.lng + 0.003

          },
          {

            lat: this.lat - 0.003,
            status: "Active",
            b_name: "Aka Milano",
            s_name: "Da vici street",
            b_category: "NA",
            a_type: "OnNet",
            cabling: "Yes",b_id: "17",
            lng: this.lng - 0.001

          });
      } else {
        this.ownMarkers = [];
      }
    }
    else if (value == "partner") {
      this.partner = !this.partner;
      if (this.partner == true) {
        this.partnerMarkers.push(
          {

            lat: this.lat - 0.002,
            status: "Active",
            b_name: "Misako",
            s_name: "Da vici street",
            b_category: "Handbag shop",
            a_type: "OffNet",
            cabling: "No",b_id: "26",
            lng: this.lng - 0.003

          },
          {

            lat: this.lat - 0.003,
            status: "Active",
            b_name: "Hotel Catalonia",
            s_name: "Avinguda del portal",
            b_category: "Hotel",
            a_type: "OffNet",
            cabling: "Yes",b_id: "8",
            lng: this.lng - 0.002

          },
          {

            lat: this.lat + 0.002,
            status: "Active",
            b_name: "Abacus shop",
            s_name: "Da vici street",
            b_category: "Shop",
            a_type: "OffNet",
            cabling: "No",b_id: "23",
            lng: this.lng - 0.003

          },
          {

            lat: this.lat - 0.002,
            status: "Active",
            b_name: "Disney store",
            s_name: "Da vici street",
            b_category: "Toy shop",
            a_type: "OffNet",
            cabling: "Yes",b_id: "54",
            lng: this.lng + 0.003

          }
        );
      } else {
        this.partnerMarkers = [];
      }
    }
    else {
      this.trial = !this.trial;
      if (this.trial == true) {
        this.fiveGMarkers.push({

          lat: this.lat + 0.0013,
          status: "Active",
            b_name: "Disney store",
            s_name: "Da vici street",
            b_category: "Toy shop",
            a_type: "5G",
            cabling: "Yes",b_id: "65",
          lng: this.lng - 0.0034

        },
          {

            lat: this.lat - 0.0021,
            status: "Active",
            b_name: "Aka Milano",
            s_name: "Da vici street",
            b_category: "NA",
            a_type: "5G",
            cabling: "Yes",b_id: "25",
            lng: this.lng + 0.0002

          },
          {

            lat: this.lat - 0.0027,
            status: "Active",
            b_name: "Abacus shop",
            s_name: "Da vici street",
            b_category: "Shop",
            a_type: "5G",
            cabling: "Yes",b_id: "34",
            lng: this.lng - 0.0012

          },
          {

            lat: this.lat + 0.0017,
            status: "Active",
            b_name: "Alpine restaurant",
            s_name: "Avinguda alad",
            b_category: "Restaurant",
            a_type: "5G",
            cabling: "Yes",b_id: "26",
            lng: this.lng - 0.0027

          });
      } else {
        this.fiveGMarkers = [];
      }
    }
  }


  open(content) {
    console.log(this.zip2);
    this.modalService.open(content, { size: 'lg', centered: true });
    var elem = document.getElementsByTagName("div")[0];
    elem.setAttribute("style", "max-width:1050px !important;");
    var elem2 = document.getElementsByTagName("ngb-modal-window")[0];
    elem2.setAttribute("style", "background: rgba(0, 0, 0, 0.4);");
    // console.log("child nodes",document.getElementsByClassName("modal-lg")[0]);

    // this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
  }


  showlocation2()
  {
    $("#location2").removeClass("eht_hidelocation");
    $("#button1").removeClass("active");

    $("#location1").addClass("eht_hidelocation");
    $("#button2").addClass("active");
  }
showlocation1()
  {
    $("#location1").removeClass("eht_hidelocation");
    $("#button2").removeClass("active");

    $("#location2").addClass("eht_hidelocation");
    $("#button1").addClass("active");
  }



  // fetch  add  product
fetchProduct(){
  let tmp_ethernet = JSON.parse(localStorage.getItem('ethernet_detail'));
  this.product.push(tmp_ethernet[0]);
  this.model_name = tmp_ethernet[0].displayName;
 this.bandwidth = tmp_ethernet[0].bandwidth;
 this.monthly_cost =tmp_ethernet[0].recurrencecost;
 this.devided_cost = Number(this.monthly_cost) / 2;
 
 console.log(this.product);
}


   // ADD TO CART
   addtocart() 
   {
    let cart_ary=JSON.parse(localStorage.getItem('ethernet_cart')); 
       let ethernet_detail = [];
              // this.modal_prodcut_name = this.product[index].displayName;
               let ethernetdetailData = {
                   id: this.product[0].id,
                   displayName: this.product[0].displayName,
                   salePrice: this.product[0].salePrice,
                   bandwidth: this.product[0].bandwidth,
                   recurrencecost: this.product[0].recurrencecost,
                   recurrencePeriod: this.product[0].recurrencePeriod,
                  address1:[ this.street1,this.city1,this.state1,this.zip1],
                  address2:[ this.street2,this.city2,this.state2,this.zip2]
               }

                   ethernet_detail.push(ethernetdetailData);
                   localStorage.setItem('ethernet_cart', JSON.stringify(ethernet_detail));
              
       console.log('ethernet');
       console.log(ethernet_detail);
       // this.router.navigate(['cart_summary/']);
       if(cart_ary !=null ){
        this.cart_update = 0;
      } 
      else{
        this.cart_update =1;  }

       let add_to_cart_val=document.getElementById('headCount').innerText;
      document.getElementById('headCount').innerText=String(Number(add_to_cart_val)+this.cart_update);

       console.log(JSON.parse(localStorage.getItem('ethernet_cart')));
   }

}

interface marker {
  lat: number;
  lng: number;
}

