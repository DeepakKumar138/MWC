import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EthernetAndTrasportComponent } from './ethernet-and-trasport.component';

describe('EthernetAndTrasportComponent', () => {
  let component: EthernetAndTrasportComponent;
  let fixture: ComponentFixture<EthernetAndTrasportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EthernetAndTrasportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EthernetAndTrasportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
