import { Component, ElementRef, OnInit } from '@angular/core';
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router,NavigationEnd } from '@angular/router';
import { log } from 'util';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  cart_total: Number = 0;
  //cart_counter
  cart_counter : any;

  // cart_total: Number = 0;
  //cart_counter
  c_bunddle_c : any;
  smart_bunddle_c : any;
  internet_c : any;
  iot_c : any;
  con_b_c : any;
  infra_c : any;
  ether_c:any;
  
  // cart_counter : any;


constructor(private router: Router) { }

sliceAsBundle(){
  window.open("http://52.6.121.116:3200/#/sliceAsBundle");
}

ngOnInit() {
  this.router.events.subscribe((evt) => {
    if (!(evt instanceof NavigationEnd)) {
        return;
    }
    window.scrollTo(0, 0)
});
  $("script[src='assets/js/menu.js']").remove();

  let tempproduct = {
  }
  
  let temp_product = JSON.parse(localStorage.getItem('smart_bunddle_cart'));
  let temp_product_internet = JSON.parse(localStorage.getItem('internet_cart'));
  let temp_product_c_bundle = JSON.parse(localStorage.getItem('bundle_info'));
  
  let temp_product_iot = JSON.parse(localStorage.getItem('iot_cart'));
  let temp_product_content_b = JSON.parse(localStorage.getItem('content_for_business_cart'));
  let temp_product_infra_cart = JSON.parse(localStorage.getItem('infra_cart'));
  let temp_product_ethernet_cart = JSON.parse(localStorage.getItem('ethernet_cart'));

  console.log(temp_product_c_bundle);

  if(temp_product!=null){
    this.smart_bunddle_c= 1;
  }else{
    this.smart_bunddle_c=0;
  }


  if(temp_product_c_bundle!=null){
    this.c_bunddle_c=temp_product_c_bundle.length;
  }else{
    this.c_bunddle_c=0;
  }


  if(temp_product_internet!=null){
    this.internet_c=temp_product_internet.length;
  }else{
    this.internet_c=0;
  }

  if(temp_product_iot!=null){
    this.iot_c=temp_product_iot.length;
  }else{
    this.iot_c=0;
  }

  if(temp_product_content_b!=null){
    this.con_b_c=temp_product_content_b.length;
  }else{
    this.con_b_c=0;
  }

  if(temp_product_infra_cart!=null){
    this.infra_c=temp_product_infra_cart.length;
  }else{
    this.infra_c=0;
  }

  if(temp_product_ethernet_cart!=null){
    this.ether_c=temp_product_ethernet_cart.length;
  }else{
    this.ether_c=0;
  }

  this.cart_total=this.smart_bunddle_c+this.internet_c+this.iot_c+this.con_b_c+this.infra_c+this.ether_c+this.c_bunddle_c;

  // console.log('temp', JSON.parse(localStorage.getItem('smart_bunddle_cart'))); 
  // this.cart_counter=temp_product.length;
  // console.log('temp length', temp_product.length); 

 

  var dynamicScripts = [
    "assets/js/menu.js",
  ];

  for (var i = 0; i < dynamicScripts.length; i++) {
    let node = document.createElement('script');
    node.src = dynamicScripts[i];
    node.type = 'text/javascript';
    node.async = false;
    node.charset = 'utf-8';
    document.getElementsByTagName('head')[0].appendChild(node);
  }

}



// cart_update(){
//   this.cart_total = 0;

//   for (let index = 0; index < environment.internet_cart.length; index++) {
//     this.cart_total = Number(this.cart_total)+ 1;    
//   }
// }



intelligent(){
  window.open('http://125.18.12.68:8080/Barcelona_POC/');
}

fleet(){
  window.open('http://125.18.12.68:8080/SmartBus');
}

ot(){
  window.open('http://125.18.12.69:8080/wd/login.jsf');
}

smartcity(){
  window.open('https://www.google.com','_self');
}

}
