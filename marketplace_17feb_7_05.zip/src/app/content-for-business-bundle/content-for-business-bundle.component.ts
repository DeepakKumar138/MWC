import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
declare var bandwidth: String;
@Component({
  selector: 'app-content-for-business-bundle',
  templateUrl: './content-for-business-bundle.component.html',
  styleUrls: ['./content-for-business-bundle.component.css']
})
export class ContentForBusinessBundleComponent implements OnInit {
  channel: number = 0;
  location: number = 10;
  Hours: number = 10;
  contact: number = 10;
  options: Options = {
    floor: 10,
    ceil: 1000
  };

  
  ch_options: Options = {
    floor: 0,
    ceil: 350
  };
  text = 'Add to Bundle';
banner:String;
product =[];
modal_prodcut_name:String;
  constructor(private service: ServiceService) { }

  ngOnInit() {
 
    this.service.login().subscribe((data:any)=>{
      this.service.getProduct().subscribe((data:any)=>{
        console.log(data);
        localStorage.setItem('product_internet',JSON.stringify(data));
      });
    });

    // image gallery
    $(".image-checkbox").each(function () {
      if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
        $(this).addClass('image-checkbox-checked');

      }
      else {
        $(this).removeClass('image-checkbox-checked');
      }
    });

    // sync the state to the input
    $(".image-checkbox").on("click", function (e) {
      $(this).toggleClass('phovercontent_active proicon_chkbox');
      $(this).toggleClass('image-checkbox-checked');
      var $checkbox = $(this).find('input[type="checkbox"]');
      $checkbox.prop("checked", !$checkbox.prop("checked"))

      e.preventDefault();
    });
    this.getBannerImage();
    this.fetchBundleProduct();
  }

 
  getBannerImage() {
    this.service.getBannerImages()
      .subscribe((bannerdata) => {
console.log(bannerdata);

        this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[7].url;
        // console.log(' banner' + this.banner);

      });
  }


// fetch bundle product
fetchBundleProduct(){
  let tmp_internet = JSON.parse(localStorage.getItem('content_bundle'));
  this.product.push(tmp_internet[0]);
  console.log(this.product);
}


  getAllProduct() {
    this.product = [];
    // this.cart_btn = "Add to cart";
    let tempproduct = {

    }
    // let tempB = null;
    let temp_product = JSON.parse(localStorage.getItem('product_internet'));
    console.log(temp_product);


    for (let index = 0; index < temp_product.products.length; index++) {

      if (temp_product.products[index].parentCategories[0].repositoryId == 'CONTC_001') {
      
        let tempdata = {
          catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
          id: temp_product.products[index].id,
          type: temp_product.products[index].type,
          displayName: temp_product.products[index].displayName,
          salePrice: temp_product.products[index].listPrice,
          channel: temp_product.products[index].x_cHANNEL,
          recurrencecost: temp_product.products[index].x_recurrencecost,
          recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
          description: temp_product.products[index].description
        }
        this.product.push(tempdata);
        this.product.forEach((item, index) => {
          if (index !== this.product.findIndex(i => i.id === item.id)) {
            this.product.splice(index, 1);
          }

        });
      

        console.log(this.product);

       
      //   if (temp_product.products[index].x_cHANNEL <= this.channel &&  this.channel <= 100 && temp_product.products[index].x_cHANNEL <= 100) {
      //     let tempdata = {
      //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
      //       id: temp_product.products[index].id,
      //       type: temp_product.products[index].type,
      //       displayName: temp_product.products[index].displayName,
      //       salePrice: temp_product.products[index].listPrice,
      //       channel: temp_product.products[index].x_cHANNEL,
      //       recurrencecost: temp_product.products[index].x_recurrencecost,
      //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
      //       description: temp_product.products[index].description
      //     }
      //     this.product.push(tempdata);
      //     this.product.forEach((item, index) => {
      //       if (index !== this.product.findIndex(i => i.id === item.id)) {
      //         this.product.splice(index, 1);
      //       }

      //     });
        

      //     console.log(this.product);

      //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
      //   }
      //  else if (temp_product.products[index].x_cHANNEL <= this.channel &&  this.channel <= 300 && temp_product.products[index].x_cHANNEL <= 300) {
      //     let tempdata = {
      //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
      //       id: temp_product.products[index].id,
      //       type: temp_product.products[index].type,
      //       displayName: temp_product.products[index].displayName,
      //       salePrice: temp_product.products[index].listPrice,
      //       channel: temp_product.products[index].x_cHANNEL,
      //       recurrencecost: temp_product.products[index].x_recurrencecost,
      //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
      //       description: temp_product.products[index].description
      //     }
      //     this.product.push(tempdata);
      //     this.product.forEach((item, index) => {
      //       if (index !== this.product.findIndex(i => i.id === item.id)) {
      //         this.product.splice(index, 1);
      //       }

      //     });
        

      //     console.log(this.product);

      //     // localStorage.setItem('product_internet', JSON.stringify(this.product));
      //   }

      //   else if (temp_product.products[index].x_cHANNEL > 300) {
      //     let tempdata = {
      //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
      //       id: temp_product.products[index].id,
      //       type: temp_product.products[index].type,
      //       displayName: temp_product.products[index].displayName,
      //       salePrice: temp_product.products[index].listPrice,
      //       bandwidth: temp_product.products[index].x_bANDWIDTH,
      //       recurrencecost: temp_product.products[index].x_recurrencecost,
      //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
      //       description: temp_product.products[index].description
      //     }
      //     this.product.push(tempdata);
      //     this.product.forEach((item, index) => {
      //       if (index !== this.product.findIndex(i => i.id === item.id)) {
      //         this.product.splice(index, 1);
      //       }

      //     });
        

      //     console.log(this.product);

      //   }
      }

    }

  }
 



  // ADD TO CART

  addToCart(id) {

    document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove From Bundle" ? "Add to Bundle" : "Remove From Bundle";

    let p_id = id;
    // this.cart_btn ="Remove";
    let content_for_business_cart = [];
    for (let index = 0; index < this.product.length; index++) {
      if (this.product[index].id === p_id) {
        this.modal_prodcut_name = this.product[index].displayName;
        let internet = {
          id: this.product[index].id,
          displayName: this.product[index].displayName,
          salePrice: this.product[index].salePrice,
          bandwidth: this.product[index].bandwidth,
          recurrencecost: this.product[index].recurrencecost,
    
        }
         content_for_business_cart = JSON.parse(localStorage.getItem("smart_bunddle_cart"));


          content_for_business_cart = JSON.parse(localStorage.getItem("smart_bunddle_cart"));
        
          for (let index = 0; index < content_for_business_cart.length; index++) {
            content_for_business_cart[2] =internet ;

          }
            console.log(content_for_business_cart);
            
         
          localStorage.setItem('smart_bunddle_cart', JSON.stringify(content_for_business_cart));
  
      }


    }



    console.log(JSON.parse(localStorage.getItem('smart_bunddle_cart')));
    // this.router.navigate(['cart_summary/']);

    // console.log(localStorage.getItem('product_internet'));
  }
}
