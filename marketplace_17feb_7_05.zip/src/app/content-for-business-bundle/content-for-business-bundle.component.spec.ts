import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentForBusinessBundleComponent } from './content-for-business-bundle.component';

describe('ContentForBusinessBundleComponent', () => {
  let component: ContentForBusinessBundleComponent;
  let fixture: ComponentFixture<ContentForBusinessBundleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentForBusinessBundleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentForBusinessBundleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
