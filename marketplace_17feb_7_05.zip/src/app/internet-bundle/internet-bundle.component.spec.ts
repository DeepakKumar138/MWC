import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternetBundleComponent } from './internet-bundle.component';

describe('InternetBundleComponent', () => {
  let component: InternetBundleComponent;
  let fixture: ComponentFixture<InternetBundleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternetBundleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternetBundleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
