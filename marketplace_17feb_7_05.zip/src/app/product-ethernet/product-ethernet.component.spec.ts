import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductEthernetComponent } from './product-ethernet.component';

describe('ProductEthernetComponent', () => {
  let component: ProductEthernetComponent;
  let fixture: ComponentFixture<ProductEthernetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductEthernetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductEthernetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
