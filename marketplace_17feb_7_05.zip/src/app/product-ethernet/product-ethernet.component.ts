import { Component,ElementRef, OnInit } from '@angular/core';
declare var $: any;
import {OwlCarousel} from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
declare var bandwidth: String;
import { Options } from 'ng5-slider';
import { Router, NavigationEnd } from '@angular/router';
import { WindowRefService } from '../services/window-ref.service';
import * as jwt from 'jsonwebtoken';


@Component({
  selector: 'app-product-ethernet',
  templateUrl: './product-ethernet.component.html',
  styleUrls: ['./product-ethernet.component.css']
})
export class ProductEthernetComponent implements OnInit {

    _w: any;
    chatBox: any;

  bandwidth: number = 0;
  Contract: number = 0;
  location: number = 0;
  employe: number = 0 ;
  options: Options = {
        floor: 10,
        ceil: 1024
    };
    modal_prodcut_name:string;
  product = new Array;
  repositoryId: string;
  displayName: string;
  salePrice: string;
  description: string;
  items = new Array;
  constructor(private service: ServiceService,
    private winRef:WindowRefService,
    private router: Router) {
        this._w = this.winRef.nativeWindow;
     }

  ngOnInit() {

    this.service.login().subscribe((data:any)=>{
        this.service.getProduct().subscribe((data:any)=>{
          console.log(data);
          localStorage.setItem('product_internet',JSON.stringify(data));
        });
      });

    this.router.events.subscribe((evt) => {
        if (!(evt instanceof NavigationEnd)) {
            return;
        }
        window.scrollTo(0, 0)
    });
    // (function () {

    //    let selector = '[data-rangeSlider]',
    //      elements = document.querySelectorAll(selector);
    //    // Basic rangeSlider initialization
    //    rangeSlider.create(elements, {

    //      // Callback function
    //      onInit: function () {
    //      },

    //      // Callback function
    //      onSlideStart: function (value, percent, position) {
    //        console.info('onSlideStart', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
    //      },

    //      // Callback function
    //      onSlide: function (value, percent, position) {
    //        console.log('onSlide', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
    //      },

    //      // Callback function
    //      onSlideEnd: function (value, percent, position) {
    //        console.warn('onSlideEnd', 'value: ' + value, 'percent: ' + percent, 'position: ' + position);
    //      }
    //    });
    //  })();

     $('.fitment-carousel').owlCarousel({
      loop:true,
      margin:10,
      nav:true,
       navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
      responsive:{
          0:{
              items:1
          },
          600:{
              items:2
          },
          1000:{
              items:2
          }
      }
  })

  $('.rightpro-carousel').owlCarousel({
      loop:true,
      margin:10,
      nav:true,
       navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
      responsive:{
          0:{
              items:1
          },
          600:{
              items:2
          },
          1000:{
              items:3
          }
      }
  })

  	// init the state from the input
    $(".image-checkbox").each(function () {
      if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
        $(this).addClass('image-checkbox-checked');
      }
      else {
        $(this).removeClass('image-checkbox-checked');
      }
    });

    // sync the state to the input
    $(".image-checkbox").on("click", function (e) {
      $(this).toggleClass('image-checkbox-checked phovercontent_active proicon_chkbox');
      let $checkbox = $(this).find('input[type="checkbox"]');
      $checkbox.prop("checked",!$checkbox.prop("checked"))

      e.preventDefault();
    });

    // this.getAllProduct();
  }


  getcontact(){
    this.cleanup()
    let user = JSON.parse(localStorage.getItem('currentUser'));

    let token = jwt.sign({
      "uuid": Math.random()*1000,
      "FirstName": "there",
      "trigger_reason": "CONTACT_ME",
      "productName": "Smart workplace bundle"
    }, '9e181236-6850-48a8-8807-d8947436ac12');

    this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
    this.chatBox.load();
    console.log("chatbox is ", this.chatBox);
    setTimeout(()=>{
     this._w.Avaamo.openChatBox();
    },1000);
  }

  cleanup() {
    [].forEach.call(document.querySelectorAll('.avaamo__chat__widget'), (x) => x.remove());
    [].filter.call(document.querySelectorAll('script'), x => x.src.indexOf('avaamo')!=-1).forEach(x => x.remove());
  }

  show_product(){
    this.getAllProduct();
    $('#product_carousel').css('display','block');
  }
  

  // getAllProduct() {
  //   let tempproduct = {

  //   }
  //   this.service.getProduct()
  //     .subscribe((data) => {
  //       for (let index = 0; index < data.products.length; index++) {
  //         let tempdata = {
  //           repositoryId: data.products[index].id,
  //           displayName: data.products[index].displayName,
  //           salePrice: data.products[index].salePrice,
  //           description: data.products[index].description

  //         }
  //         this.product.push(tempdata);

  //       }

  //       console.log(this.product);
  //     });


  // }

  getAllProduct()
    {
        let bandwidthValueID = $("#bandwidthValueID")[0]['innerText'];
        
        let needToValid = 1;

        console.log(needToValid);

        this.product = [];
        // this.cart_btn = "Add to cart";
        let tempproduct = {}
        // let tempB = null;
        let temp_product = JSON.parse(localStorage.getItem('product_internet'));
        console.log(temp_product);
        for (let index = 0; index < temp_product.products.length; index++) {
            let price = 0;
                if(temp_product.products[index].x_recurrencecost != null)
                {
                  price = temp_product.products[index].x_recurrencecost;
                //   price = (Number(price) > 0) ? price : 0;  
                }

            if (temp_product.products[index].parentCategories[0].repositoryId == 'CON_002') {
            
            
                let tempdata = {
                  catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
                  id: temp_product.products[index].id,
                  type: temp_product.products[index].type,
                  displayName: temp_product.products[index].displayName,
                  salePrice: temp_product.products[index].listPrice,
                  bandwidth: temp_product.products[index].x_bANDWIDTH,
                  recurrencecost: price,
                  recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
                  description: temp_product.products[index].description
                }
                this.product.push(tempdata);
                this.product.forEach((item, index) => {
                  if (index !== this.product.findIndex(i => i.id === item.id)) {
                    this.product.splice(index, 1);
                  }
      
                });
            
            
                // localStorage.setItem('product_internet', JSON.stringify(this.product));
    
            }
      
          }
      
    }


    // ADD TO CART
    viewdetail(id) 
    {
        // document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove" ? "Add to cart" : "Remove";
        let p_id = id;
        let ethernet_detail = [];
        for (let index = 0; index < this.product.length; index++) 
        {
            if (this.product[index].id == p_id)
            {
                this.modal_prodcut_name = this.product[index].displayName;
                let ethernetdetailData = {
                    id: this.product[index].id,
                    displayName: this.product[index].displayName,
                    salePrice: this.product[index].salePrice,
                    bandwidth: this.product[index].bandwidth,
                    recurrencecost: this.product[index].recurrencecost,
                    recurrencePeriod: this.product[index].recurrencePeriod,

                }

                    ethernet_detail.push(ethernetdetailData);
                    localStorage.setItem('ethernet_detail', JSON.stringify(ethernet_detail));
               
            }
        }
        console.log('ethernet');
        console.log(ethernet_detail);
        // this.router.navigate(['cart_summary/']);
        console.log(JSON.parse(localStorage.getItem('ethernet_detail')));

        this.cleanup()
        let user = JSON.parse(localStorage.getItem('currentUser'));
    
        let token = jwt.sign({
          "uuid": Math.random()*1000,
          "FirstName": "there",
          "trigger_reason": "CONTACT_ME",
          "productName": "Smart workplace bundle"
        }, '9e181236-6850-48a8-8807-d8947436ac12');
    
        this.chatBox = new this._w.AvaamoChatBot({ url: 'https://c0.avaamo.com/web_channels/4f321e32-a08f-4009-a6ad-2f5e9c6a1e62?theme=avm-messenger&user_info='+token+'' });
        this.chatBox.load();
        setTimeout(()=>{
         this._w.Avaamo.openChatBox();
        },1000);

    }

}
