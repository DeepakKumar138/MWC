import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IotBundleComponent } from './iot-bundle.component';

describe('IotBundleComponent', () => {
  let component: IotBundleComponent;
  let fixture: ComponentFixture<IotBundleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IotBundleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IotBundleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
