import { Component, ElementRef, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
import { OwlCarousel } from 'ngx-owl-carousel';
import { ServiceService } from '../services/service.service';
// import { Product } from '../model/product'
import { environment } from '../../environments/environment'
import { from } from 'rxjs';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'util';
import { Options } from 'ng5-slider';
declare var bandwidth: String;
@Component({
  selector: 'app-iot-bundle',
  templateUrl: './iot-bundle.component.html',
  styleUrls: ['./iot-bundle.component.css']
})
export class IotBundleComponent implements OnInit {

  bandwidth: number = 10;
  location: number = 10;
  Employees: number = 10;   
  contact: number = 10;
  cart_btn: String;
  options: Options = {
      floor: 10,
      ceil: 1024
  };
  iot_cart =[];
  banner:String;
  product =[];
  modal_prodcut_name:String;
  s_light:boolean =false ;
  s_water:boolean =false;
  s_access:boolean =false;
  s_alarm:boolean =false;
  s_surveollance:boolean =false;
  s_meter:boolean =false;

  constructor(private service: ServiceService) {}

  ngOnInit()
  {
    this.service.login().subscribe((data:any)=>{
      this.service.getProduct().subscribe((data:any)=>{
        console.log(data);
        localStorage.setItem('product_internet',JSON.stringify(data));
      });
    });
      // image gallery
      // init the state from the input
      $(".image-checkbox").each(function () {
          if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
              $(this).addClass('image-checkbox-checked');
          }
          else {
              $(this).removeClass('image-checkbox-checked');
          }
      });
      // sync the state to the input
      $(".image-checkbox").on("click", function (e) {
          $(this).toggleClass('phovercontent_active proicon_chkbox');
          $(this).toggleClass('image-checkbox-checked');
          let $checkbox = $(this).find('input[type="checkbox"]');
          $checkbox.prop("checked", !$checkbox.prop("checked"))

          e.preventDefault();
      });
      this.getBannerImage();
      this.fetchBundleProduct();
  }

  show_product()
  {
      this.getAllProduct();
      $('#product_carousel').css('display', 'block');
      // console.log(' hlloe '+this.bandwidth);
  }

  getBannerImage()
  {
      this.service.getBannerImages()
          .subscribe((bannerdata) => 
          {
              console.log(bannerdata);    
              this.banner = 'http://52.5.252.249:8080' + bannerdata.webPageAssets.banners[2].url;
              // console.log(' banner' + this.banner);
          });
  }

  
// fetch  add bundle product
fetchBundleProduct(){
    let tmp_internet = JSON.parse(localStorage.getItem('iot_bundle'));
    this.product.push(tmp_internet[0]);
    console.log(this.product);
  }
  
  // get product sorted by bandwidth
  getAllProduct()
  {
      let smartLighting = ($('#smartLighting').is(":checked")) ? 1 : 0;
      let smartWater = ($('#smartWater').is(":checked")) ? 1 : 0;
      let smartAC = ($('#smartAC').is(":checked")) ? 1 : 0;
      let smartSurveillance = ($('#smartSurveillance').is(":checked")) ? 1 : 0;
      let smartAlarms = ($('#smartAlarms').is(":checked")) ? 1 : 0;
      let smartAccess = ($('#smartAccess').is(":checked")) ? 1 : 0;

      let locationIDVALUE = $("#locationValueID")[0]['innerText'];
      let bandwidthValueID = $("#bandwidthValueID")[0]['innerText'];
      
      let needToValid = 1 + Number(smartLighting) + Number(smartWater) + Number(smartAC) + Number(smartSurveillance) + Number(smartAlarms) + Number(smartAccess);

      console.log(needToValid);

      this.product = [];
      // this.cart_btn = "Add to cart";
      let tempproduct = {}
      // let tempB = null;
      let temp_product = JSON.parse(localStorage.getItem('product_internet'));
      console.log(temp_product);
      for (let index = 0; index < temp_product.products.length; index++)
      {
          let databaseBandwidthValue = 10;
          if(temp_product.products[index].x_bANDWIDTH)
          {
              let tempB = temp_product.products[index].x_bANDWIDTH.split(' ');
              databaseBandwidthValue = tempB[0];
          }

          // let databaseLocationValue = 0;
          // if(temp_product.products[index].x_Location)
          // {
          //     databaseLocationValue = temp_product.products[index].x_Location;
          //     databaseLocationValue = databaseLocationValue.replace("MBPS", "");
          //     databaseLocationValue = databaseLocationValue.replace(" ", "");    
          // }

          if (temp_product.products[index].parentCategories[0].repositoryId == 'IOTC_001')
          {
              
        let tempdata = {
          catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
          id: temp_product.products[index].id,
          type: temp_product.products[index].type,
          displayName: temp_product.products[index].displayName,
          salePrice: temp_product.products[index].listPrice,
          bandwidth: temp_product.products[index].x_bANDWIDTH,
          recurrencecost: temp_product.products[index].x_recurrencecost,
          recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
          description: temp_product.products[index].description
        }
        this.product.push(tempdata);
        this.product.forEach((item, index) => {
          if (index !== this.product.findIndex(i => i.id === item.id)) {
            this.product.splice(index, 1);
          }

        });
             
            //   let tempdata = {
            //       catgory_id: temp_product.products[index].parentCategories[0].repositoryId,
            //       id: temp_product.products[index].id,
            //       type: temp_product.products[index].type,
            //       displayName: temp_product.products[index].displayName,
            //       salePrice: temp_product.products[index].listPrice,
            //       bandwidth: temp_product.products[index].x_bANDWIDTH,
            //       recurrencecost: temp_product.products[index].x_recurrencecost,
            //       recurrencePeriod: temp_product.products[index].x_recurrencePeriod,
            //       description: temp_product.products[index].description,
            //       s_light:temp_product.products[index].x_sMARTLIGHT,
            //       s_water:temp_product.products[index].x_sMARTWATER,
            //       s_access:temp_product.products[index].x_sMARTACCESS,
            //       s_alarm:temp_product.products[index].x_sMARTALARMS,
            //       s_surveollance:temp_product.products[index].x_sMARTSURVEILLANCE,
            //       s_meter:temp_product.products[index].x_sMARTMETER
            //   }
              
            //   let isValid = 0;
            //   if(Number(smartLighting)) { if(temp_product.products[index].x_sMARTLIGHT) { isValid = Number(isValid) + 1; } }
            //   if(Number(smartWater)) { if(temp_product.products[index].x_sMARTWATER) { isValid = Number(isValid) + 1; } }
            //   if(Number(smartAC)) { if(temp_product.products[index].x_sMARTACCESS) { isValid = Number(isValid) + 1; } }
            //   if(Number(smartSurveillance)) { if(temp_product.products[index].x_sMARTSURVEILLANCE) { isValid = Number(isValid) + 1; } }
            //   if(Number(smartAlarms)) { if(temp_product.products[index].x_sMARTALARMS) { isValid = Number(isValid) + 1; } }

            //   // if(databaseLocationValue <= locationIDVALUE)
            //   // {
            //   //     isValid = Number(isValid) + 1;
            //   // }

            //   console.log(databaseBandwidthValue);
            //   console.log(bandwidthValueID);

            //   if(databaseBandwidthValue <= bandwidthValueID)
            //   {
            //       isValid = Number(isValid) + 1;
            //   }

            //   if(Number(isValid) == Number(needToValid))
            //   {
            //       this.product.push(tempdata);
            //       this.product.forEach((item, index) =>
            //       {
            //           if (index !== this.product.findIndex(i => i.id === item.id))
            //           {
            //               this.product.splice(index, 1);
            //           }
            //       });
            //   }
            //   localStorage.setItem('iot_product', JSON.stringify(this.product));
            //   console.log('localStorage',JSON.parse(localStorage.getItem('iot_product')))
          }
      }
  }

  // ADD TO CART


  addToCart(id) {

    document.getElementById("btn-" + id).innerHTML = document.getElementById("btn-" + id).innerHTML == "Remove from Bundle" ? "Add to Bundle" : "Remove from Bundle";

    let p_id = id;
    // this.cart_btn ="Remove";
    let internet_cart =[];
    for (let index = 0; index < this.product.length; index++) {
      if (this.product[index].id === p_id) {
        this.modal_prodcut_name = this.product[index].displayName;
        let internet = {
          id: this.product[index].id,
          displayName: this.product[index].displayName,
          salePrice: this.product[index].salePrice,
        
          recurrencecost: this.product[index].recurrencecost,
      

        }

      
        if (JSON.parse(localStorage.getItem("smart_bunddle_cart")) == null ) {
          internet_cart.push(internet);

          localStorage.setItem('smart_bunddle_cart', JSON.stringify(internet_cart));
          // environment.internet_cart.push(internet)
        }
        else{
          internet_cart = JSON.parse(localStorage.getItem("smart_bunddle_cart"));
        
          for (let index = 0; index < internet_cart.length; index++) {
            internet_cart[1] =internet ;

          }
            console.log(internet_cart);
            
  
          // internet_cart = JSON.parse(localStorage.getItem("smart_bunddle_cart"));
          // internet_cart.push(internet);
          localStorage.setItem('smart_bunddle_cart', JSON.stringify(internet_cart));
        }
      }


    }



    // console.log(environment.internet_cart);
    // this.router.navigate(['cart_summary/']);

    // console.log(localStorage.getItem('product_internet'));
  }
}
