import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IotSmartWorkplaceComponent } from './iot-smart-workplace.component';

describe('IotSmartWorkplaceComponent', () => {
  let component: IotSmartWorkplaceComponent;
  let fixture: ComponentFixture<IotSmartWorkplaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IotSmartWorkplaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IotSmartWorkplaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
