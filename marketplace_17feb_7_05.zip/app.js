//Install express server
const express = require('express');
const path = require('path');

const app = express();

// Serve only the static files form the dist directory
 app.use(express.static(__dirname + '/dist/marketplace'));
//app.use(express.static('/dist'));

//app.use('/static', express.static(path.join(__dirname, 'dist')))
app.get('/*', function(req,res) {
   
res.sendFile(path.join(__dirname+'/dist/marketplace/index.html'));
});

// Start the app by listening on the default Heroku port
app.listen(process.env.PORT || 8888);